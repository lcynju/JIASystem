package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DzdaWdAjDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 13314 on 2018/9/12.
 */
@Repository
public interface DzdaWdAjDao extends JpaRepository<DzdaWdAjDO,String>{
    /**
     * 根据案号获取文档案件
     * @param ah
     * @return
     */
    DzdaWdAjDO findByAh(String ah) ;
}
