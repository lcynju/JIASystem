function error_tip(error_text) {
    alert(error_text);
}

/**
 * 检查网络请求的返回值是否正确
 * @param returnVO
 * @returns {boolean}
 */
function check_result(returnVO) {
    if (returnVO.succeed) {
        return true;
    } else {
        if (returnVO.message === LOGIN_STATE.LOGIN_INVALID) {
            vm.login_state = LOGIN_STATE.UNLOGIN;
            vm.login_text = LOGIN_TEXT.LOGIN;
            if (vm.left_view_state === LEFT_VIEW_STATE.DZJZ) {
                vm.left_view_state = LEFT_VIEW_STATE.BDWD;
            }
            return false;
        } else {
            return false;
        }
    }
}

// 加载网页时检查是否登陆过
function checkLogin() {
    var dm = getCookie();
    if (dm === '') {
        vm.login_state = LOGIN_STATE.UNLOGIN;
        vm.login_text = LOGIN_TEXT.LOGIN;
        //获取空白文档
        getEmptyDocument();
    } else {
        $.ajax({
            url: baseUrl + '/checkLogin',
            type: 'get',
            data: {
                name: dm
            },
            success: function (res) {
                if (check_result(res)) {
                    vm.login_state = LOGIN_STATE.LOGIN;
                    vm.login_username = "欢迎您，" + res.object.name + "（" + res.object.sf + "）";
                    vm.login_text = LOGIN_TEXT.EXIT;
                    getDocumentModel();
                } else {
                    vm.login_state = LOGIN_STATE.UNLOGIN;
                    vm.login_text = LOGIN_TEXT.LOGIN;
                    //获取空白文档
                    getEmptyDocument();
                }
            },
            error: function () {
                vm.login_text = LOGIN_TEXT.LOGIN;
                vm.login_state = LOGIN_STATE.UNLOGIN;
            }
        })
    }

}

function getCookie() {
    var dm = '';
    document.cookie.split(';').forEach(function (cook) {
        var name = cook.split('=')[0];
        var value = cook.split('=')[1];
        if (name.trim() === 'dm') {
            dm = value;
        }
    });
    return dm;
}

function delCookie(cookie_name) {
    var date = new Date();
    date.setTime(date.getTime() - 1000);
    //删除cookie的方式就是把expires设置为一个过去的时间
    document.cookie = "dm=" + cookie_name + ";expires=" + date.toUTCString()
}

/**
 * 根据列表案件长度创建下标
 * @param list_length 案件列表长度
 */
function create_pagination(list_length) {
    if (list_length === 0) {
        vm.zjIdxList.removeAll();
    } else if (list_length <= 15 && list_length > 0) {
        vm.zjIdxList = [1];
    } else {
        var page_num = Math.ceil(list_length / 15);
        vm.zjIdxList.removeAll();
        for (var i = 1; i <= page_num; i++) {
            vm.zjIdxList.push(i);
        }
    }
}

function create_treeview(tree_data) {
    //生成树控件
    $("#left_tree_view").animate({marginTop: '0px'});
    $('#left_tree_view').treeview({
        color: "#3d3d3d",
        data: tree_data,
        enableLinks: true,
        levels: 2,
        onNodeSelected: function (event, node) {
            if (node.isDocument !== undefined && node.isDocument === true) {
                // 根据树节点的选择进行响应
                $('#view_dzjz_ocr_content').fadeOut({
                    duration: 500
                });
                $('#load_document_tip').css('color', 'black');
                $('#load_document_tip').css('display', 'block');
                vm.showOcrContent = SHOW_STATE.HIDE;
                vm.doc_image_state = DOC_IMAGE_STATE.EMPTY;
                vm.extract_text = '';
                console.log(node.id + ":" + node.text);
                //如果是图片，则直接加载
                if (is_image(node.text)) {
                    vm.load_document_tip = LOAD_DOCUMENT.LOADING_IMAGE;
                    var wait1 = setInterval(function () {
                        if (vm.load_document_tip.length > 20) {
                            vm.load_document_tip = LOAD_DOCUMENT.LOADING_IMAGE;
                        } else {
                            vm.load_document_tip += '.';
                        }
                    }, 500);
                    vm.selectedWdId = node.id;
                    $.ajax({
                        url: baseUrl + '/getDzjzWd?wdId=' + node.id,
                        type: 'get',
                        success: function (doc) {
                            clearInterval(wait1);
                            if (check_result(doc)) {
                                console.log(doc.object.url);
                                vm.doc_image_state = DOC_IMAGE_STATE.IMAGE;
                                $('#load_document_tip').css('display', 'none');
                                load_picture(doc.object.url);
                            } else {
                                $('#load_document_tip').css('color', 'red');
                                vm.load_document_tip = doc.message;
                            }
                        },
                        error: function (data, status, e) {
                            clearInterval(wait1);
                            $('#load_document_tip').css('color', 'red');
                            vm.load_document_tip = ERROR_MESSAGE.UNEXPECTED;
                        }
                    })
                } else if(is_document(node.text)) {
                    load_tree_document(node);
                }

            }
        }
    });
}

function load_picture(image_url) {
    var image_content = $('#view_dzjz_image');
    image_content.attr("src", image_url);
}

function get_image_width(url, callback) {
    var img = new Image();
    img.src = url;
    // 如果图片被缓存，则直接返回缓存数据
    if (img.complete) {
        callback(img.width, img.height);
    } else {
        // 完全加载完毕的事件
        img.onload = function () {
            callback(img.width, img.height);
        }
    }

}

var fold_state = SHOW_STATE.SHOW;
$('#nav_tree').mouseenter(function () {
    if(fold_state === SHOW_STATE.HIDE && vm.load_tree_view_finish){
        show_tree_view();
        $('#fold_tree').html(FOLD_TREE_VIEW.EXPANDED);
        fold_state = SHOW_STATE.SHOW;
    }
});

$('#nav_tree').mouseleave(function () {
    if(fold_state === SHOW_STATE.SHOW && vm.load_tree_view_finish){
        hide_tree_view();
        $('#fold_tree').html(FOLD_TREE_VIEW.FOLD);
        fold_state = SHOW_STATE.HIDE;
    }
});

function hide_tree_view() {
    var tree_view = $('#left_tree_view');
    tree_view.treeview('collapseAll', {silent: true});
    tree_view.animate({marginTop: vm.fold_tree_margin}, 100);
    var wrap;
    if (vm.doc_image_state === DOC_IMAGE_STATE.DOCUMENT) {
        wrap = $('#view_dzjz');
    } else {
        wrap = $('#dzjz_image_content');
    }
    wrap.animate({marginLeft: '0%', width: '100%'}, 100);
}

function show_tree_view() {
    var tree_view = $('#left_tree_view');
    var wrap;
    tree_view.treeview('expandAll', {levels: 1});
    tree_view.animate({marginTop: '0px'}, 200);
    if (vm.doc_image_state === DOC_IMAGE_STATE.DOCUMENT) {
        wrap = $('#view_dzjz');
    } else {
        wrap = $('#dzjz_image_content');
    }
    wrap.animate({marginLeft: '50%', width: '50%'}, 200);
}

function change_document_size() {
    var win_height = window.innerHeight;
    //如果左边是电子卷宗，且案件详情打开，且右边存在打开的文档
    if (vm.left_view_state === LEFT_VIEW_STATE.DZJZ && vm.query_aj_state === AJ_STATE.AJXQ &&
        vm.right_opened_document_list.length > 0) {
        vm.left_win_height = win_height - 150 - 30;
        vm.right_win_height = win_height - 172 - 30;
    }
    // 如果左边是电子卷宗，但案件详情未打开，且右边存在打开但文档
    else if (vm.left_view_state === LEFT_VIEW_STATE.DZJZ && vm.query_aj_state !== AJ_STATE.AJXQ && vm.right_opened_document_list.length > 0) {
        vm.left_win_height = win_height - 100 - 30;
        vm.right_win_height = win_height - 122 - 30;
    }
    // 如果左边不是电子卷宗，但案件详情的状态是打开的
    else if(vm.left_view_state !== LEFT_VIEW_STATE.DZJZ){
        vm.right_win_height = win_height - 122 - 30;
    }

    if (vm.left_view_state === LEFT_VIEW_STATE.BDWD && vm.left_opened_document_list.length === 0) {
        vm.left_win_height = win_height - 100 - 30;
    } else if (vm.left_view_state === LEFT_VIEW_STATE.BDWD && vm.left_opened_document_list.length > 0) {
        vm.left_win_height = win_height - 120 - 30;
    }
    vm.tree_win_height = win_height - 172 - 30;

    $('#right_content').animate({height: vm.right_win_height + "px"}, 100);
    $('#left_content').animate({height: vm.left_win_height + "px"}, 100);
    $('#view_dzjz').animate({height: vm.tree_win_height + "px"}, 100);
    $('#dzjz_image_content').animate({height: vm.tree_win_height + "px"}, 100);

}

function get_index(arr, key) {
    for (var j = 0; j < arr.length; j++) {
        if (arr[j].key === key) {
            return j;
        }
    }
}

function is_image(mc) {
    return (/.*\.jpg/i.test(mc)) || (/.*\.png/i.test(mc)) || (/.*\.tif/i.test(mc));
}

function is_document(mc) {
    return (/.*\.(doc|pdf|xlsx|xls|xml|docx)/i.test(mc))
}

/**
 * 初始化页面的动作
 */
function init_view_state() {
    console.log("init view state");
    //检查是否登陆过
    checkLogin();
    //更新法律法规网站url（如果是已登陆，需要获取免密登陆的url）
    getFlfgList();
    //打开本地文档页面
    vm.open_bdwd();
}

function get_image_ocr() {
    $.ajax({
        url: baseUrl + '/getOcr',
        type: 'post',
        data: {
            ajxh: vm.selectedAjxh,
            wdId: vm.selectedWdId
        },
        success: function (data) {
            vm.tree_image_ocr_dict[vm.selectedWdId] = data;
        }
    });
}

function change_arr_2_str(arr) {
    var str = '';
    for (var i = 0; i < arr.length; i++) {
        str += arr[i] + '==';
    }
    return str;
}
if (window.attachEvent) {
    window.attachEvent("resize", change_document_size);
} else if (window.addEventListener) {
    window.addEventListener("resize", change_document_size, false);
}

function parse_dzjz_wdml(data) {
    var result = [];
    data.forEach(function (item) {
        if(item){
            item.text = item.mc;
            //console.log('item', item);
            //区分电子卷宗
            if (item.xssx === 1) {
                //区分正卷、副卷等
                item = parse_first_zml(item);
                item.nodes = item.zml;
            }
            // 原审档案
            else if(item.xssx === 3) {
                item.zml = parse_second_zml(item.zml);
                item.nodes = item.zml;
            }
            //文书信息
            else if(item.xssx === 2) {
                if (item.wds !== null) {
                    item.wds.forEach(function (node) {
                        node.text = node.mc;
                        node.isDocument = true;
                    });
                    item.nodes = item.wds;
                }
            }
            else if(item.xssx === 4){
                item.zml.forEach(function (zml) {
                    zml.text = zml.mc;
                    zml.nodes = parse_dzjz_wdml(zml.zml);
                });
                item.nodes = item.zml;
            }

            result.push(item)
        }

    });
    return result;
}

function parse_first_zml(item) {

    if(item.zml !== null){
        item.zml.forEach(function (node) {
            node.text = node.mc;
            if (node.zml !== null) {
                node.zml = parse_second_zml(node.zml);
            }
            node.nodes = node.zml;
        });
    }
    return item;
}
function parse_second_zml(zmls) {
    var result_zmls = [];
    if(zmls){
        zmls.forEach(function (zml) {
            zml.text = zml.mc;
            // 区分文档或图片
            if (zml.wds !== null) {
                zml.wds.forEach(function (wd) {
                    wd.text = wd.mc;
                    // isDocument属性表示是可以加载的文档或图片
                    wd.isDocument = true;
                    if (is_image(wd.text)) {
                        vm.tree_image_list.push(wd.id);
                    }
                });
            }
            zml.nodes = zml.wds;
            result_zmls.push(zml);
            //console.log("node:", zml);
        });
        return result_zmls;
    }
}
