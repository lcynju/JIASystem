package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.AyDmbDao;
import cn.edu.nju.software.data.dao.LaAyDao;
import cn.edu.nju.software.data.dataobject.AydmbDO;
import cn.edu.nju.software.data.dataobject.LaAyDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.AyDmbService;
import cn.edu.nju.software.service.convertor.AydmbConvertor;
import cn.edu.nju.software.service.model.AydmModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/14
 */
@Service
public class AyDmbServiceImpl implements AyDmbService {
    @Autowired
    private AyDmbDao ayDmbDao ;
    @Autowired
    private LaAyDao laAyDao ;
    @Override
    public List<AydmModel> getAydmByAjxh(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);

        List<AydmModel> aydmModels = null ;

        List<LaAyDO> laAyDOS = laAyDao.findByAjxh(ajxh);
        if(laAyDOS!=null&&!laAyDOS.isEmpty()){
            aydmModels = new ArrayList<>() ;
            for(LaAyDO laAyDO:laAyDOS){
                AydmbDO ayDO = ayDmbDao.findByDmbh(laAyDO.getAy());

                /**
                 * 若查询不到pub_aydmb则适用立案案由
                 */
                if(ayDO!=null){
                    aydmModels.add(AydmbConvertor.DO2Model(ayDO)) ;
                }else {
                    AydmModel model = new AydmModel() ;
                    model.setAydmbh(laAyDO.getAy());
                    model.setDmms(laAyDO.getLaay());
                    aydmModels.add(model) ;
                }

            }
        }
        DynamicDataSource.router(curDB);
        return aydmModels;
    }
}
