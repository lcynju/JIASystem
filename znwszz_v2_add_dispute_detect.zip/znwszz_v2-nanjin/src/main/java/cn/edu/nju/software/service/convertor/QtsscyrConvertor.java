package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.QtsscyrDO;
import cn.edu.nju.software.service.model.Qtsscyr;
import cn.edu.nju.software.service.model.enums.QtsscyrTypeEnum;
import cn.edu.nju.software.service.model.enums.XbEnum;
import cn.edu.nju.software.util.DateUtil;
import cn.edu.nju.software.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 *
 * @author 13314
 * @date 2018/8/15
 */
public class QtsscyrConvertor {
    private static  Logger logger = LoggerFactory.getLogger(QtsscyrConvertor.class) ;
    public static Qtsscyr DO2Model(QtsscyrDO DO,Map<String,String> zwMap){
        Qtsscyr cyr = new Qtsscyr() ;
        QtsscyrTypeEnum cyrLx = QtsscyrTypeEnum.getMcByBh(DO.getQtsscyrlx()) ;
        if(cyrLx==null){
            logger.error("构造其他诉讼参与人失败，参与人类型无法识别"+DO.toString());
            return null ;
        }
        cyr.setLx(cyrLx.getMc());
        cyr.setLxDm(cyrLx.getBh());
        if(cyrLx.equals(QtsscyrTypeEnum.FDDBR)){
            /**
             * 法定代表人，dm在数据库为A，为了让法定代表人在其他诉讼参与人列表中排序排在第一，将dm改为0
             */
            cyr.setLxDm("0");
        }
        cyr.setMc(DO.getXm());
        if(cyrLx.equals(QtsscyrTypeEnum.WTDLR)&&
                !StringUtil.isEmpty(DO.getGzdw())&&
                StringUtil.contains(DO.getGzdw(),"律师")){
            cyr.setXx(DO.getGzdw()+"。");
        }else {
            StringBuilder xxBuilder = new StringBuilder() ;
            if(!StringUtil.isEmpty(DO.getXb())){
                xxBuilder.append(XbEnum.getMcByBh(DO.getXb())+"，") ;
            }
            if(null!=DO.getCsnyr()){
                xxBuilder.append(DateUtil.format(DO.getCsnyr(),DateUtil.chineseDtFormat)+"出生，") ;
            }
            if(!StringUtil.isEmpty(DO.getDz())){
                xxBuilder.append(DO.getDz()+"，") ;
            }
            if(!StringUtil.isEmpty(DO.getZw())){
                xxBuilder.append(zwMap.get(DO.getZw())+",") ;
            }
            if(xxBuilder.length()>0){
                cyr.setXx(xxBuilder.toString().substring(0,xxBuilder.length()-1).trim()+"。");
            }
        }
        return cyr ;
    }
}
