package cn.edu.nju.software.service.model;

/**
 * Created by 13314 on 2018/8/13.
 */

import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

/**
 *
 * 代表编码的类型
 * @author zym
 *
 */
public class CodeItem implements Serializable {

    private static final long serialVersionUID = -4685960877887925067L;

    /**
     * 代码编号
     */
    private String dm;

    /**
     * 代码值
     */
    private String value;

    /**
     * 该代码的类别编号
     */
    private String lbbh;


    public CodeItem(){
        super();
    }

    /**
     * CodeItem的构造函数
     *
     * @param dm
     * @param value
     * @param lbbh
     */
    public CodeItem(String dm, String value, String lbbh) {
        super();
        this.dm = dm;
        this.value = value;
        this.lbbh = lbbh;
    }

    public String getDm() {
        return dm;
    }

    public void setDm(String dm) {
        this.dm = dm;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }


    public String getLbbh() {
        return lbbh;
    }

    public void setLbbh(String lbbh) {
        this.lbbh = lbbh;
    }


    @Override
    public String toString(){
        return ToStringBuilder.reflectionToString(this);
    }
}
