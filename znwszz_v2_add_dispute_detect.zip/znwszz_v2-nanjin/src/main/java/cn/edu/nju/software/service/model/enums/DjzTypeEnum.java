package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;
import jdk.nashorn.internal.objects.NativeUint8Array;

/**
 *
 * @author 13314
 * @date 2018/8/15
 */
public enum DjzTypeEnum {
    /**
     * 单位、机构登记证类别
     */
    GSDJZ("L","工商登记证"),
    ZZJGDMZ("M","组织机构代码证"),
    MFQYDJZ("N","民非企业登记证"),
    QYXYZHM("O","企业信用证号码"),

    /**
     * 其他不显示
     */
//    QT("P","其他"),
    TYSHXYZ("Q","统一社会信用代码"),
    ;
    private String bh ;
    private String mc ;
    DjzTypeEnum(String bh,String mc){
        this.bh = bh ;
        this.mc = mc ;
    }
    public static String findMcByBh(String bh){
        for(DjzTypeEnum typeEnum:DjzTypeEnum.values()){
            if(StringUtil.equals(StringUtil.trim(bh),typeEnum.bh)){
                return typeEnum.mc ;
            }
        }
        return null ;
    }
}
