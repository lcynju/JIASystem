package cn.edu.nju.software.service.model;

import cn.edu.nju.software.util.StringUtil;
import lombok.Data;
import lombok.Getter;

/**当事人机构
 *
 * @author 13314
 * @date 2018/8/15
 */
@Getter
public class DsrJg extends Dsr{
    /**
     * 登记证类别
     */
    private String djzlb ;
    /**
     * 登记证号
     */
    private String djzh ;
    /**
     * 法定代表人
     */
    private String fddbr ;

    public void setDjzlb(String djzlb) {
        if(!StringUtil.isEmpty(djzlb)) {
            this.djzlb = djzlb;
        }
    }

    public void setDjzh(String djzh) {
        if(!StringUtil.isEmpty(djzh)) {
            this.djzh = djzh;
        }
    }

    public void setFddbr(String fddbr) {
        if(!StringUtil.isEmpty(fddbr)) {
            this.fddbr = fddbr;
        }
    }
}
