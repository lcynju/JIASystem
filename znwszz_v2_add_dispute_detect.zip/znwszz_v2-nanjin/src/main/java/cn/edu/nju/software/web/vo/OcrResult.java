package cn.edu.nju.software.web.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

/**
 * Created by 13314 on 2018/9/12.
 */
@Data
@AllArgsConstructor
@ToString
@ApiModel
public class OcrResult {
    @ApiModelProperty(value = "文档id")
    private String wdId ;
    @ApiModelProperty(value = "ocr识别结果字符串，含有\\t制表符")
    private String content ;
}
