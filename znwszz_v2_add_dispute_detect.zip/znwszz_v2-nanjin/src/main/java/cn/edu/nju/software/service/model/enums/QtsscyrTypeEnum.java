package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;

/**
 *
 * @author 13314
 * @date 2018/8/15
 */
public enum QtsscyrTypeEnum {
    /**
     * 其他诉讼参与人类型
     */
    FDDLR("1","法定代理人"),
    WTDLR("2","委托代理人"),
    ZDDLR("3","指定代理人"),
    SSDBR("4","诉讼代表人"),
    BHR("5","辩护人"),
    ZR("6","证人"),
    FYR("7","翻译人"),
    JDR("8","鉴定人"),
    KYR("9","勘验人"),


    FDDBR("A","法定代表人"),
    FZR("B","负责人"),
    ZQR("C","债权人"),
    ZWR("D","债务人"),
    JCY("F","检察员"),
    ;
    private String bh ;
    private String mc ;
    QtsscyrTypeEnum(String bh,String mc){
        this.bh = bh ;
        this.mc = mc ;
    }
    public static QtsscyrTypeEnum getMcByBh(String bh){
        for(QtsscyrTypeEnum typeEnum:QtsscyrTypeEnum.values()){
            if(StringUtil.equals(StringUtil.trim(bh),typeEnum.getBh())){
                return typeEnum ;
            }
        }
        return null ;
    }

    public String getBh() {
        return bh;
    }

    public String getMc() {
        return mc;
    }
}
