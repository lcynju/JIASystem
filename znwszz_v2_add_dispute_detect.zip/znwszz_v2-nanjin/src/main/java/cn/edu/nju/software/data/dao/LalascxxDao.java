package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.LaLascxxDO;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author 13314409603@163.com
 * @date 2018/10/31
 * @time 15:54
 * @Description
 */
public interface LalascxxDao extends JpaRepository<LaLascxxDO,Integer> {
    LaLascxxDO findByAjxh(int ajxh) ;
}
