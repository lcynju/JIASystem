package cn.edu.nju.software.service.convertor;


import cn.edu.nju.software.data.dataobject.DzjzWdMlDO;
import cn.edu.nju.software.data.dataobject.DzjzWdWjDO;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;

/**
 *
 * @author 13314
 * @date 2018/7/30
 */
public class DzjzConvertor {
    public static MlModel mlDO2MlModel(DzjzWdMlDO mlDO){
        MlModel mlModel = new MlModel() ;
        mlModel.setId(mlDO.getMlid());
        mlModel.setMc(mlDO.getMlmc());
        mlModel.setXssx(mlDO.getMlsx());
        return mlModel ;
    }

    /**
     * 构造文档model时，id加上电子卷宗前缀，用于与基表文书、本地文档区别
     * @param wjDO
     * @return
     */
    public static WdModel wjDO2WjModel(String fydm,DzjzWdWjDO wjDO){
        WdModel wdModel = new WdModel() ;
        wdModel.setId(DocSourceEnum.DZJZ.getPrefix()+DocSourceEnum.CONNECTOR +fydm+DocSourceEnum.CONNECTOR+wjDO.getWjid());
        wdModel.setMc(wjDO.getWjmc());
        wdModel.setWjsx(wjDO.getWjsx());
        return wdModel ;
    }
}
