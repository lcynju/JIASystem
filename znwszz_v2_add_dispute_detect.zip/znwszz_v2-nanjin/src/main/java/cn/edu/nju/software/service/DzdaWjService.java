package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;

import java.util.ArrayList;
import java.util.Map;

/** 电子档案Service
 * Created by 13314 on 2018/9/12.
 */
public interface DzdaWjService {
    /**
     * 根据案件序号，获取该案件电子档案文件目录
     * @param fydm
     * @param ah
     * @return
     */
    MlModel getDzdaMlByAjxh(String fydm, String ah) ;

    /**
     * 获取指定电子档案文件model
     * @param wdId
     * @return
     */
    DocumentModel getDzjzDocumentModel(String wdId) ;

    /**
     * 获取电子档案图片ocr识别结果
     * @param ajxh
     * @param fydm
     * @return
     */
    Map<String,ArrayList<String>> getOcrResult(int ajxh, String fydm) ;
}
