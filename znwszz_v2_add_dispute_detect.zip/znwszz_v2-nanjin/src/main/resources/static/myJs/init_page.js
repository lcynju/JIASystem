/**
 * Created by YuanHao on 2018/7/25.
 *  初始化页面
 */

//初始化fileinput
$(function () {
    console.log("init fileinput");
    var oFileInput = new FileInput();
    oFileInput.Init("left_file_upload", "/upload?type=view");
    oFileInput.Init("right_file_upload", "/upload?type=edit");

});

//初始化fileinput
var FileInput = function () {
    var oFile = {};
    //初始化fileinput控件（第一次初始化）
    oFile.Init = function (ctrlName, uploadUrl) {
        var control = $('#' + ctrlName);
        //初始化上传控件的样式
        control.fileinput({
            language: 'zh', //设置语言
            uploadUrl: uploadUrl, //上传的地址
            allowedFileExtensions: ['xml', 'md', 'docx', 'doc', 'xlsx', 'xls', 'ppt', 'pptx', 'pdf', 'rtf','RFT'],//接收的文件后缀
            showUpload: false, //是否显示上传按钮
            showCaption: true,//是否显示标题
            browseClass: "btn btn-primary", //按钮样式
            dropZoneEnabled: false,//是否显示拖拽区域
            //maxFileSize: 0,//单位为kb，如果为0表示不限制文件大小
            //minFileCount: 0,
            maxFileCount: 10, //表示允许同时上传的最大文件个数
            enctype: 'multipart/form-data',
            validateInitialCount: false,
            previewFileIcon: "<i class='glyphicon glyphicon-king'></i>",
            msgFilesTooMany: "选择上传的文件数量({n}) 超过允许的最大数值{m}！",
            showPreview: false
        }).on("filebatchselected", function(event, files) {
            if(uploadUrl === "/upload?type=view"){
                uploadFile('leftUploadForm', 'left');
            }else{
                uploadFile('rightUploadForm', 'right');
            }

        });
        console.log("init file input finished");
    };

    return oFile;
};

//对bootstrap datetimepicker 进行汉化
$.fn.datetimepicker.dates['zh'] = {
    days: ["星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"],
    daysShort: ["日", "一", "二", "三", "四", "五", "六", "日"],
    daysMin: ["日", "一", "二", "三", "四", "五", "六", "日"],
    months: ["一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"],
    monthsShort: ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"],
    meridiem: ["上午", "下午"],
    today: "今天"
};


/**
 * 给Date 增加Format属性，即格式化日期
 * @param fmt
 * @returns {*}
 * @constructor
 */
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};

//计算当前日期和一个月前的日期并格式化为 yyyy-MM-dd
var today_time = new Date();
var begin_time = new Date();
begin_time = begin_time.setDate(today_time.getDate() - 31);
begin_time = new Date(begin_time);

//初始化日期控件
$("#datetimeStart").datetimepicker({
    format: 'yyyy-mm-dd',
    minView: 'month',
    language: 'zh',
    autoclose: true,
    endDate: new Date(),
    pickerPosition: "bottom-left"
}).on("click", function () {
    $("#datetimeStart").datetimepicker("setEndDate", $("#datetimeEnd").val())
});

$("#datetimeEnd").datetimepicker({
    format: 'yyyy-mm-dd',
    minView: 'month',
    language: 'zh',
    autoclose: true,
    todayBtn: true,
    todayHighlight: true,
    startDate: new Date(),
    pickerPosition: "bottom-left"
}).on("click", function () {
    $("#datetimeEnd").datetimepicker("setStartDate", $("#datetimeStart").val())
});

