package cn.edu.nju.software.thread;

import cn.edu.nju.software.service.DzjzWjService;
import cn.edu.nju.software.service.model.OcrModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.web.controller.JzdaController;
import cn.edu.nju.software.web.vo.OcrResult;
import org.apache.log4j.Logger;
//import org.springframework.data.redis.core.StringRedisTemplate;

import java.util.ArrayList;
import java.util.Map;


public class OcrThread implements Runnable {
    private OcrModel ocrModel;

    private Logger logger = Logger.getLogger(JzdaController.class);

    @Override
    public void run() {
        String wdId = ocrModel.getWdId();
        int ajxh = ocrModel.getAjxh();
        YhModel user = ocrModel.getUser();
        DzjzWjService dzjzWjService = ocrModel.getDzjzWjService();
//        StringRedisTemplate stringRedisTemplate = ocrModel.getStringRedisTemplate();
        String session_key = user.getDm() + "_" + ajxh + "_ocr_map";
        try{
            String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);

            Map<String, ArrayList<String>> ajWdsOcrResult = dzjzWjService.getOcrResult(ajxh, user.getFydm());
            String key = FyEnum.findByFydm(user.getFydm()).getFybh() + "_0_" + split_wdId[2];
            ArrayList<String> wdOcrResultList = ajWdsOcrResult.get(key);

            OcrResult ocrResult;
            if (wdOcrResultList == null || wdOcrResultList.isEmpty()) {
                logger.error(String.format("法院%s案件%s文档%socr识别结果为空", user.getFydm(), ajxh, wdId));
                System.err.println(String.format("法院%s案件%s文档%socr识别结果为空", user.getFydm(), ajxh, wdId));
                ocrResult = new OcrResult(wdId, "抱歉，该文档无OCR识别结果");
            } else {
                ocrResult = new OcrResult(wdId, wdOcrResultList.get(0));
            }
//            save_data_to_redis(stringRedisTemplate, session_key, ocrResult);
        }
        catch (Exception e) {
            logger.error(String.format("法院%s案件%s文档%socr识别结果为空", user.getFydm(), ajxh, wdId));
            System.err.println(String.format("法院%s案件%s文档%socr识别结果为空", user.getFydm(), ajxh, wdId));
            OcrResult ocrResult = new OcrResult(wdId, "抱歉，该文档无OCR识别结果");
//            save_data_to_redis(stringRedisTemplate, session_key, ocrResult);
        }
//        if (wdId.startsWith(DocSourceEnum.DZJZ.getPrefix())) {
//
//
//        } else {
//            logger.error(String.format("法院%s案件%s文档%socr识别,文档id格式错误，只支持电子卷宗文档", user.getFydm(), ajxh, wdId));
//            throw new BaseException("文档id格式错误");
//        }
    }

//    private void save_data_to_redis(StringRedisTemplate redisTemplate, String key, OcrResult ocrResult){
//        try {
////            redisTemplate.opsForHash().put(key, ocrResult.getWdId(), ocrResult.getContent());
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error(e);
//            throw new BaseException("存储ocr结果失败,请检查redis状态");
//        }
//    }

//    public void initOcrModel(StringRedisTemplate stringRedisTemplate, YhModel user, int ajxh, String wdId, DzjzWjService dzjzWjService) {
//        ocrModel = new OcrModel();
//        ocrModel.setAjxh(ajxh);
//        ocrModel.setWdId(wdId);
//        ocrModel.setUser(user);
//        ocrModel.setStringRedisTemplate(stringRedisTemplate);
//        ocrModel.setDzjzWjService(dzjzWjService);
//    }
}
