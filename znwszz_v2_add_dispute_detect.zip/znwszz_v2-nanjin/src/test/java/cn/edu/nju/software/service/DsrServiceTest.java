package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.AjModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * Created by 13314 on 2018/8/15.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DsrServiceTest {
    @Autowired
    private DsrService dsrService ;

    @Autowired
    private AjService ajService ;

    @Test
    public void test(){
        List<AjModel> fangzhe = ajService.getYjByName("120000 200", "2016/1/1", "2018/8/20", "方哲");
//        for(AjModel aj:fangzhe){
//            Map<String, List<Dsr>> dsrXxByAjxh = dsrService.getDsrXxByAjxh("120000 200", aj.getAjxh());
//            Assert.assertNotNull(dsrXxByAjxh);
//        }
    }
}
