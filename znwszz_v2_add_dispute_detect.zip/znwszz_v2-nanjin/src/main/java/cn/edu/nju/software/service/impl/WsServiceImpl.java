package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.PubWsJbDao;
import cn.edu.nju.software.data.dataobject.PubWsJbDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.manager.DocumentModelFactory;
import cn.edu.nju.software.service.WsService;
import cn.edu.nju.software.service.convertor.WsConvertor;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.WsModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.UrlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
@Service
public class WsServiceImpl implements WsService {
    @Autowired
    private PubWsJbDao wsJbDao ;
    @Autowired
    private DocumentModelFactory documentModelFactory ;
    private Logger logger = LoggerFactory.getLogger(WsServiceImpl.class) ;

    private static final String LJF = "-" ;

    @Override
    public MlModel getWsMlByAjxh(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        MlModel mlModel = new MlModel() ;
        mlModel.setId(DocSourceEnum.WSXX.getPrefix());
        mlModel.setMc(DocSourceEnum.WSXX.getMc());
        mlModel.setXssx(DocSourceEnum.WSXX.getXssx());

        /**
         * 获取文书列表
         */
        List<WsModel> wsModelsWithoutWsnr = this.getWsListWithoutWsnrByAjxh(ajxh);
        if(wsModelsWithoutWsnr==null){
            logger.info(String.format("fydm:%s,ajxh:%s文书为空", FyEnum.findByFydm(fydm).getJc(),ajxh));
            return null ;
        }
        /**
         * 构造DzjzWdModel列表
         */
        List<WdModel> wdList = new ArrayList<>() ;
        for(WsModel ws:wsModelsWithoutWsnr){
            wdList.add(WsConvertor.WsModel2JzdaModel(fydm,ws)) ;
        }
        /**
         *排序
         */
        Collections.sort(wdList,new Comparator<WdModel>() {
            @Override
            public int compare(WdModel o1, WdModel o2) {
                return o1.getWjsx()-o2.getWjsx();
            }
        });
        mlModel.setWds(wdList);
        DynamicDataSource.router(curDB);
        return mlModel;
    }

    @Override
    public DocumentModel getWsDocumentModel( String wdId) {
        String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);
        String fydm = split_wdId[1] ;
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);

        DocumentModel documentModel = null ;
        //wdId由"wsjb-fydm-ajxh-wsjbbh"构成
        try {
            PubWsJbDO wsJbDO = wsJbDao.findByAjxhAndWsjbbh(Integer.parseInt(split_wdId[2]), Integer.parseInt(split_wdId[3]));
            DynamicDataSource.router(curDB);
            String name = wsJbDO.getWswjm() ;
            documentModel = documentModelFactory.createDocumentModelByNameAndKey(name, wdId);
        }catch (Exception e){
            logger.error(String.format("构造文书类型documentModel失败，wdId:%s解析失败",wdId));
            throw new BaseException("文档id格式错误") ;
        }
        return documentModel ;
    }

    @Override
    public void downloadWs(HttpServletResponse response,String wdId) {
        try {
            //wdId由"wsjb-fydm-ajxh-wsjbbh"组成
            String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);
            String curDB = DynamicDataSource.getCurrentDB() ;
            DynamicDataSource.router(split_wdId[1]);
            PubWsJbDO wsJbDO = wsJbDao.findByAjxhAndWsjbbh(Integer.parseInt(split_wdId[2]), Integer.parseInt(split_wdId[3]));
            DynamicDataSource.router(curDB);
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition","attachment;fileName="+ UrlUtil.encode(wsJbDO.getWswjm()));
            ServletOutputStream outputStream = response.getOutputStream();
            outputStream.write(wsJbDO.getWsnr());
            outputStream.flush();
            outputStream.close();
        }catch (NullPointerException e){
            logger.error("查询文书基表为空，wdId:"+wdId);
            throw new BaseException("文书为空") ;
        } catch (Exception e){
            logger.error(String.format("下载基表文书失败，wdid：%s，错误信息：%s",wdId,e.getMessage()));
            throw new BaseException("下载文书失败") ;
        }
    }


    /**
     * 返回指定法院单个案件文书列表，针对文书基表,不含文书内容
     * @param ajxh
     * @return
     */
    private List<WsModel> getWsListWithoutWsnrByAjxh(int ajxh) {
        List<PubWsJbDO> wsJbDOS = wsJbDao.findByAjxhAndWsnrIsNotNull(ajxh);
        return WsConvertor.DOs2Models(wsJbDOS);
    }
}
