#word embedded+Bi-LSTM+CRF for Event Detect
    1、gensim word2vec
    2、Bi-LSTM+CRF
    
#steps:(main.py)
    1、processData()
    2、trainWord2Vec()
    3、main(args)