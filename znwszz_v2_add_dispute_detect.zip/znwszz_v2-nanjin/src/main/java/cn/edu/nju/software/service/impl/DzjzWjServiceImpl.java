package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.configuration.properties.JzdaServiceProperties;
import cn.edu.nju.software.data.dao.DzjzWdMlDao;
import cn.edu.nju.software.data.dao.DzjzWdWjDao;
import cn.edu.nju.software.data.dao.XtCygjbDao;
import cn.edu.nju.software.data.dataobject.DzjzWdMlDO;
import cn.edu.nju.software.data.dataobject.DzjzWdWjDO;
import cn.edu.nju.software.data.dataobject.XtCygjbDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.manager.DocumentModelFactory;
import cn.edu.nju.software.manager.webServiceManager.ocrManager.SpAndZsService;
import cn.edu.nju.software.service.DzjzWjService;
import cn.edu.nju.software.service.convertor.DzjzConvertor;
import cn.edu.nju.software.service.model.*;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.AjUtil;
import cn.edu.nju.software.util.Base64Util;
import cn.edu.nju.software.util.StringUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.*;

/**
 *
 * @author 13314
 * @date 2018/7/30
 */
@Service("dzjzWjService")
public class DzjzWjServiceImpl implements DzjzWjService {
    @Autowired
    private DzjzWdMlDao wdMlDao;
    @Autowired
    private DzjzWdWjDao wdWjDao;

    @Autowired
    private JzdaServiceProperties dzjzServicePro ;

    @Autowired
    private DocumentModelFactory documentModelFactory ;

//    @Autowired
    private SpAndZsService ocrService ;

    @Autowired
    private XtCygjbDao xtCygjbDao ;
    /**
     * 获取电子卷宗目录，默认去掉回收站
     */
    private static String EXCLUDE_STR = "%回收站%" ;
    private Logger logger = LoggerFactory.getLogger(DzjzWjServiceImpl.class) ;
    @Override
    public MlModel getDzjzMlByAjxh(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB();
        DynamicDataSource.router(fydm);
        /**
         * 获取文档，并构造文档所属目录-文档list
         */
        List<DzjzWdWjDO> wjs = wdWjDao.getByAjxh(ajxh);
        if(wjs==null){
            return null ;
        }
        //目录id-文档list
        Map<String,List<WdModel>> wdMap = fomateWdMap(fydm,wjs) ;
        /**
         * 获得目录列表，
         */
        List<DzjzWdMlDO> mls = wdMlDao.getByAjxhAndMlmcNotLike(ajxh,EXCLUDE_STR);
        if(mls==null){
            return null ;
        }
        /**
         * 填充入文档
         */
        List<MlModel> mlModels = fomateMl(null, mls, wdMap);

        MlModel mlModel = new MlModel() ;
        mlModel.setId(DocSourceEnum.DZJZ.getPrefix());
        mlModel.setMc(DocSourceEnum.DZJZ.getMc());
        mlModel.setXssx(DocSourceEnum.DZJZ.getXssx());
        mlModel.setZml(mlModels);
        DynamicDataSource.router(curDB);
        return mlModel;
    }

    @Override
    public DocumentModel getDzjzDocumentModel( String wdId) {


        //wdId由"dzjz-fydm_dzjzWdWjId"构成
        String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);
        String curDB = DynamicDataSource.getCurrentDB();
        String fydm = split_wdId[1] ;
        DynamicDataSource.router(fydm);
        DzjzWdWjDO dzjzWdDO = wdWjDao.getByWjid(split_wdId[2]);

        /**
         * 构造documentModel
         */
        String name = dzjzWdDO.getWjmc() ;

        DocumentModel documentModel = documentModelFactory.createDocumentModelByNameAndKey(name, wdId);
        //电子卷宗文档下载地址调用远程接口
        String baseUrl = dzjzServicePro.getDzjzDownloadUrl() ;
        String downloadUrl = String.format(baseUrl,FyEnum.findByFydm(fydm).getFybh(), split_wdId[2]) ;
        documentModel.setUrl(downloadUrl);

        DynamicDataSource.router(curDB);
        return documentModel;
    }

    @Override
    public Map<String, ArrayList<String>> getOcrResult(int ajxh, String fydm) {

        String ajbs = AjUtil.formAJBS(ajxh,fydm) ;
        Map<String,ArrayList<String>> result = null ;
        String resultStr = ocrService.getOCRResult(ajbs) ;
        if(resultStr==null){
            logger.error(ajbs+"此案件的ocr识别结果为空"); ;
            throw new BaseException(ajbs+"此案件的ocr识别结果为空") ;
        }
        ObjectMapper mapper = new ObjectMapper() ;
        try {
            result = mapper.readValue(resultStr, HashMap.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    @Override
    public void uploadFileToDzjz(YhModel user,int ajxh,String wjmc ,File targetFile) {
        logger.info("上传文档到电子卷宗");
        if(!targetFile.exists()){
            logger.error("上传到电子卷宗的文件不存在");
            throw  new BaseException("上传到电子卷宗的文件不存在") ;
        }
        /**
         * 准备参数
         */
        String root = "正卷" ;
        String folder = BgJzEnum.getMatchJz(wjmc) ;

        try {
            root = Base64Util.getBASE64(root.getBytes("UTF-8"));
            folder = Base64Util.getBASE64(folder.getBytes("UTF-8"));
            wjmc = Base64Util.getBASE64(wjmc.trim().getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        /**
         * 填充参数
         */
        MultiValueMap<String,Object> bodyMap = new LinkedMultiValueMap<>() ;
        FileSystemResource file = new FileSystemResource(targetFile);
        bodyMap.add("file",file);
        bodyMap.add("ajxh",ajxh);
        bodyMap.add("wjmc",wjmc) ;
        bodyMap.add("yhbh",user.getYhbh()) ;
        bodyMap.add("root",root) ;
        bodyMap.add("folder",folder) ;
        /**
         * 方法头
         */
        HttpHeaders headers = new HttpHeaders() ;
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String,Object>> entity = new org.springframework.http.HttpEntity<>(bodyMap,headers) ;


        /**
         * 获取目标url
         */
        DynamicDataSource.router(user.getFydm());
        XtCygjbDO xtCygjbDO = xtCygjbDao.findByGjmc("电子卷宗");
        if (xtCygjbDO == null || StringUtil.isBlank(xtCygjbDO.getLj())) {
            logger.error("上传文件时找不到电子卷宗服务器地址, ajxh: {}, wjmc: {}", ajxh, wjmc);
            throw new BaseException("上传文件时找不到电子卷宗服务器地址, ajxh: "+ajxh+", wjmc: " + wjmc);
        }
        String dzjzServerUrl = xtCygjbDO.getLj();
        if (!dzjzServerUrl.endsWith("/")) {
            dzjzServerUrl += "/";
        }
        dzjzServerUrl += "gatewayUploadMul.do" ;

        /**
         * 测试库地址
         */
        // dzjzServerUrl = "http://130.1.1.70:8083/dzjz/gatewayUploadMul.do" ;
        /**
         * 发送请求
         */
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<ResponseResult> result = restTemplate.exchange(dzjzServerUrl, HttpMethod.POST, entity, ResponseResult.class);
        int statusCode = result.getStatusCodeValue() ;
        if (statusCode == HttpStatus.SC_OK) {
            logger.warn("上传文件到电子卷宗，ajxh: {}, wjmc: {}, response:" + result, ajxh, wjmc);
        } else {
            logger.error("上传文件到电子卷宗失败，ajxh:" + ajxh + ", wjmc:" + wjmc + ", statusLine:" + result.getBody().toString());
            throw new BaseException("上传文件到电子卷宗失败，ajxh:" + ajxh + ", wjmc:" + wjmc + ", statusLine:" + result.getBody().toString()) ;
        }
    }


    /**构造文件所属目录Id-文件list
     * ssmlId-wjs
     * @param wjs
     * @return
     */
    private Map<String,List<WdModel>> fomateWdMap(String fydm,List<DzjzWdWjDO> wjs){
        if(wjs==null || wjs.isEmpty()) {
            return null;
        }
        Map<String,List<WdModel>> wjMap = new HashMap<>() ;
        for(DzjzWdWjDO wj:wjs){
            List<WdModel> theWjs = wjMap.get(wj.getWjssml()) ;
            if(theWjs==null){
                theWjs = new ArrayList<>() ;
            }
            theWjs.add(DzjzConvertor.wjDO2WjModel(fydm,wj)) ;
            wjMap.put(wj.getWjssml(),theWjs) ;
        }
        //排序
        for(String key:wjMap.keySet()){
            Collections.sort(wjMap.get(key), new Comparator<WdModel>() {
                @Override
                public int compare(WdModel o1, WdModel o2) {
                    return o1.getWjsx()-o2.getWjsx();
                }
            });
        }
        return wjMap ;
    }

    /**
     * 递归构造目录model
     * @param fmlId 父目录id
     * @param mls 所有目录列表
     * @param wdMap 文件所属目录Id-文件list
     * @return
     */
    private List<MlModel> fomateMl(String fmlId, List<DzjzWdMlDO> mls, Map<String,List<WdModel>> wdMap){

        if(mls==null||mls.isEmpty()) {
            return null;
        }

        List<MlModel> mlModelList = null ;

        for(DzjzWdMlDO ml:mls){
            if(StringUtil.equals(ml.getFmlid(),fmlId)) {
                MlModel mlModel = DzjzConvertor.mlDO2MlModel(ml) ;

                //获取子目录
                List<MlModel> zml = fomateMl(mlModel.getId(),mls,wdMap) ;
                if(zml==null || zml.isEmpty()){
                    //若是目录叶节点，判断是否有文档
                    if(wdMap!=null && !wdMap.isEmpty()) {
                        List<WdModel> wdModels = wdMap.get(mlModel.getId());
                        if(wdModels==null||wdModels.isEmpty()){
                            //若子文档也为空，则跳过，不将目录放入
                            continue;
                        }else {
                            mlModel.setWds(wdModels);
                        }
                    }
                }
                mlModel.setZml(zml);


                if(mlModelList==null) {
                    mlModelList = new ArrayList<>();
                }
                mlModelList.add(mlModel);
            }
        }
        if(mlModelList!=null){
            //排序
            Collections.sort(mlModelList, new Comparator<MlModel>() {
                @Override
                public int compare(MlModel o1, MlModel o2) {
                    return o1.getXssx()-o2.getXssx();
                }
            });
        }
        return mlModelList ;
    }
}
