package cn.edu.nju.software.service.model;

import cn.edu.nju.software.util.StringUtil;
import lombok.Data;
import lombok.Getter;

/**
 * 当事人个人
 * @author 13314
 * @date 2018/8/8
 */
@Getter
public class DsrGr extends Dsr{
    /**
     * 性别
     */
    private String xb ;
    /**
     * 名族
     */
    private String mz ;
    /**
     * 出生日期
     */
    private String csrq ;

    /**
     * 证件类别
     */
    private String zjlb ;
    /**
     * 证号
     */
    private String sfzh ;

    /**
     * 籍贯代码
     */
    private String jgdm ;
    /**
     * 籍贯
     */
    private String jg ;
    public void setXb(String xb) {
        if(!StringUtil.isEmpty(xb)){
            this.xb = xb.trim();
        }
    }

    public void setMz(String mz) {
        if(!StringUtil.isEmpty(mz)) {
            this.mz = mz.trim();
        }
    }

    public void setCsrq(String csrq) {
        if(!StringUtil.isEmpty(csrq)) {
            this.csrq = csrq.trim();
        }
    }

    public void setSfzh(String sfzh) {
        if(!StringUtil.isEmpty(sfzh)) {
            this.sfzh = sfzh.trim();
        }
    }

    public void setZjlb(String zjlb) {
        if(!StringUtil.isEmpty(zjlb)){
            this.zjlb = zjlb.trim();
        }
    }

    public void setJgdm(String jgdm) {
        if(!StringUtil.isEmpty(jgdm)){
            this.jgdm = jgdm.trim();
        };
    }

    public void setJg(String jg) {
        if(!StringUtil.isEmpty(jg)){
            this.jg = jg.trim();
        };
    }
}
