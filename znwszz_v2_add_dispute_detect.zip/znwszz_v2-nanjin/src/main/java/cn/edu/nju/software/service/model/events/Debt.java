package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:53
 * @Description
 */
public class Debt extends BaseEvent {
    private String creditor ;
    private String value ;

    public Debt(HashMap<String ,Object> map){
        super(map);
        this.creditor = (String) map.get("creditor");
        this.forRendaring.add((ArrayList<Integer>) map.get("creditor_index_pair")) ;

        this.value = (String) map.get("value");
        this.forRendaring.add((ArrayList<Integer>) map.get("value_index_pair")) ;
    }
    @Override
    /**
     * negated: trigger creditor value
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }

        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.creditor!=null && this.creditor.length()>0){
            str = str +" "+this.creditor ;
        }
        if(this.value!=null && this.value.length()>0){
            str = str +" "+this.value ;
        }
        this.title = str ;
    }
}
