package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DsrQtsscyrGxDO;
import cn.edu.nju.software.data.dataobject.DsrQtsscyrGxDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/15.
 */
@Repository
public interface DsrQtsscyrGxDao extends JpaRepository<DsrQtsscyrGxDO,DsrQtsscyrGxDOId> {
    List<DsrQtsscyrGxDO> findByAjxh(int ajxh) ;
}
