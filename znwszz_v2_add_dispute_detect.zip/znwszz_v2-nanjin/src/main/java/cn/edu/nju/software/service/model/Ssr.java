package cn.edu.nju.software.service.model;

import lombok.Data;

import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/10/10
 * @time 10:01
 * @Description 诉讼人
 *  诉讼人、当事人、其他诉讼参与人结构：
 *      诉讼人-代表处于某个诉讼地位的一类人，比如原告，被告，上诉人，被上诉人
 *      当事人-代表具有某个诉讼地位的单个当事人，比如具体的原告李某，被告XXX公司
 *      其他诉讼参与人-代表与某个当事人相关参与人，比如被告XXX公司的法定代表人，被告XXX公司的委托代理人
 *   因此结构是：
 *      Ssr{
 *          dsrs:List<Dsr>
 *      }
 *      Dsr{
 *          qtsscyrs:List<Qtsscyr>
 *      }
 */
@Data
public class Ssr {
    /**
     * 诉讼地位名称
     */
    private String ssdwmc ;
    /**
     * 诉讼地位代码,
     */
    private String ssdwdm ;

    private List<Dsr> dsrs ;
}
