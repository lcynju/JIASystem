package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:53
 * @Description
 */
public class Wealth extends BaseEvent {
    private String value ;
    private String isCommon ;
    private String isPersonal ;
    private String whose ;

    public Wealth(HashMap<String,Object> map){
        super(map);
        this.value = (String) map.get("value");
        this.forRendaring.add((ArrayList<Integer>) map.get("value_index_pair")) ;

        this.isCommon = (String) map.get("isCommon");
        this.forRendaring.add((ArrayList<Integer>) map.get("isCommon_index_pair")) ;

        this.isPersonal = (String) map.get("isPersonal");
        this.forRendaring.add((ArrayList<Integer>) map.get("isPersonal_index_pair")) ;

        this.whose = (String) map.get("whose");
        this.forRendaring.add((ArrayList<Integer>) map.get("whose_index_pair")) ;
    }
    @Override
    /**
     * negated: trigger value isCommon/whose isPersonal
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.value!=null && this.value.length()>0){
            str = str+" "+this.value ;
        }

        if(this.isCommon!=null && this.isCommon.length()>0){
            str = str+" "+this.isCommon ;
        }else{
            if(this.whose!=null && this.whose.length()>0){
                str = str+" "+this.whose ;
            }
            if(this.isPersonal!=null && this.isPersonal.length()>0){
                str = str+" "+this.isPersonal ;
            }
        }
        this.title = str ;
    }
}
