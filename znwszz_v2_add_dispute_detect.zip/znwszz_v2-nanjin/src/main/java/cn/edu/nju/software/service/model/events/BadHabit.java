package cn.edu.nju.software.service.model.events;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:49
 * @Description
 */
public class BadHabit extends BaseEvent{
    private String person ;

    public BadHabit(HashMap<String,Object> map){
        super(map);
        this.person = (String) map.get("person");
        this.forRendaring.add((ArrayList<Integer>) map.get("person_index_pair")) ;
    }
    @Override
    /**
     * negated: person trigger
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.person!=null && this.person.length()!=0){
            if(str.length()>0){
                str =str +" "+ this.person ;
            }else {
                str = this.person ;
            }
        }
        if(str.length()>0){
            str = str+" "+this.trigger ;
        }else {
            str = this.trigger ;
        }

        this.title = str;
    }
}
