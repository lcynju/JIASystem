package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.PubSsxxDO;
import cn.edu.nju.software.data.dataobject.PubSsxxDOId;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 10:23
 * @Description
 */
public interface SsxxDao extends JpaRepository<PubSsxxDO,PubSsxxDOId> {
    PubSsxxDO findByAjxh(int ajxh) ;
}
