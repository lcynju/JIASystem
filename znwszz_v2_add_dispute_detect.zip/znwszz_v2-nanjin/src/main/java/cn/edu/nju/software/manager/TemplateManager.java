package cn.edu.nju.software.manager;

import cn.edu.nju.software.data.dao.FtnqFtsysqdjDao;
import cn.edu.nju.software.data.dao.LalascxxDao;
import cn.edu.nju.software.data.dao.PubAjJbDao;
import cn.edu.nju.software.data.dao.SpryDao;
import cn.edu.nju.software.data.dataobject.FtnqFtsysqdjDO;
import cn.edu.nju.software.data.dataobject.LaLascxxDO;
import cn.edu.nju.software.data.dataobject.PubAjJbDO;
import cn.edu.nju.software.data.dataobject.SpryDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.AyDmbService;
import cn.edu.nju.software.service.DmbService;
import cn.edu.nju.software.service.DsrService;
import cn.edu.nju.software.service.model.AydmModel;
import cn.edu.nju.software.service.model.DmbModel;
import cn.edu.nju.software.service.model.Dsr;
import cn.edu.nju.software.service.model.Ssr;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.DateUtil;
import cn.edu.nju.software.util.NumberUtil;
import cn.edu.nju.software.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.*;

/**
 *  模板构造manager
 * @author 13314
 * @date 2018/8/15
 */
@Component
public class TemplateManager {
    @Autowired
    private PubAjJbDao ajRepostiy ;
    @Autowired
    private DsrService dsrService ;
    @Autowired
    private AyDmbService ayDmbService ;
    @Autowired
    private DmbService dmbService ;

    @Autowired
    private SpryDao spryDao ;
    @Autowired
    private FtnqFtsysqdjDao ftnqFtsysqdjDao;
    @Autowired
    private LalascxxDao lalascxxDao ;
    private static final String SYCX_LBBH = "FBS0042-97" ;
    /**
     * 获取创建模板所需信息
     * @param fydm
     * @param ajxh
     * @return
     */
    public Map<String,Object> getTemplateData(String fydm,int ajxh, int ktbh){
        Map<String,Object> data = new HashMap<>() ;
        /**
         * 法院名称
         */
        data.put("fymc", FyEnum.findByFydm(fydm).getName()) ;

        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        PubAjJbDO ajJb = ajRepostiy.findByAjxh(ajxh);

        if(ajJb==null){
            throw new BaseException("获取案件关联模板信息识别，案件序号无效，无对应案件(fydm:"+fydm+",ajxh:"+ajxh+")") ;
        }
        /**
         * 案号
         */
        data.put("ah",ajJb.getAh().trim()) ;
        /**
         * 控诉机关（刑事公诉案件适用）,若无则默认位 人民检查院
         */
        data.put("gsjg",ajJb.getGksjg()==null?" 人民检查院":StringUtil.trim(ajJb.getGksjg())) ;

        /**
         * 收到诉状日期
         */
        LaLascxxDO laLascxxDO = lalascxxDao.findByAjxh(ajxh);
        if(laLascxxDO!=null&&laLascxxDO.getSdszrq()!=null){
            data.put("sdszrq",DateUtil.format(laLascxxDO.getSdszrq(),DateUtil.chineseDtFormat)) ;
        }else {
            data.put("sdszrq"," 年 月 日") ;
        }


        /**
         * 当事人信息
         *
         */
        getDsrXx(data,fydm,ajxh);

        /**
         * 立案案由
         */
        List<AydmModel> laAyModels = ayDmbService.getAydmByAjxh(fydm, ajxh);
        String ls_ay = "" ;
        if(laAyModels!=null&&!laAyModels.isEmpty()){
            for(AydmModel ayModel:laAyModels){
                ls_ay = ls_ay+ayModel.getDmms()+"," ;
            }
            if(!StringUtil.isEmpty(ls_ay)) {
                ls_ay = ls_ay.substring(0, ls_ay.length() - 1);
            }
        }
        data.put("ay",ls_ay) ;

        /**
         * 立案日期
         */
        data.put("larq", DateUtil.format(ajJb.getLarq(),DateUtil.chineseDtFormat)) ;

        /**
         * 适用程序
         */
        DmbModel sycxModel = dmbService.getDmModelByLbbhAndDmbh(fydm, SYCX_LBBH, ajJb.getSycx());
        data.put("sycx",sycxModel.getDmms()) ;

        /**
         * 开庭信息
         */
        getKtxx(data,ajxh,ktbh);

        /**
         * 上级法院
         */
        data.put("sjfy",FyEnum.getSjFyMc(fydm)) ;

        /**
         * 审判人员信息
         */
        getSpryxx(data,fydm,ajxh);

        /**
         * 审判日期，默认当前
         */
        data.put("sprq", DateUtil.formateDateToCH(new Date())) ;

        DynamicDataSource.router(curDB);
        return data ;
    }

    /**
     * 构造当事人信息
     * @param data
     * @param fydm
     * @param ajxh
     */
    private void getDsrXx(Map<String,Object> data,String fydm,int ajxh){

        List<Ssr> dsrXx = dsrService.getDsrXxByAjxh(fydm, ajxh);
        Assert.notNull(dsrXx,String.format("当事人信息不能为空,fydm:%s,ajxh:%s",fydm,ajxh));
        data.put("dsrXx",dsrXx) ;

        /**
         * 构造原告、被告名称
         * 包括两种形式，
         * 1，XXX、XXX
         * 2，原告XXX、原告XXX；被告XXX，被告XXX
         */
        StringBuilder dsrmcBuilder = new StringBuilder() ;
        StringBuilder dsrmc2Builder = new StringBuilder() ;

        StringBuilder ygmcBuilder = new StringBuilder() ;
        ygmcBuilder.append("") ;
        StringBuilder bgmcBuilder = new StringBuilder() ;
        bgmcBuilder.append("") ;
        for(Ssr ssr:dsrXx) {
            String key = ssr.getSsdwmc();
            /**
             * 构造原被告名称
             */
            if (ssr.getDsrs() != null && !ssr.getDsrs().isEmpty()) {
                dsrmcBuilder.append(ssr.getDsrs().get(0).getMc());
                dsrmc2Builder.append(key).append(ssr.getDsrs().get(0).getMc());
                for (int i = 1; i < ssr.getDsrs().size(); i++) {
                    dsrmcBuilder.append("、" + ssr.getDsrs().get(i).getMc());
                    dsrmc2Builder.append("、" + key + ssr.getDsrs().get(i).getMc());
                }
                data.put(key,dsrmcBuilder.toString());
                data.put(key+"2",dsrmc2Builder.toString()) ;

                /**
                 * 清楚历史记录
                 */
                dsrmcBuilder.delete(0,dsrmcBuilder.length()) ;
                dsrmc2Builder.delete(0,dsrmc2Builder.length()) ;
            }
            /**
             * 构造被告人数
             */
            if(StringUtil.contains(ssr.getSsdwmc(),"被告")){
                data.put("bgs", NumberUtil.numberToCH(ssr.getDsrs().size())) ;
            }
            /**
             * 构造原告、被告名称
             */
            if(StringUtil.contains(ssr.getSsdwmc(),"原告")||(StringUtil.contains(ssr.getSsdwmc(),"上诉人")&&!StringUtil.contains(ssr.getSsdwmc(),"被"))){
                if(ssr.getDsrs()!=null&&!ssr.getDsrs().isEmpty()){
                    for(Dsr dsr:ssr.getDsrs()){
                        ygmcBuilder.append(dsr.getMc()+",") ;
                    }
                }
            }else if(StringUtil.contains(ssr.getSsdwmc(),"被告")||StringUtil.contains(ssr.getSsdwmc(),"被")){
                if(ssr.getDsrs()!=null&&!ssr.getDsrs().isEmpty()){
                    for(Dsr dsr:ssr.getDsrs()){
                        bgmcBuilder.append(dsr.getMc()+",") ;
                    }
                }
            }
        }
        data.put("bgmc",bgmcBuilder.toString()) ;
        data.put("ygmc",ygmcBuilder.toString()) ;
    }

    /**
     * 获取开庭信息
     * @param data
     * @param ajxh
     * @param ktbh
     */
    private void getKtxx(Map<String,Object> data,int ajxh,int ktbh){
        List<FtnqFtsysqdjDO> ktxx = ftnqFtsysqdjDao.findByAjxh(ajxh);
        if (ktxx.size() > ktbh) {
            FtnqFtsysqdjDO sqxx = ktxx.get(ktbh);
            /**
             * 开庭时间
             */
            if (sqxx.getRq() != null) {
                data.put("ktsj",DateUtil.format(sqxx.getRq(),DateUtil.chineseDtFormat));
            } else {
                data.put("ktsj","");
            }
            /**
             * 开庭地点
             */
            if (sqxx.getRq() != null) {
                data.put("ktdd",sqxx.getSjft());
            } else {
                data.put("ktdd","");
            }
            /**
             * 是否公开审理
             * 旁听人数
             */
            if (sqxx.getSfgkkt() != "Y") {
                data.put("sfgksl","否");
                data.put("ptrs",null);
            } else {
                data.put("sfgksl","是");
                if (sqxx.getPtrs() != null) {
                    data.put("ptrs",sqxx.getPtrs() + "人");
                } else {
                    data.put("ptrs","");
                }
            }
        }
    }

    /**
     * 获取审判庭组成
     * @param data
     * @param fydm
     * @param ajxh
     */
    private void getSpryxx(Map<String,Object> data,String fydm,int ajxh){
        List<SpryDO> spryDOS = spryDao.findByAjxh(ajxh);
        Assert.notNull(spryDOS, String.format("审判人员信息不能为空,fydm:%s,ajxh:%s",fydm,ajxh));

        //遍历判断审判人员职责，包括审判长、审判员和法官助理、书记员，
        // 其中审判长、审判员展示在审判日期前，法官助理和书记员展示在审判日期后

        String spry = "";
        List<String> spys = new ArrayList<>() ;
        Map<String,String> spryMap2 = new HashMap<>() ;
        for(SpryDO spryDO:spryDOS){
            if(StringUtil.equals(spryDO.getSfspz(),"Y")){
                //审判长
                spry = spryDO.getXm();
                data.put("spz",spryDO.getXm()) ;
            }else if(StringUtil.equals(spryDO.getFg(),"1")&&!StringUtil.equals(spryDO.getSfcbr(),"Y")&&!StringUtil.equals(spryDO.getSfrmpsy(),"Y")){
                //审判员
                spys.add(spryDO.getXm()) ;
            }else if(StringUtil.equals(spryDO.getFg(),"3")){
                //法官助理
                data.put("fgzl",spryDO.getXm()) ;
            }else if(StringUtil.equals(spryDO.getFg(),"0")){
                //书记员
                data.put("sjy",spryDO.getXm()) ;
            }
        }
        if(!spys.isEmpty()){
            data.put("spys",spys) ;
        }
        /**
         * 是否为合议庭(审判人员>=3)
         */
        if (spys.size() > 1) {
            data.put("sfhyt","合议庭成员");
        } else {
            data.put("sfhyt","审判人员");
        }
        /**
         * 审判人员
         */
        for (String spy : spys) {
            if(StringUtil.isEmpty(spry)){
                spry += spy ;
            }else {
                spry += "、" + spy;
            }
        }
        data.put("spry",spry);
    }
}
