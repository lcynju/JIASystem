package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.YhModel;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
public interface TemplateService {
    /**
     * 获取指定案件关联类模板
     * @param yhModel
     * @param ajxh
     * @param templateBh
     * @param ktbh
     * @return
     */
    DocumentModel getAjglTemplate(YhModel yhModel, int ajxh, int templateBh, int ktbh) ;

    /**
     * 获取通用类模板目录
     * @return
     */
    MlModel getTyTemplateMl();

    /**
     * 获取案件关联类模板目录
     * @param ajxh
     * @return
     */
    MlModel getAjglTemplateMl(String fydm,int ajxh);

    /**
     * 获取当前案件序号的开庭信息
     * @param ajxh
     * @return
     */
    List<String> getKtxxByAjxh(int ajxh);
}
