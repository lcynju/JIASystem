package cn.edu.nju.software.service;


import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.YhCheckResult;

/**
 *  用户service
 * @author 13314
 * @date 2018/7/27
 */
public interface UserService {

    /**
     * 用户登陆接口
     * @param fydm
     * @param userName
     * @param password
     * @return
     */
    YhCheckResult login(String fydm, String userName, String password) ;

    /**
     * 查找特定法院特定用户
     * @param fydm
     * @param yhdm
     * @return
     */
    YhModel findByYhdm(String fydm,String yhdm) ;
}
