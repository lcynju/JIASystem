package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.EventExtractor;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.events.BaseEvent;
import cn.edu.nju.software.service.model.events.DivorceCaseModel;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2019/4/18
 * @time 16:07
 * @Description
 */
@RestController
public class CaseModelingController {
    @Autowired
    private EventExtractor eventExtractor ;
    @Autowired
    private DocumentService documentService ;

    @ApiOperation(value = "获取指定文件的事件抽取结果")
    @ApiImplicitParams({
            @ApiImplicitParam(name="wdId",value = "文档ID",paramType = "query"),
    })
    @GetMapping(value = "/getCaseModeling",produces = "application/json")
    public ResultVO<DivorceCaseModel> getCaseModeling(String wdId){
        ResultVO<DivorceCaseModel> resultVO = new ResultVO<>() ;
        byte[] content = null ;
        try {
            content = documentService.getContent(wdId);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("无法找到该文档："+wdId);
            throw new BaseException("无法找到该文档") ;
        }
        resultVO.setSucceed(true);
        DivorceCaseModel caseModel = eventExtractor.extractorEvents(content);


        resultVO.setObject(caseModel);
        return resultVO ;
    }
}
