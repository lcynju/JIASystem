package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.DocumentModel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by 13314 on 2018/8/23.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TemplateTest {
    @Autowired
    TemplateService templateService ;

    @Autowired
    private freemarker.template.Configuration cfg ;
    @Test
    public void test(){
//        DocumentModel ajglTemplate = templateService.getAjglTemplate("120104 212", 238202, 40, 0);
//        templateService.getAjglTemplate("120104 212", 234964, 45, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 47, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 48, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 49, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 50, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 51, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 52, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 53, 0);
//        templateService.getAjglTemplate("120104 212", 230559, 54, 0);
        System.out.println("end");
    }
}
