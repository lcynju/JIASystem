package cn.edu.nju.software.service.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 13314 on 2018/9/5.
 */
public class PluginModel {
    private String baseUrl ;
    private String guid ;
    private String name ;
    private Variation variations ;
    public PluginModel(String baseUrl,String guid,String name){
        this.baseUrl = baseUrl ;
        this.guid = guid ;
        this.name = name ;
        this.variations.addButton(new Button("OK",true));
        this.variations.addButton(new Button("Cancel",false));
    }

}
class Variation{
    private List<Button> buttons =new ArrayList<>();
    private String description ="chess";
    private String[] EditorsSupport ={"word","cell","slide"};
    private String[] icons ={"chess/icon.png","chess/icon@2x.png"};
    private String intitData ="";
    private String initDataType ="ole";
    private boolean initOnSelectionChanged=true ;
    private boolean isModal=true ;
    private boolean isInsideMode=false ;
    private boolean isUpdateOleOnResize=true ;
    private boolean isViewer = true ;
    private boolean isVisual = true ;
    private String url = "chess/index.html" ;
    public void addButton(Button button){
        this.buttons.add(button) ;
    }
}
class Button{
    private String text ;
    private boolean primary ;

    public Button(String text, boolean primary) {
        this.text = text;
        this.primary = primary;
    }
}
