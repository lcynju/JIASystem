package cn.edu.nju.software.service.model;

import cn.edu.nju.software.util.StringUtil;
import lombok.Data;

/**
 * Created by 13314 on 2018/8/8.
 */
public class DsrDw extends Dsr{
    /**
     * 登记证类别
     */
    private String djzlb ;
    /**
     * 登记证号
     */
    private String djzh ;
    /**
     * 法定代表人
     */
    private String fddbr ;

    /**
     * 代表人职位
     */
    private String dbrzw ;

    public String getDjzlb() {
        return djzlb;
    }

    /**
     * 重写set方法是为了避免这些属性在数据库存储为空字符串:'',以及统一做trim处理
     * @param djzlb
     */
    public void setDjzlb(String djzlb) {
        if(!StringUtil.isEmpty(djzlb)) {
            this.djzlb = djzlb.trim();
        }
    }

    public String getDjzh() {
        return djzh;
    }

    public void setDjzh(String djzh) {
        if(!StringUtil.isEmpty(djzh)) {
            this.djzh = djzh.trim();
        }
    }

    public String getFddbr() {
        return fddbr;
    }

    public void setFddbr(String fddbr) {
        if(!StringUtil.isEmpty(fddbr)) {
            this.fddbr = fddbr.trim();
        }
    }

    public String getDbrzw() {
        return dbrzw;
    }

    public void setDbrzw(String dbrzw) {
        if(!StringUtil.isEmpty(dbrzw)) {
            this.dbrzw = dbrzw;
        }
    }
}
