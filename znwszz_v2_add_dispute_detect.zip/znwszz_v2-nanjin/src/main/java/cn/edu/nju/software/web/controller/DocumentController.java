package cn.edu.nju.software.web.controller;
import cn.edu.nju.software.configuration.properties.DocServiceProperties;
import cn.edu.nju.software.manager.DocumentServerManager;
import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.EventExtractor;
import cn.edu.nju.software.service.WsService;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FileTypeEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.DocumentUtil;
import cn.edu.nju.software.util.StringUtil;
import cn.edu.nju.software.util.UserUtil;
import cn.edu.nju.software.web.vo.ResultVO;
import com.alibaba.fastjson.JSON;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.*;

/**
 *
 * @author 13314
 * @date 2018/8/5
 */
@Api(tags = "文档处理Controller")
@RestController
public class DocumentController {

    private DocumentService documentService;
    private DocumentServerManager documentServerManager ;
    private DocServiceProperties docServicePro ;
    @Autowired
    private WsService wsService ;
    private Logger logger = LoggerFactory.getLogger(DocumentController.class) ;
    @Autowired
    private EventExtractor eventExtractorImpl ;
    /**
     * 创建空白文档的默认名称
     */
    private final String EMPTY_FILE_NAME = "新建文档.docx" ;

//    @Autowired
//    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    public DocumentController(DocumentService documentService, DocumentServerManager documentServerManager,
                              DocServiceProperties docServicePro){
        this.documentService = documentService ;
        this.documentServerManager = documentServerManager ;
        this.docServicePro = docServicePro ;
    }

    @ApiOperation(value = "获取documentServer服务的js地址")
    @GetMapping("/getDocumentServerApi")
    public String getDocumentServerApi(){
        return docServicePro.getApiUrl() ;
    }

    @ApiOperation(value = "获取空白文档实例接口")
    @GetMapping(value = "/getEmptyDocx",produces = "application/json")
    public ResultVO<DocumentModel> createEmptyDocx(HttpServletRequest request){
        String remoteAddr = request.getRemoteAddr();
        DocumentModel emptyDocument = documentService.saveDocumentByYhmodeAndIpAddress((YhModel) request.getSession().getAttribute("user"),
                remoteAddr,EMPTY_FILE_NAME,null) ;
        ResultVO resultVO = new ResultVO<DocumentModel>() ;
        resultVO.setSucceed(true);
        resultVO.setObject(emptyDocument);
        return resultVO ;
    }


    @ApiOperation(value = "上传文档接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "type",value="针对目标文档的操作类型,包括：view,edit。对应查看，编辑",required=true,paramType = "query")
    })
    @PostMapping(value = "/upload",produces = "application/json",headers="content-type=multipart/form-data")
    public ResultVO<DocumentModel> upload(@ApiParam(value = "目标文档",required = true)MultipartFile file, String type,HttpServletRequest request){
        ResultVO result = new ResultVO<DocumentModel>() ;
        String submittedFileName = null;
        try {
            submittedFileName = URLDecoder.decode(file.getOriginalFilename(),"utf-8");
            //documentServer转换程序对文件名含空格的敏感
            submittedFileName = StringUtil.replace(submittedFileName," ","") ;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            logger.error("上传文件名解码失败，错误信息："+e.getMessage());
            throw new BaseException("文件上传失败，文件名错误") ;
        }

        //检查文件格式是否支持
        String ext = DocumentUtil.getFileExtension(submittedFileName) ;
        FileTypeEnum fileTypeEnum = FileTypeEnum.findBySuffixName(ext);
        if(fileTypeEnum==null){
            result.setSucceed(false);
            result.setMessage("文件格式不支持");
            return result ;
        }
        /**
         * 通过文件头判断文件的实际类型和文件的后缀名格式是否匹配
         */
//        try {
//            boolean b = DocumentUtil.checkSuffixAndFileHeader(file.getInputStream(), fileTypeEnum.getFileHeader());
//            if(!b){
//                throw new BaseException("文件实际类型和文件后缀名不匹配，请确定文件真正格式") ;
//            }
//        } catch (IOException e) {
//            e.printStackTrace();
//            throw new BaseException("上传文件无法打开，请联系管理员") ;
//        }
        //存储文件
        byte[] content = null;
        try {
            content = file.getBytes();
        } catch (IOException e) {
            e.printStackTrace();
        }
        DocumentModel documentModel = documentService.saveDocumentByYhmodeAndIpAddress((YhModel) request.getSession().getAttribute("user"),
                request.getRemoteAddr(),submittedFileName,content) ;
        //判断文件是否需要转换
        switch (type){
            case "view":
                result.setSucceed(true);
                result.setObject(documentModel);
                break ;
            case "edit":
                if (fileTypeEnum.equals(FileTypeEnum.PDF)) {
                    //判断是否文件只支持view
                    result.setSucceed(true);
                    result.setMessage("文件上传成功，但该文件只支持view模式");
                } else if (FileTypeEnum.ifNeedConverted(fileTypeEnum)) {
                    //判断是否需要进行文件格式转换
                    documentModel = documentServerManager.convert(documentModel);
                    result.setSucceed(true);
                    result.setMessage("文件上传成功，且文件转换为可编辑格式");
                }else {
                    result.setSucceed(true);
                }
                break;
            default:
                ;
        }
        result.setObject(documentModel);
        return result ;
    }

    @ApiOperation(value = "下载文档接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId",value = "目标文档Id",required = true,paramType = "query")
    })
    @GetMapping(value = "/download",produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public void download(HttpServletRequest request,HttpServletResponse response,String wdId){

        /**
         * 下载目标文档包括：本地文档、文书基表文档，通过wdId前缀区分
         */
        if(StringUtil.isEmpty(wdId)){
            throw new BaseException("文档id不能为空") ;
        }

        if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
            documentService.download(response,wdId); ;
        }else if(wdId.startsWith(DocSourceEnum.WSXX.getPrefix())){
            wsService.downloadWs(response,wdId);
        }


    }

    @ApiOperation(value = "更新文档接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId",value = "目标文档名",required = true,paramType = "query")
    })
    @PostMapping(value="/save")
    public void save(HttpServletRequest request,HttpServletResponse response){
        response.setContentType("text/plain; charset=utf-8");
        PrintWriter writer = null;
        String wdId = request.getParameter("wdId") ;
        try {
            writer = response.getWriter();

            Scanner scanner = new Scanner(request.getInputStream()).useDelimiter("\\A");
            String body = scanner.hasNext() ? scanner.next() : "";

            ObjectMapper mapper = new ObjectMapper() ;
            HashMap hashMap = mapper.readValue(body, HashMap.class);

            if((int) hashMap.get("status") == 2||(int)hashMap.get("status") == 6) {
                String downloadUri = (String) hashMap.get("url");

                URL url = new URL(downloadUri);
                java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
                InputStream stream = connection.getInputStream();

                //获取并删除原文件
                if(StringUtil.isEmpty(wdId)){
                    throw new Exception("文档id为空") ;
                }
                //目前回调写入更新文档只对本地文档支持
                byte[] content = new byte[stream.available()] ;
                stream.read(content) ;
                if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
                    documentService.updateFileContect(content,wdId);
                }
                stream.close();
                connection.disconnect();
            }
            response.setStatus(200);
            writer.write("{\"error\":0}");
        }catch (Exception e){
            response.setStatus(500);
            writer.write("{\"error\":"+e.getMessage()+"}");
            logger.error("documentServer回调更新文档失败"+wdId+e.getMessage());
            logger.error(e.getMessage());
        }
    }

    @ApiOperation(value = "文书纠错接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId",value = "纠错目标文档Id",required = true)
    })
    @GetMapping("/wsjc")
    public String wsjc(String wdId){
        String wsjcUrl = documentService.wsjc(wdId);
        logger.info("获取文书纠错url，传给前台使用ie浏览器打开文书纠错界面。url:"+wsjcUrl);
        return wsjcUrl ;
    }

    @GetMapping("/getWsjcResult")
    @ApiOperation(value = "获取文书纠错结果model")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId",value = "目标文档id",required = true)
    })
    public ResultVO<DocumentModel> getResultOfWsjc(String wdId){
        ResultVO resultVO = new ResultVO<DocumentModel>() ;
        DocumentModel wsjcResult = documentService.getWsjcResult(wdId);
        if(wsjcResult==null){
            resultVO.setSucceed(false);
            resultVO.setMessage("该文档还没纠错完成，或文档id错误");
        }else{
            resultVO.setSucceed(true);
            resultVO.setObject(wsjcResult);
        }
        return resultVO ;
    }

    @PostMapping("/saveDocumentModelList")
    public ResultVO saveDocumentModel(HttpServletRequest request, @RequestBody HashMap<String, DocumentModel> documentModels){
        YhModel user = UserUtil.checkUserLogin(request);
        String redis_key = user.getDm() + "document_model";
        //System.out.println(documentModels.size());
        Set<String> keySet = documentModels.keySet();
        for(String key: keySet){
//            stringRedisTemplate.opsForHash().put(redis_key, key, JSON.toJSONString(documentModels.get(key)));
        }
        ResultVO resultVO = new ResultVO();
        resultVO.setSucceed(true);
        resultVO.setMessage("缓存Model成功");
        return resultVO;
    }

    @GetMapping("/deleteDocumentModel")
    public ResultVO deleteDocumentModel(HttpServletRequest request, String document_key){
        YhModel user = UserUtil.checkUserLogin(request);
        String redis_key = user.getDm() + "document_model";
//        Long result = stringRedisTemplate.opsForHash().delete(redis_key, document_key);
        ResultVO resultVO = new ResultVO();
//        resultVO.setSucceed(true);
//        resultVO.setMessage(String.valueOf(result));
        return resultVO;
    }

    @GetMapping("/getDocumentModelList")
    public List<ResultVO> getDocumentModelList(HttpServletRequest request){
        YhModel user = UserUtil.checkUserLogin(request);
        String redis_key = user.getDm() + "document_model";
//        Map<Object, Object> DocumentMap = stringRedisTemplate.opsForHash().entries(redis_key);
        List<ResultVO> resultVOS = new ArrayList<>();
//        Set<Object> keySet = DocumentMap.keySet();
//        for (Object Key: keySet){
//            String key = (String) Key;
//            DocumentModel model = JSON.parseObject((String)DocumentMap.get(key), DocumentModel.class);
//            ResultVO resultVO = new ResultVO();
//            resultVO.setObject(model);
//            resultVO.setMessage(key);
//            resultVO.setSucceed(true);
//            resultVOS.add(resultVO);
//        }
        return resultVOS;
    }

    @ApiOperation(value = "获取当前用户文件名list")
    @GetMapping("/getFileNamesList")
    public ResultVO<String[]> getFileNamesList(HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        String[] fileNamesListByYhmodelAndIpAddress = documentService.getFileNamesListByYhmodelAndIpAddress(user, request.getRemoteAddr());
        ResultVO<String[]> resultVO = new ResultVO<>();
        resultVO.setSucceed(true);
        resultVO.setObject(fileNamesListByYhmodelAndIpAddress);
        return resultVO ;
    }

    @ApiOperation(value = "根据文件名获取documentModel")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "fileName",value = "目标文件名称",required = true)
    })
    @GetMapping("/getDocumentModelByFileName")
    public ResultVO<DocumentModel> getDocumentModelByFileName(String fileName,HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        DocumentModel documentByYhmodeAndIpAddressAndFileName = documentService.getDocumentByYhmodeAndIpAddressAndFileName(user, request.getRemoteAddr(), fileName);
        ResultVO<DocumentModel> resultVO = new ResultVO<>() ;
        resultVO.setSucceed(true);
        resultVO.setObject(documentByYhmodeAndIpAddressAndFileName);
        return resultVO ;
    }

    @ApiOperation(value = "根据文件名删除用户本地文档")
    @ApiImplicitParams({
            @ApiImplicitParam(name="fileName",value="目标文件名称",required = true)
    })
    @GetMapping("/deleteFileByFileName")
    public void deleteDocumentByFileName(String fileName,HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        documentService.deleteDocumentByYhmodelAndIpAddress(user, request.getRemoteAddr(), fileName);
    }

    @ApiOperation(value = "更新文件名称")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "targetFileName" ,value = "更名目标文件名称",required = true) ,
            @ApiImplicitParam(name = "newFileName",value = "文件新名称",required = true) ,
    })
    @GetMapping("/updateFileName")
    public ResultVO<DocumentModel> updateFileName(String targetFileName,String newFileName,HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        ResultVO<DocumentModel> resultVO = new ResultVO<>() ;
        try {
            DocumentModel documentModel = documentService.updateDocumentNameByYhmodelAndIpAddress(user, request.getRemoteAddr(), targetFileName, newFileName);
            resultVO.setSucceed(true);
            resultVO.setObject(documentModel);
        }catch (BaseException e){
            resultVO.setSucceed(false);
            resultVO.setMessage(e.getMessage());
        }
        return resultVO ;
    }
}
