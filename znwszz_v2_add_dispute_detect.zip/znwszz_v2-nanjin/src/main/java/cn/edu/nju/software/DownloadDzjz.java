package cn.edu.nju.software;

import cn.edu.nju.software.data.dao.PubWsJbDao;
import cn.edu.nju.software.service.AjService;
import cn.edu.nju.software.service.DzjzWjService;
import cn.edu.nju.software.service.WsService;
import cn.edu.nju.software.service.model.AjModel;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author 13314409603@163.com
 * @date 2018/10/29
 * @time 18:30
 * @Description
 */
//@Component
public class DownloadDzjz implements CommandLineRunner{
    @Autowired
    DzjzWjService dzjzWjService ;
    @Autowired
    AjService ajService ;

    static DzjzWjService dzjzWjService2 ;
    static String fybh = null ;
    static Map<String, ArrayList<String>> ocrResult = null ;
    static RestTemplate restTemplate  = new RestTemplate() ;
    public void downland() throws IOException {
        dzjzWjService2 = dzjzWjService ;

        //下载文件存储根目录
        String location = "E:\\rawMaterial" ;
        String begin = "2016/1/1" ;
        String end = "2018/12/1" ;

        //总共只需要1000个以上
        int totalTarget = 1000 ;
        //实际数量
        int totalNum = 0 ;
        for (FyEnum fyEnum : FyEnum.values()) {
            //高院无一审案件，直接跳过
            if(fyEnum.equals(FyEnum.TJGY)){
                continue;
            }
            //每家法院最多200个
            int targetNum = 200 ;
            //记录当前法院已经下载多少个
            int num = 0 ;
            fybh = fyEnum.getFybh();
            //当前法院存储地址
            String dir = location+File.separator+fyEnum.getName() ;
            //获取案件列表
            List<AjModel> yjajList = ajService.findByAy(fyEnum.getFydm(),"离婚纠纷",begin,end);
            for (AjModel ajModel : yjajList) {
                //只取民事一审的
                if (!StringUtil.equals(ajModel.getSpcx().trim(), "1")&&!StringUtil.equals(ajModel.getAjxz().trim(), "2")) {
                    continue;
                }
                /**
                 * 创建案号为名称的文件夹
                 */
                String path = dir + File.separator + ajModel.getAh();

                //下载电子卷宗文档
                /**
                 * 获取这个案件的ocr识别结果
                 */
                ocrResult = null;
                try {
                    ocrResult = dzjzWjService.getOcrResult(ajModel.getAjxh(), fyEnum.getFydm());
                }catch(Exception e){
                    e.printStackTrace();
                }
                /**
                 * 获取文件夹和文件信息
                 */
                MlModel ml = dzjzWjService.getDzjzMlByAjxh(fyEnum.getFydm(), ajModel.getAjxh());

                /**
                 * 下载文档
                 */
                getWd(path, ml);
                num++ ;
                if(num>=targetNum){
                    break;
                }
            }
            System.out.println(fyEnum.getJc()+"总计:"+num);
            totalNum+=num ;
            if(totalNum>totalTarget){
                break;
            }
        }
        System.out.println("总计："+totalNum);
    }

    private static void getWd(String parentPath,MlModel ml){
        if(ml==null){
            return;
        }
        //只下载电子卷宗下的裁判文书、立案材料、庭审笔录
        if(ml.getMc().contains("电子卷宗")||ml.getMc().contains("正卷")||ml.getMc().contains("裁判文书")||ml.getMc().contains("立案相关材料")||ml.getMc().contains("庭审")||ml.getMc().contains("笔录")){
            ;
        }else {
            return;
        }
        /**
         * 每个目录对于一个文件夹
         */
        String dirPath = parentPath+File.separator+ml.getMc() ;
        File file = new File(dirPath) ;
        if(ml.getZml()!=null&&!ml.getZml().isEmpty()){
            file.mkdirs() ;
            /**
             * 如果有子目录则递归调用
             */
            for(MlModel mlModel:ml.getZml()){
                getWd(dirPath,mlModel);
            }
        }else if(ml.getWds()!=null&&!ml.getWds().isEmpty()){
            file.mkdirs() ;
            /**
             * 下载文件
             */
            List<WdModel> wds = ml.getWds();
            for (WdModel wdModel:wds){
                makeFile(dirPath,wdModel) ;
            }
        }
    }
    private static void makeFile(String dirPath,WdModel wdModel){
        try {
            String filePath = dirPath+ File.separator+wdModel.getMc() ;
            DocumentModel dzjzDocumentModel = dzjzWjService2.getDzjzDocumentModel(wdModel.getId());
            String url = dzjzDocumentModel.getUrl();
            ResponseEntity<byte[]> exchange = restTemplate.exchange(url, HttpMethod.GET, null, byte[].class);
            File file = new File(filePath) ;
            try {
                FileOutputStream fos = new FileOutputStream(file) ;
                fos.write(exchange.getBody());
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            /**
             * 如果是图片则新建一个txt存储识别结果
             */
            if(wdModel.getMc().endsWith(".jpg")||wdModel.getMc().endsWith(".jpeg")){
                getOcr(filePath,dzjzDocumentModel.getWdId());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private static void getOcr(String filePath,String wdId){
        String[] split = wdId.split("_");
        String key = FyEnum.findByFydm(split[1]).getFybh() + "_0_" + split[2] ;
        if(ocrResult==null){
            return;
        }
        ArrayList<String> strings = ocrResult.get(key);
        if(strings!=null&&!strings.isEmpty()){
            String newName = filePath.substring(0,filePath.lastIndexOf("."))+"_ocr.txt" ;
            File newFile = new File(newName) ;
            try {
                FileOutputStream fos = new FileOutputStream(newFile) ;
                fos.write(strings.get(0).getBytes("UTF-8"));
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void run(String... strings) throws Exception {
        downland();
    }
}
