package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DsrJbDO;
import cn.edu.nju.software.data.dataobject.DsrJbDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/10
 */
@Repository
public interface DsrJbDao extends JpaRepository<DsrJbDO,DsrJbDOId> {
    List<DsrJbDO> findByAjxh(int ajxh) ;
}
