package cn.edu.nju.software.service.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/9/21
 * @time 9:28
 * @Description
 */
@Data
@ToString
@ApiModel
public class FyModel {
    @ApiModelProperty(value = "法院名称")
    private String fymc ;
    @ApiModelProperty(value = "法院代码，具有唯一性")
    private String fydm ;
    @ApiModelProperty(value = "法院简称")
    private String fyjc ;
    @ApiModelProperty(value = "下级法院")
    private List<FyModel> xjFy ;

    public FyModel(){

    }
    public FyModel(String fymc, String fydm, String fyjc) {
        this.fymc = fymc;
        this.fydm = fydm;
        this.fyjc = fyjc;
    }
}
