webService接口，
自动生成要调用的接口类可使用命令：wsimport -s 目标文件夹 wsdl访问url
如： wsimport -s . http://130.39.112.42:8604/LawyeeService/LawyeeCheck.asmx?wsdl