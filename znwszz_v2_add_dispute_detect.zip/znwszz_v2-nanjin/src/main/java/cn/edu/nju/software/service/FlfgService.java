package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.FlfgModel;
import cn.edu.nju.software.service.model.YhModel;

import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 17:14
 * @Description
 */
public interface FlfgService {
    List<FlfgModel> findFlfg() ;
    List<FlfgModel> findByUser(YhModel user) ;
}
