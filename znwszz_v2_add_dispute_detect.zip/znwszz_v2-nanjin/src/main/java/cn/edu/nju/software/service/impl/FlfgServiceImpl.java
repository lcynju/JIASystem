package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.service.DmbService;
import cn.edu.nju.software.service.FlfgService;
import cn.edu.nju.software.service.model.DmbModel;
import cn.edu.nju.software.service.model.FlfgModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.FlfgEnum;
import cn.edu.nju.software.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 17:18
 * @Description
 */
@Service
public class FlfgServiceImpl implements FlfgService {
    @Autowired
    private DmbService dmbService ;
    @Override
    public List<FlfgModel> findFlfg() {
        List<FlfgModel> flfgs = new ArrayList<>(FlfgEnum.values().length) ;
        for(FlfgEnum flfgEnum:FlfgEnum.values()){
            FlfgModel model = new FlfgModel() ;
            model.setMc(flfgEnum.getMc());
            model.setJc(flfgEnum.getJc());
            model.setUrl(flfgEnum.getUrl());
            flfgs.add(model) ;
        }
        return flfgs ;
    }

    @Override
    public List<FlfgModel> findByUser(YhModel user) {
        List<FlfgModel> flfgs = new ArrayList<>(FlfgEnum.values().length) ;

        /**
         * 发信
         */
        FlfgModel fx = new FlfgModel() ;
        fx.setMc(FlfgEnum.FX.getMc());
        fx.setJc(FlfgEnum.FX.getJc());
        String timestamp = DateUtil.format(new Date(),"yyyyMMddHHmm");
        fx.setUrl(String.format(FlfgEnum.FX.getGatewarUrl(),user.getFydm()+user.getDm(),timestamp+user.getFydm()+user.getDm()));
        flfgs.add(fx) ;

        /**
         * 律例注疏
         */
        FlfgModel llzs = new FlfgModel() ;
        llzs.setMc(FlfgEnum.LLZS.getMc());
        llzs.setJc(FlfgEnum.LLZS.getJc());
        DmbModel dm = dmbService.getDmModelByLbbhAndDmbh(user.getFydm(),"USR213-99","DZ5");
        llzs.setUrl(String.format(FlfgEnum.LLZS.getGatewarUrl(), user.getDm(),user.getPassword(),dm.getBz()));
        flfgs.add(llzs) ;

        /**
         * 中国审判法院应用支持系统
         */

        FlfgModel spyyzc = new FlfgModel() ;
        spyyzc.setMc(FlfgEnum.ZGSPFLYYZCXT.getMc());
        spyyzc.setJc(FlfgEnum.ZGSPFLYYZCXT.getJc());
        spyyzc.setUrl(FlfgEnum.ZGSPFLYYZCXT.getUrl());
        flfgs.add(spyyzc) ;

        return flfgs;
    }
}
