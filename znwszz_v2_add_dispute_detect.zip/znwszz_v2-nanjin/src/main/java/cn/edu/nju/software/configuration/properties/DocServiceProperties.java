package cn.edu.nju.software.configuration.properties;

import lombok.Data;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * documentServer服务配置映射的properties类
 * @author 13314
 * @date 2018/8/7
 */
@Component
@ConfigurationProperties("document-service")
@Data
public class DocServiceProperties  {
    private String apiUrl ;
    private String converterUrl ;
    private int timeout ;

}
