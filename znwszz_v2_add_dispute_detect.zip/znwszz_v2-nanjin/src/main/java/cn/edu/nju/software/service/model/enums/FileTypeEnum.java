package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;

import static cn.edu.nju.software.service.model.enums.DocumentTypeEnum.PRESENTATION;
import static cn.edu.nju.software.service.model.enums.DocumentTypeEnum.SPREADSHEET;
import static cn.edu.nju.software.service.model.enums.DocumentTypeEnum.TEXT;

/**
 * @author 13314409603@163.com
 * @date 2018/11/16
 * @time 15:44
 * @Description 本系统支持的文件类型，
 *  onlyoffice之documentServer本身支持以下类型：
     *  仅查看：
     *      viewedDocs: .pdf|.djvu|.xps
     *  可编辑：
     *      editedDocs: .docx|.xlsx|.csv|.pptx|.ppsx|.txt
     *  可转换：
     *      convertDocs: .docm|.dotx|.dotm|.dot|.doc|.odt|.fodt|.xlsm|.xltx|.xltm|.xlt|.xls|.ods|.fods|.pptm|.ppt|.ppsm|.pps|.potx|.potm|.pot|.odp|.fodp|.rtf|.mht|.html|.htm|.epub
 * 在此通过枚举类限制系统目前只支持以下类型
 *      doc,xls,ppt,docx,xlsx,pptx,pdf,jpg,png,tif,
 */
public enum FileTypeEnum {


    /**
     * 只可展示
     */
    PDF(".pdf","255044462D31", TEXT) ,
    TXT(".txt","",TEXT) ,

    /**
     * 可展示，转化后可编辑
     */
    DOC(".doc","D0CF11E0",TEXT) ,
    XLS(".xls","D0CF11E0",SPREADSHEET) ,
    PPT(".ppt","D0CF11E0",PRESENTATION) ,


    /**
     * 可展示，可编辑
     */
    DOCX(".docx","504B0304",TEXT) ,
    XLSX(".xlsx","504B0304",SPREADSHEET) ,
    PPTX(".pptx","504B0304",PRESENTATION) ,

    /**
     * 图片
     */
    JPG(".jpg","",PRESENTATION) ,
    ;
    /**
     * 后缀名
     */
    String suffixName ;
    /**
     * 文件头信息十六进制表示,用于检查文件的实际类型是否和后缀名匹配,
     */
    String fileHeader ;
    /**
     * 文件类型，包括展示型，表格型，TEXT型
     */
    DocumentTypeEnum documentType ;
    FileTypeEnum(String suffixName,String fileHeader,DocumentTypeEnum documentType){
        this.suffixName = suffixName ;
        this.fileHeader = fileHeader ;
        this.documentType = documentType ;
    }

    public static FileTypeEnum findBySuffixName(String suffixName){
        for(FileTypeEnum fileTypeEnum:FileTypeEnum.values()){
            if(StringUtil.equals(fileTypeEnum.suffixName,suffixName)){
                return fileTypeEnum ;
            }
        }
        return null ;
    }
    public static boolean ifNeedConverted(FileTypeEnum fileTypeEnum){
        if(DOC.equals(fileTypeEnum)||XLS.equals(fileTypeEnum)||PPT.equals(fileTypeEnum)){
            return true ;
        }else {
            return false ;
        }
    }
    public String getSuffixName() {
        return suffixName;
    }

    public String getFileHeader() {
        return fileHeader;
    }

    public DocumentTypeEnum getDocumentType() {
        return documentType;
    }

}
