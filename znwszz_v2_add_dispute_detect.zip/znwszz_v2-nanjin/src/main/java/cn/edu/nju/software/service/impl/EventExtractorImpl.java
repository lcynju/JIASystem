package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.service.EventExtractor;
import cn.edu.nju.software.service.model.events.*;
import cn.edu.nju.software.util.UicodeBackslashU;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 13314409603@163.com
 * @date 2019/4/15
 * @time 15:09
 * @Description
 */
@Component
public class EventExtractorImpl implements EventExtractor {

    @Autowired
    private RestTemplate restTemplate ;

    private String url = "http://127.0.0.1:8000/api/event_extractor" ;
    @Override
    public DivorceCaseModel extractorEvents(byte[] content) {
        String contentStr = new String(content) ;
        String[] ygscBgbc = contentStr.split("\r\n\r\n") ;
        System.out.println(ygscBgbc[0]);
        System.out.println(ygscBgbc[1]);

        //将原告诉称和被告辩称加入Map
        //MultiValueMap 继承自Map<K,List<V>>所以他的一个可以存储的是多个value
        MultiValueMap<String, String> bodyMap = new LinkedMultiValueMap<>();

        int index = ygscBgbc[0].indexOf("诉称") ;
        if(index!=-1) {
            String ygsc = ygscBgbc[0].substring(index + 2).trim();
            if(ygsc.startsWith("：")||ygsc.startsWith(":")||ygsc.startsWith("，")){
                ygsc = ygsc.substring(1) ;
            }
            bodyMap.add("content", ygsc);
        }
        index = ygscBgbc[1].indexOf("辩称") ;
        if(index!=-1){
            String bgbc = ygscBgbc[1].substring(index+2).trim() ;
            if(bgbc.startsWith("：")||bgbc.startsWith(":")||bgbc.startsWith("，")){
                bgbc = bgbc.substring(1) ;
            }
            bodyMap.add("content",bgbc);
        }

        //构造header
        HttpHeaders headers = new HttpHeaders() ;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<MultiValueMap<String,String>> entity = new HttpEntity<>(bodyMap,headers) ;

        //发送请求
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
        //将结果解码
        String result = UicodeBackslashU.unicodeToCn(responseEntity.getBody()) ;
        result =result.replaceAll("\\\\","").trim() ;
        System.out.println(result);

        //解析结果
        //去掉最外层的"[]"
        result = result.substring(2,result.length()-2) ;
        String regex = "\\[(.*)\\],\\s\\[(.*)\\]" ;
//        String regex = "\\[(.*?)\\]" ;
        Pattern pattern = Pattern.compile(regex) ;
        Matcher matcher = pattern.matcher(result);
        List<BaseEvent> ygEvents = null ;
        List<BaseEvent> bgEvents = null ;
        if (matcher.find()){
            //解析原告事实
            String ygss = matcher.group(1) ;
            ygEvents = decoder(ygss,true);
            //被告事实
            String bgss = matcher.group(2) ;
            bgEvents = decoder(bgss,false);
        }

        //构造caseModel
        DivorceCaseModel caseModel = formCaseModel(ygEvents,bgEvents) ;
        return caseModel ;
     }

    /**
     * 解析原告或被告事实
     * @param str
     * @return
     */
    private List<BaseEvent> decoder(String str,boolean isYg){
        if(str==null || str==""){
            return null ;
        }
        String regex = "\\{(.*?)\\}" ;
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(str);

        List<BaseEvent> result = new ArrayList<>() ;

        ObjectMapper mapper = new ObjectMapper() ;
        while (matcher.find()){
            try {
                String subStr = matcher.group(0) ;
                HashMap hashMap = mapper.readValue(subStr, HashMap.class);
                result.add(EventFactory.fromEventInstance(hashMap,isYg)) ;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result ;
    }

    private DivorceCaseModel formCaseModel(List<BaseEvent>ygss,List<BaseEvent>bgss){

        EventField know = new EventField("相识") ;
        EventField beInLove = new EventField("恋爱") ;
        EventField marry = new EventField("结婚") ;
        EventField remarry = new EventField("再婚") ;
        EventField bear = new EventField("生育") ;
        EventField familyConfict = new EventField("家庭矛盾") ;
        EventField domesticViolence = new EventField("家暴") ;
        EventField badHabit = new EventField("不良习惯") ;
        EventField separtion = new EventField("分居") ;
        EventField divorceLawsuit = new EventField("离婚诉讼") ;
        EventField derailed = new EventField("出轨") ;
        EventField wealth = new EventField("财产") ;
        EventField credit = new EventField("债权") ;
        EventField debt = new EventField("债务") ;
        for(BaseEvent event:ygss){
            if(event instanceof Know){
                know.addEvent(event);
            }else if(event instanceof BeInLove){
                beInLove.addEvent(event);
            }else if(event instanceof Marry){
                marry.addEvent(event);
            }else if(event instanceof ReMarry){
                remarry.addEvent(event);
            }else if(event instanceof Bear){
                bear.addEvent(event);
            }else if(event instanceof FamilyConfilct){
                familyConfict.addEvent(event);
            }else if(event instanceof DomesticViolence){
                domesticViolence.addEvent(event);
            }else if(event instanceof BadHabit){
                badHabit.addEvent(event);
            }else if(event instanceof Separation){
                separtion.addEvent(event);
            }else if(event instanceof DivorceLawsuit){
                divorceLawsuit.addEvent(event);
            }else if(event instanceof Derailed){
                derailed.addEvent(event);
            }else if(event instanceof Wealth){
                wealth.addEvent(event);
            }else if(event instanceof Credit){
                credit.addEvent(event);
            }else if(event instanceof Debt){
                debt.addEvent(event);
            }
        }
        for(BaseEvent event:bgss){
            if(event instanceof Know){
                know.addEvent(event);
            }else if(event instanceof BeInLove){
                beInLove.addEvent(event);
            }else if(event instanceof Marry){
                marry.addEvent(event);
            }else if(event instanceof ReMarry){
                remarry.addEvent(event);
            }else if(event instanceof Bear){
                bear.addEvent(event);
            }else if(event instanceof FamilyConfilct){
                familyConfict.addEvent(event);
            }else if(event instanceof DomesticViolence){
                domesticViolence.addEvent(event);
            }else if(event instanceof BadHabit){
                badHabit.addEvent(event);
            }else if(event instanceof Separation){
                separtion.addEvent(event);
            }else if(event instanceof DivorceLawsuit){
                divorceLawsuit.addEvent(event);
            }else if(event instanceof Derailed){
                derailed.addEvent(event);
            }else if(event instanceof Wealth){
                wealth.addEvent(event);
            }else if(event instanceof Credit){
                credit.addEvent(event);
            }else if(event instanceof Debt){
                debt.addEvent(event);
            }
        }

        DivorceCaseModel caseModel = new DivorceCaseModel() ;
        if(!know.isEmpty()){
            caseModel.addEventField(know);
        }
        if(!beInLove.isEmpty()) {
            caseModel.addEventField(beInLove);
        }
        if(!marry.isEmpty()) {
            caseModel.addEventField(marry);
        }
        if(!remarry.isEmpty()){
            caseModel.addEventField(remarry);
        }
        if(!bear.isEmpty()){
            caseModel.addEventField(bear);
        }
        if(!familyConfict.isEmpty()){
            caseModel.addEventField(familyConfict);
        }
        if(!domesticViolence.isEmpty()){
            caseModel.addEventField(domesticViolence);
        }
        if(!badHabit.isEmpty()){
            caseModel.addEventField(badHabit);
        }
        if(!separtion.isEmpty()){
            caseModel.addEventField(separtion);
        }
        if(!divorceLawsuit.isEmpty()){
            caseModel.addEventField(divorceLawsuit);
        }
        if(!derailed.isEmpty()){
            caseModel.addEventField(derailed);
        }
        if(!wealth.isEmpty()){
            caseModel.addEventField(wealth);
        }
        if(!credit.isEmpty()){
            caseModel.addEventField(credit);
        }
        if(!debt.isEmpty()){
            caseModel.addEventField(debt);
        }
        return caseModel ;
    }
}
class EventFactory{
    public static BaseEvent fromEventInstance(HashMap<String,Object> map,boolean isYg){
        String type = (String) map.get("type");
        BaseEvent event = null ;
        switch (type){
            case "Know":
                event = new Know(map) ;
                break;
            case "BeInLove":
                event = new BeInLove(map) ;
                break;
            case "Marry":
                event = new Marry(map) ;
                break;
            case "Remarry":
                event = new ReMarry(map) ;
                break;
            case "Bear":
                event = new Bear(map) ;
                break;
            case "FamilyConflict":
                event = new FamilyConfilct(map) ;
                break;
            case "DomesticViolence":
                event = new DomesticViolence(map) ;
                break;
            case "BadHabit":
                event = new BadHabit(map) ;
                break;
            case "Derailed":
                event = new Derailed(map) ;
                break;
            case "Separation":
                event = new Separation(map) ;
                break;
            case "DivorceLawsuit":
                event = new DivorceLawsuit(map) ;
                break;
            case "Wealth":
                event = new Wealth(map) ;
                break;
            case "Debt":
                event = new Debt(map) ;
                break;
            case "Credit":
                event = new Credit(map) ;
                break;
            default:
                ;
        }
        //渲染句子
        if(event!=null){
            event.setYg(isYg);
            event.render();
        }
        return event ;
    }
}


