package cn.edu.nju.software.service.convertor;


import cn.edu.nju.software.data.dataobject.PubAjJbDO;
import cn.edu.nju.software.service.model.AjModel;

/**
 * Created by 13314 on 2018/7/30.
 */
public class AjConvertor {
    public static AjModel ajDO2AjModel(PubAjJbDO ajDO){
        AjModel ajModel = new AjModel(ajDO.getAjxh(),ajDO.getAh(),ajDO.getAjmc(),ajDO.getAjxz(),ajDO.getSpcx(),ajDO.getSpcxdz(),ajDO.getBaspt(),ajDO.getLarq(),ajDO.getJarq()) ;
        return ajModel ;
    }
}
