package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;

import javax.servlet.http.HttpServletResponse;

/**
 *  文书service
 * @author 13314
 * @date 2018/8/16
 */
public interface WsService {

    /**
     * 获取文书目录
     */
    MlModel getWsMlByAjxh(String fydm, int ajxh) ;

    /**
     * 获取单个文书documentModel
     * @param wdId
     * @return
     */
    DocumentModel getWsDocumentModel(String wdId) ;

    /**
     * 下载单个文书
     */
    void downloadWs(HttpServletResponse response,String wdId) ;
}
