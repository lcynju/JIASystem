package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.FyModel;

import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/9/21
 * @time 10:31
 * @Description 法院Service，获取法院列表
 */
public interface FyService {
    /**
     * 返回包含上下级关系的法院列表
     * 没有将滨海新区、铁路放在二中院和一中院下级
     * @return
     */
    List<FyModel> getFyList() ;

    /**
     *返回没有包含上下级关系的法院列表
     * 顺序指定
     */
    List<FyModel> getOrdinaryFyList() ;
}
