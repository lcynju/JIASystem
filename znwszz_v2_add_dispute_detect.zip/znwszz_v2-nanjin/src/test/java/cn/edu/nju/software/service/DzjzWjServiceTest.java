package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.ResponseResult;
import cn.edu.nju.software.util.UicodeBackslashU;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Created by 13314 on 2018/9/5.
 */
//@RunWith(SpringRunner.class)
//@SpringBootTest
public class DzjzWjServiceTest {
    @Autowired
    DzjzWjService dzjzWjService ;
    @Autowired

    DocumentService documentService ;

    @Test
    public void test() throws IOException {
        String url = "http://192.168.68.83:8000/api/event_extractor" ;
        MultiValueMap<String,String> bodyMap = new LinkedMultiValueMap<>() ;
        bodyMap.add("content","原、被告于2010年经人介绍认识，××××年××月初六订亲，××××年××月××日领取结婚证，同年农历三月十八日举行典礼仪式。" ) ;
        HttpHeaders headers = new HttpHeaders() ;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        HttpEntity<MultiValueMap<String,String>> entity = new HttpEntity<>(bodyMap,headers) ;

        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url, entity, String.class);
        String result = UicodeBackslashU.unicodeToCn(responseEntity.getBody()) ;
        result =result.replaceAll("\\\\","").trim() ;
//        resu
        ObjectMapper mapper = new ObjectMapper() ;
        HashMap hashMap = mapper.readValue(result, HashMap.class);
        System.out.println(hashMap.get("result"));
    }
    @Test
    public void someTest(){
        String str = "[{trigger: Marry, word: 登记结婚, trigger_begin_index: 6, trigger_end_index: 7, time: }, " +
                "{trigger: FamilyConflict, word: 性格脾气差异大双方发生矛盾没有建立真正夫妻感情婚生子女, trigger_begin_index: 15, " +
                "trigger_end_index: 28}, {trigger: FamilyConflict, word: 发生不正当关系, trigger_begin_index: 8, trigger_end_index: 11}, " +
                "{trigger: FamilyConflict, word: 感情已彻底破裂已无和好, trigger_begin_index: 4, trigger_end_index: 10}, " +
                "{trigger: DivorceLawsuit, word: 要求被告离婚, trigger_begin_index: 11, trigger_end_index: 13, beginTime: , " +
                "person: , court: , endTime: , document: , result: }]" ;
//        String regex = "\\[(.*?)\\]" ;
        String regex = "\\{(.*?)\\}" ;
        Pattern pattern = Pattern.compile(regex) ;
        Matcher matcher1 = pattern.matcher("[sdaf], [sdfas], [dfasdf]");
        while (matcher1.find()){
            System.out.println(matcher1.groupCount());
            System.out.println(matcher1.group());
        }
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()){
            System.out.println(matcher.group(0));
        }
    }
    @Test
    public void test2() throws UnsupportedEncodingException {
        String url = "http://localhost:8080/gatewayUploadMul.do" ;
        MultiValueMap<String,Object> bodyMap = new LinkedMultiValueMap<>() ;
        Resource file = new FileSystemResource(new File("(2017)津民申2068号-民事再审判决书.docx")) ;
        bodyMap.add("file",file);
        bodyMap.add("ajxh",1);
        bodyMap.add("wjmc","wjmc") ;
        bodyMap.add("yhbh",1) ;
        bodyMap.add("root","root") ;
        bodyMap.add("folder","folder") ;
        HttpHeaders headers = new HttpHeaders() ;
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);
        HttpEntity<MultiValueMap<String,Object>> entity = new HttpEntity<>(bodyMap,headers) ;
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<ResponseResult> exchange = restTemplate.exchange(url, HttpMethod.POST, entity, ResponseResult.class);
        System.out.println(exchange.getStatusCode());
    }

}
