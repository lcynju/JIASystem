package cn.edu.nju.software.service;


import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.YhModel;

import java.io.File;
import java.util.ArrayList;
import java.util.Map;

/**
 *  电子卷宗文件service
 * @author 13314
 * @date 2018/7/30
 */
public interface DzjzWjService {
    MlModel getDzjzMlByAjxh(String fydm, int ajxh);

    /**
     * 获取电子卷宗文档model
     *
     * @param wdId
     * @return
     */
    DocumentModel getDzjzDocumentModel(String wdId);

    Map<String, ArrayList<String>> getOcrResult(int ajxh, String fydm);

    /**
     * 上传本地文档到电子卷宗，
     * 此时若上传文件的原文件名不同，则会新建一个文件且
     *
     * @param user
     * @param ajxh
     * @param wjmc 上传到电子卷宗时的文件名称
     * @param targetFile        上传到电子 卷宗时的文件
     */
    void uploadFileToDzjz(YhModel user, int ajxh,String wjmc, File targetFile);

}
