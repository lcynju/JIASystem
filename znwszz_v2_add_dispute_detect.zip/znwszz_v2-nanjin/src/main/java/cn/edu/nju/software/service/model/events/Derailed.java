package cn.edu.nju.software.service.model.events;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:52
 * @Description
 */
public class Derailed extends BaseEvent {
    private String time ;
    private String derailer ;

    public Derailed(HashMap<String,Object> map){
        super(map);
        this.forRendaring.add((ArrayList<Integer>) map.get("time_index_pair")) ;
        this.time = (String) map.get("time");

        this.derailer = (String) map.get("derailer");
        this.forRendaring.add((ArrayList<Integer>) map.get("derailer_index_pair")) ;
    }
    @Override
    /**
     * negated: time deailer trigger
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.time!=null && this.time.length()>0){
            if(str.length()>0){
                str = str +" "+this.time ;
            }else {
                str = this.time ;
            }
        }
        if(this.derailer!=null && this.derailer.length()>0){
            if(str.length()>0){
                str = str +" "+this.derailer ;
            }else {
                str = this.derailer ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        this.title = str ;
    }
}
