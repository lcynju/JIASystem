package cn.edu.nju.software;

import cn.edu.nju.software.service.TemplateService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ZnwszzApplicationTests {
    @Autowired
    TemplateService templateService ;
    @Test
    public void test(){
//        DocumentModel docTemplate = templateService.getAjglTemplate("120000 200", 12629, 6);
//        DocumentModel docTemplate1 = templateService.getAjglTemplate("120000 200", 12629, 2);
//        DocumentModel docTemplate2 = templateService.getAjglTemplate("120000 200", 12629, 3);
    }
}
