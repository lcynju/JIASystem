package cn.edu.nju.software.service.model.enums;

/**
 *  documentServer支持文档模式
 * @author 13314
 * @date 2018/8/7
 */
public enum EditorModeEnum {
    /**
     * 文档编辑模式
     */
    EDIT ,
    /**
     * 文档查看模式
     */
    VIEW ,
    ;
}
