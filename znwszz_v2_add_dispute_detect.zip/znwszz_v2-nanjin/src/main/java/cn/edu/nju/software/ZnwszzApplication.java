package cn.edu.nju.software;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author 13314
 */
@SpringBootApplication
public class ZnwszzApplication{

	public static void main(String[] args) {
		SpringApplication.run(ZnwszzApplication.class, args);
	}

}
