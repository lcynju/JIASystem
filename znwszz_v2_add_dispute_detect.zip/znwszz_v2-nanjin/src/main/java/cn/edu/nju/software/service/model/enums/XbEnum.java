package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;

/**
 *
 * @author 13314
 * @date 2018/8/15
 */
public enum  XbEnum {
    /**
     * 性别类型
     */
    U("0","未知"),
    M("1","男"),
    F("2","女"),
    QT("3","其他") ,
    ;
    private String bh ;
    private String mc ;
    XbEnum(String bh,String mc){
        this.bh = bh ;
        this.mc = mc ;
    }

    public static String getMcByBh(String bh){
        for(XbEnum xbEnum:XbEnum.values()){
            if(StringUtil.equals(xbEnum.bh,StringUtil.trim(bh))){
                return xbEnum.mc ;
            }
        }
        return U.mc ;
    }
}
