package cn.edu.nju.software.manager.webServiceManager.wsjcManager;

import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.jws.WebMethod;
import javax.jws.WebService;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**文书纠错回调存储文书接口
 * Created by 13314 on 2018/9/6.
 */
@Component
@WebService(serviceName = "wsjcCallBackService")
public class WsjcCallBackService {
    @Autowired
    private DocumentService documentService ;

    /**
     * 维护已纠错文档id
     */
    private final Set<String> wsIdsHadJc = new HashSet<>(64) ;
    private Logger logger = Logger.getLogger(WsjcCallBackService.class) ;

    /**
     * 0:成功
     -1:参数错误
     -2:签名检查不过
     -3:文书保存出错
     -4:发生系统异常
     * @param CaseID
     * @param DocumentData
     * @param Sign
     * @return
     */
    @WebMethod
    public String SaveFile(String CaseID,byte[] DocumentData,String Sign){
        String wdId = CaseIdHolder.get(CaseID) ;
        if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
            try {
                documentService.updateFileContect(DocumentData,wdId);
                synchronized (wsIdsHadJc){
                    wsIdsHadJc.add(wdId) ;
                }
            } catch (IOException e) {
                logger.error("文书纠错回调存储服务失败，文档id："+wdId+".错误信息："+e.getMessage());
                e.printStackTrace();
                return "-3" ;
            }
            return "0" ;
        }else {
            return "-1" ;
        }
    }

    /**
     * 判断文档是否已结纠错
     * @param wdId
     * @return
     */
    public boolean hadJc(String wdId){
        return wsIdsHadJc.contains(wdId);
    }
}
