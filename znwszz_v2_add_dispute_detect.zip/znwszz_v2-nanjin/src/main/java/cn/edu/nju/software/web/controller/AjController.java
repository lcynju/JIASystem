package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.AjService;
import cn.edu.nju.software.service.model.AjModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/7/30
 */
@Api(tags = "案件信息接口")
@RestController
public class AjController {
    @Autowired
    private AjService ajService ;
    @ApiOperation(value = "获取当前登陆用户案件列表，必须账户已登陆")
    @ApiImplicitParams({
            @ApiImplicitParam(name="type",value = "案件列表类型，包括yj、zb、cs,分别对应已结、在办、参审；" +
                    "选择已结类型时，需要指定时间范围；在办和参审默认当前时间的未结案件",required = true,paramType = "query") ,
            @ApiImplicitParam(name="begin",value = "开始时间,形如yyyy/MM/dd、yyyy-MM-dd",paramType = "query") ,
            @ApiImplicitParam(name="end",value = "结束时间,形如yyyy/MM/dd、yyyy-MM-dd",paramType = "query") ,
    })
    @GetMapping(value = "/getAjList",produces ="application/json" )
    public ResultVO<AjModel> getCurrentedUserAjs(HttpServletRequest request, String begin, String end, String type){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        if(user == null) {
            throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
        }
        List<AjModel> ajList = null ;
        switch (type){
            case "yj":
                ajList = ajService.getYjByName(user.getFydm(),begin,end,user.getName()) ;
                break;
            case "zb":
                ajList = ajService.getZbByName(user.getFydm(),user.getName()) ;
                break;
            case "cs":
                ajList = ajService.getCsByName(user.getFydm(),user.getName()) ;
                break;
            default:
                ajList = new ArrayList<>() ;
        }
        ResultVO resultVO = new ResultVO<AjModel>() ;
        resultVO.setSucceed(true);
        resultVO.setObject(ajList);
        return resultVO ;
    }
}
