package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.FlfgService;
import cn.edu.nju.software.service.model.FlfgModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 16:34
 * @Description
 */
@Api(tags = "法律法规接口")
@RestController
public class FlfgController {
    @Autowired
    private FlfgService flfgService ;
    @GetMapping(value = "/getFlfgList",produces ="application/json")
    @ApiOperation(value = "获取法律法规url")
    public ResultVO<List<FlfgModel>> getFlfgList(HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        ResultVO resultVO = new ResultVO() ;
        resultVO.setSucceed(true);
        if(user==null){
            resultVO.setObject(flfgService.findFlfg()) ;
        }else {
            resultVO.setObject(flfgService.findByUser(user));
        }
        return resultVO ;
    }
}
