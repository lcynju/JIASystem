package cn.edu.nju.software.service.model.events;

import cn.edu.nju.software.service.model.events.BaseEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:42
 * @Description
 */
public class Know extends BaseEvent {
    private String time ;

    public Know(HashMap<String,Object> map){
        super(map);
        this.time = (String) map.get("time");
        this.forRendaring.add((ArrayList<Integer>) map.get("time_index_pair")) ;
    }
    @Override
    /**
     * negated: time trigger
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.time!=null && this.time.length()>0){
            if(str.length()>0){
                str = str+" "+this.time ;
            }else {
                str = this.time ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }

        this.title = str ;
    }
}
