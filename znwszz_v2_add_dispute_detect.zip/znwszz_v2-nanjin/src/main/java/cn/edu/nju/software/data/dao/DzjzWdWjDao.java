package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DzjzWdWjDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/7/30.
 */
@Repository
public interface DzjzWdWjDao extends JpaRepository<DzjzWdWjDO,String> {
    DzjzWdWjDO getByWjid(String wjid) ;
    List<DzjzWdWjDO> getByAjxh(int ajxh) ;
}
