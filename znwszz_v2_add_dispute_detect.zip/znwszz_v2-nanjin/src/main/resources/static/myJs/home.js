/**
 * Created by YuanHao on 2018/7/20.
 */

// 上传文件
$('#file_upload').on('change', function () {
    var file = this.files[0];
    if (file.size > 1024 * 1000 * 1000) {
        alert('文件最大1G！')
    }
});

// 折叠或打开左边上传文件按钮
function click_left_content() {
    var left = $('#bdwdContent');
    var left_label = $('#left_label');
    var left_val = parseInt(left.css("marginLeft"));
    if (left_val >= 0) {
        vm.left_label_state = SHOW_STATE.HIDE;
        left.animate({marginLeft: '-350px'});
        left_label.css("background", "url(\"/image/right_fold.png\") no-repeat")
    } else if (left_val < 0) {
        vm.left_label_state = SHOW_STATE.SHOW;
        left.animate({marginLeft: '10px'});
        left_label.css("background", "url(\"/image/left_fold.png\") no-repeat")
    }
}

// 折叠或打开右边上传文件按钮
function click_right_content() {
    var right = $('#rightContent');
    var right_label = $('#right_label');
    var right_val = parseInt(right.css("marginLeft"));
    if (right_val >= 0) {
        vm.right_label_state = SHOW_STATE.HIDE;
        right.animate({marginLeft: '-350px'});
        right_label.css("background", "url(\"/image/right_fold.png\") no-repeat")
    } else if (right_val < 0) {
        vm.right_label_state = SHOW_STATE.SHOW;
        right.animate({marginLeft: '10px'});
        right_label.css("background", "url(\"/image/left_fold.png\") no-repeat")
    }
}

function show_left_content() {
    if(vm.left_label_state === SHOW_STATE.HIDE){
        click_left_content();
    }
}

function hide_right_content() {
    if(vm.right_label_state === SHOW_STATE.SHOW){
        click_right_content();
    }
}

function hide_left_content() {
    if(vm.left_label_state === SHOW_STATE.SHOW){
        click_left_content();
    }
}

//在页面关闭时对用户进行提醒保存文档
$(window).on('beforeunload', function() {
    return "确定要离开吗？";
});
