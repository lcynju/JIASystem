package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.service.model.YhModel;
import lombok.Data;

/**
 * @author 13314409603@163.com
 * @date 2018/9/21
 * @time 11:14
 * @Description
 */
@Data
public class YhCheckResult {
    boolean isSuccess;

    YhCheckResultCodeEnum resultCode;

    YhModel xtyh;
}
