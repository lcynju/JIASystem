/**
 * created at 2012-5-21
 */
package cn.edu.nju.software.service.model;


import java.io.Serializable;
import java.util.Date;

/**
 * 案由的领域模型
 * @author zym
 *
 */
public class AydmModel implements Serializable {


	private static final long serialVersionUID = 7896681019710707483L;
	/**
	 * 版本号
	 */
	private String bbh;
	/**
	 * 案由代码编号
	 */
	private String aydmbh;
	/**
	 * 修改时间
	 */
	private Date xgsj;
	/**
	 * 案由名称
	 */
	private String aymc;
	/**
	 * 案由类别
	 */
	private String aylb;
	/**
	 * 备注
	 */
	private String bz;
	/**
	 * 当前标识
	 */
	private String dqbs;
	/**
	 * 上级代码
	 */
	private String sjdm;
	/**
	 * 案由代码描述
	 */
	private String dmms;

    @Override
    public String toString() {
        return "AydmModel{" +
                "bbh='" + bbh + '\'' +
                ", aydmbh='" + aydmbh + '\'' +
                ", xgsj=" + xgsj +
                ", aymc='" + aymc + '\'' +
                ", aylb='" + aylb + '\'' +
                ", bz='" + bz + '\'' +
                ", dqbs='" + dqbs + '\'' +
                ", sjdm='" + sjdm + '\'' +
                ", dmms='" + dmms + '\'' +
                '}';
    }

    public String getBbh() {
		return bbh;
	}

	public void setBbh(String bbh) {
		this.bbh = bbh;
	}

	public String getAydmbh() {
		return aydmbh;
	}

	public void setAydmbh(String aydmbh) {
		this.aydmbh = aydmbh;
	}

	public Date getXgsj() {
		return xgsj;
	}

	public void setXgsj(Date xgsj) {
		this.xgsj = xgsj;
	}

	public String getAymc() {
		return aymc;
	}

	public void setAymc(String aymc) {
		this.aymc = aymc;
	}

	public String getAylb() {
		return aylb;
	}

	public void setAylb(String aylb) {
		this.aylb = aylb;
	}

	public String getBz() {
		return bz;
	}

	public void setBz(String bz) {
		this.bz = bz;
	}

	public String getDqbs() {
		return dqbs;
	}

	public void setDqbs(String dqbs) {
		this.dqbs = dqbs;
	}

	public String getSjdm() {
		return sjdm;
	}

	public void setSjdm(String sjdm) {
		this.sjdm = sjdm;
	}

	@Override
    @SuppressWarnings("deprecation")
	public boolean equals(Object other) {
		if ((this == other)) {
            return true;
        }if ((other == null)) {
            return false;
        }if (!(other instanceof AydmModel)) {
            return false;
        }
		AydmModel castOther = (AydmModel)other;
		boolean b = ((this.getBbh() == castOther.getBbh()) || (this.getBbh() != null && castOther.getBbh() != null && this.getBbh().equals(castOther.getBbh())))
				&& ((this.getAydmbh() == castOther.getAydmbh()) || (this.getAydmbh() != null && castOther.getAydmbh() != null && this.getAydmbh().equals(castOther.getAydmbh())))
				&& ((this.getAymc() == castOther.getAymc()) || (this.getAymc() != null && castOther.getAymc() != null && this.getAymc().equals(castOther.getAymc())))
				&& ((this.getAylb() == castOther.getAylb()) || (this.getAylb() != null && castOther.getAylb() != null && this.getAylb().equals(castOther.getAylb())))
				&& ((this.getBz() == castOther.getBz()) || (this.getBz() != null && castOther.getBz() != null && this.getBz().equals(castOther.getBz())))
				&& ((this.getXgsj() == castOther.getXgsj()) || (this.getXgsj() != null && castOther.getXgsj() != null && this.getXgsj().toLocaleString().equals(castOther.getXgsj().toLocaleString())))
				&& ((this.getDqbs() == castOther.getDqbs()) || (this.getDqbs() != null && castOther.getDqbs() != null && this.getDqbs().equals(castOther.getDqbs())));
		return b;
	}

	@Override
    public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getBbh() == null ? 0 : this.getBbh().hashCode());
		result = 37 * result
				+ (getAydmbh() == null ? 0 : this.getAydmbh().hashCode());
		result = 37 * result
				+ (getAymc() == null ? 0 : this.getAymc().hashCode());
		result = 37 * result
				+ (getAylb() == null ? 0 : this.getAylb().hashCode());
		result = 37 * result
				+ (getBz() == null ? 0 : this.getBz().hashCode());
		result = 37 * result
				+ (getXgsj() == null ? 0 : this.getXgsj().hashCode());
		result = 37 * result
				+ (getDqbs() == null ? 0 : this.getDqbs().hashCode());
		result = 37 * result
		+ (getDmms() == null ? 0 : this.getDmms().hashCode());
		
		return result;
	}

	/**
	 * @param dmms the dmms to set
	 */
	public void setDmms(String dmms) {
		this.dmms = dmms;
	}

	/**
	 * @return the dmms
	 */
	public String getDmms() {
		return dmms;
	}
	
}
