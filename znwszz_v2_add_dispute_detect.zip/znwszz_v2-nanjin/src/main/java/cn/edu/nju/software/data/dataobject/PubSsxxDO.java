package cn.edu.nju.software.data.dataobject;

import javax.persistence.*;
import java.util.Date;
/**
 * @author SsxxDO entity. @author MyEclipse Persistence Tools
 * @date 2018/10/26
 * @time 10:18
 * @Description
 */
@Entity
@Table(name = "PUB_SSXX")
@IdClass(PubSsxxDOId.class)
public class PubSsxxDO implements java.io.Serializable{
    private Integer ajxh;
    private Integer bh;

    private String ssr;
    private Date ssrq;
    private Date pjsxrq;
    private String ssrssqk;
    private String sbzclqk;
    private Double ssf;
    private Date dbrq;
    private Integer zjcs;
    private Integer fjcs;
    private String zscl;
    private Date ajjsrq;
    private Date yssjfyrq;
    private Date tjrq;
    private String cpwsspdz;
    private String cpwszw;
    private String ssjg;
    private String ajpcjg;
    private String sslc;
    private String bz;
    private String ssfs;
    private Date yjssfrq;
    private Date escprq;
    private String ssjgdm;
    private String ssgpyy;
    private Date sdsszrq;
    private Date fdssrq;
    private Date cdbssrrq;
    private Date bssrdbrq;
    private Date yslatrq;
    private Date tcbrrq;
    private Date sdtjrq;
    private Integer sfks;
    private String hjqksm;
    private String esah;
    private Date eslarq;
    private byte[] escpws;
    private Date esjarq;
    private String eshyjafs;

    // Constructors

    /** default constructor */
    public PubSsxxDO() {
    }

    /** minimal constructor */
    public PubSsxxDO(Integer ajxh,Integer bh) {
        this.ajxh = ajxh;
        this.bh = bh;
    }

    /** full constructor */
    public PubSsxxDO(Integer ajxh,Integer bh, String ssr, Date ssrq, Date pjsxrq,
                  String ssrssqk, String sbzclqk, Double ssf, Date dbrq,
                  Integer zjcs, Integer fjcs, String zscl, Date ajjsrq,
                  Date yssjfyrq, Date tjrq, String cpwsspdz, String cpwszw,
                  String ssjg, String ajpcjg, String sslc, String bz, String ssfs,
                  Date yjssfrq, Date escprq, String ssjgdm, String ssgpyy,
                  Date sdsszrq, Date fdssrq, Date cdbssrrq, Date bssrdbrq,
                  Date yslatrq, Date tcbrrq, Date sdtjrq, Integer sfks,
                  String hjqksm, String esah, Date eslarq, byte[] escpws,
                  Date esjarq, String eshyjafs) {
        this.ajxh = ajxh;
        this.bh = bh;
        this.ssr = ssr;
        this.ssrq = ssrq;
        this.pjsxrq = pjsxrq;
        this.ssrssqk = ssrssqk;
        this.sbzclqk = sbzclqk;
        this.ssf = ssf;
        this.dbrq = dbrq;
        this.zjcs = zjcs;
        this.fjcs = fjcs;
        this.zscl = zscl;
        this.ajjsrq = ajjsrq;
        this.yssjfyrq = yssjfyrq;
        this.tjrq = tjrq;
        this.cpwsspdz = cpwsspdz;
        this.cpwszw = cpwszw;
        this.ssjg = ssjg;
        this.ajpcjg = ajpcjg;
        this.sslc = sslc;
        this.bz = bz;
        this.ssfs = ssfs;
        this.yjssfrq = yjssfrq;
        this.escprq = escprq;
        this.ssjgdm = ssjgdm;
        this.ssgpyy = ssgpyy;
        this.sdsszrq = sdsszrq;
        this.fdssrq = fdssrq;
        this.cdbssrrq = cdbssrrq;
        this.bssrdbrq = bssrdbrq;
        this.yslatrq = yslatrq;
        this.tcbrrq = tcbrrq;
        this.sdtjrq = sdtjrq;
        this.sfks = sfks;
        this.hjqksm = hjqksm;
        this.esah = esah;
        this.eslarq = eslarq;
        this.escpws = escpws;
        this.esjarq = esjarq;
        this.eshyjafs = eshyjafs;
    }

    @Column(name = "AJXH", nullable = false)
    @Id
    public Integer getAjxh() {
        return ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name = "BH", nullable = false)
    @Id
    public Integer getBh() {
        return bh;
    }

    public void setBh(Integer bh) {
        this.bh = bh;
    }

    @Column(name = "SSR", length = 100)
    public String getSsr() {
        return this.ssr;
    }

    public void setSsr(String ssr) {
        this.ssr = ssr;
    }

    @Column(name = "SSRQ", length = 23)
    public Date getSsrq() {
        return this.ssrq;
    }

    public void setSsrq(Date ssrq) {
        this.ssrq = ssrq;
    }

    @Column(name = "PJSXRQ", length = 23)
    public Date getPjsxrq() {
        return this.pjsxrq;
    }

    public void setPjsxrq(Date pjsxrq) {
        this.pjsxrq = pjsxrq;
    }

    @Column(name = "SSRSSQK")
    public String getSsrssqk() {
        return this.ssrssqk;
    }

    public void setSsrssqk(String ssrssqk) {
        this.ssrssqk = ssrssqk;
    }

    @Column(name = "SBZCLQK", length = 250)
    public String getSbzclqk() {
        return this.sbzclqk;
    }

    public void setSbzclqk(String sbzclqk) {
        this.sbzclqk = sbzclqk;
    }

    @Column(name = "SSF", scale = 4)
    public Double getSsf() {
        return this.ssf;
    }

    public void setSsf(Double ssf) {
        this.ssf = ssf;
    }

    @Column(name = "DBRQ", length = 23)
    public Date getDbrq() {
        return this.dbrq;
    }

    public void setDbrq(Date dbrq) {
        this.dbrq = dbrq;
    }

    @Column(name = "ZJCS")
    public Integer getZjcs() {
        return this.zjcs;
    }

    public void setZjcs(Integer zjcs) {
        this.zjcs = zjcs;
    }

    @Column(name = "FJCS")
    public Integer getFjcs() {
        return this.fjcs;
    }

    public void setFjcs(Integer fjcs) {
        this.fjcs = fjcs;
    }

    @Column(name = "ZSCL", length = 200)
    public String getZscl() {
        return this.zscl;
    }

    public void setZscl(String zscl) {
        this.zscl = zscl;
    }

    @Column(name = "AJJSRQ", length = 23)
    public Date getAjjsrq() {
        return this.ajjsrq;
    }

    public void setAjjsrq(Date ajjsrq) {
        this.ajjsrq = ajjsrq;
    }

    @Column(name = "YSSJFYRQ", length = 23)
    public Date getYssjfyrq() {
        return this.yssjfyrq;
    }

    public void setYssjfyrq(Date yssjfyrq) {
        this.yssjfyrq = yssjfyrq;
    }

    @Column(name = "TJRQ", length = 23)
    public Date getTjrq() {
        return this.tjrq;
    }

    public void setTjrq(Date tjrq) {
        this.tjrq = tjrq;
    }

    @Column(name = "CPWSSPDZ", length = 20)
    public String getCpwsspdz() {
        return this.cpwsspdz;
    }

    public void setCpwsspdz(String cpwsspdz) {
        this.cpwsspdz = cpwsspdz;
    }

    @Column(name = "CPWSZW")
    public String getCpwszw() {
        return this.cpwszw;
    }

    public void setCpwszw(String cpwszw) {
        this.cpwszw = cpwszw;
    }

    @Column(name = "SSJG", length = 250)
    public String getSsjg() {
        return this.ssjg;
    }

    public void setSsjg(String ssjg) {
        this.ssjg = ssjg;
    }

    @Column(name = "AJPCJG", length = 20)
    public String getAjpcjg() {
        return this.ajpcjg;
    }

    public void setAjpcjg(String ajpcjg) {
        this.ajpcjg = ajpcjg;
    }

    @Column(name = "SSLC", length = 1)
    public String getSslc() {
        return this.sslc;
    }

    public void setSslc(String sslc) {
        this.sslc = sslc;
    }

    @Column(name = "BZ", length = 20)
    public String getBz() {
        return this.bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    @Column(name = "SSFS", length = 10)
    public String getSsfs() {
        return this.ssfs;
    }

    public void setSsfs(String ssfs) {
        this.ssfs = ssfs;
    }

    @Column(name = "YJSSFRQ", length = 23)
    public Date getYjssfrq() {
        return this.yjssfrq;
    }

    public void setYjssfrq(Date yjssfrq) {
        this.yjssfrq = yjssfrq;
    }

    @Column(name = "ESCPRQ", length = 23)
    public Date getEscprq() {
        return this.escprq;
    }

    public void setEscprq(Date escprq) {
        this.escprq = escprq;
    }

    @Column(name = "SSJGDM", length = 10)
    public String getSsjgdm() {
        return this.ssjgdm;
    }

    public void setSsjgdm(String ssjgdm) {
        this.ssjgdm = ssjgdm;
    }

    @Column(name = "SSGPYY", length = 200)
    public String getSsgpyy() {
        return this.ssgpyy;
    }

    public void setSsgpyy(String ssgpyy) {
        this.ssgpyy = ssgpyy;
    }

    @Column(name = "SDSSZRQ", length = 23)
    public Date getSdsszrq() {
        return this.sdsszrq;
    }

    public void setSdsszrq(Date sdsszrq) {
        this.sdsszrq = sdsszrq;
    }

    @Column(name = "FDSSRQ", length = 23)
    public Date getFdssrq() {
        return this.fdssrq;
    }

    public void setFdssrq(Date fdssrq) {
        this.fdssrq = fdssrq;
    }

    @Column(name = "CDBSSRRQ", length = 23)
    public Date getCdbssrrq() {
        return this.cdbssrrq;
    }

    public void setCdbssrrq(Date cdbssrrq) {
        this.cdbssrrq = cdbssrrq;
    }

    @Column(name = "BSSRDBRQ", length = 23)
    public Date getBssrdbrq() {
        return this.bssrdbrq;
    }

    public void setBssrdbrq(Date bssrdbrq) {
        this.bssrdbrq = bssrdbrq;
    }


    @Column(name = "YSLATRQ", length = 23)
    public Date getYslatrq() {
        return this.yslatrq;
    }

    public void setYslatrq(Date yslatrq) {
        this.yslatrq = yslatrq;
    }

    @Column(name = "TCBRRQ", length = 23)
    public Date getTcbrrq() {
        return this.tcbrrq;
    }

    public void setTcbrrq(Date tcbrrq) {
        this.tcbrrq = tcbrrq;
    }

    @Column(name = "SDTJRQ", length = 23)
    public Date getSdtjrq() {
        return this.sdtjrq;
    }

    public void setSdtjrq(Date sdtjrq) {
        this.sdtjrq = sdtjrq;
    }

    @Column(name = "SFKS")
    public Integer getSfks() {
        return this.sfks;
    }

    public void setSfks(Integer sfks) {
        this.sfks = sfks;
    }

    @Column(name = "HJQKSM", length = 200)
    public String getHjqksm() {
        return this.hjqksm;
    }

    public void setHjqksm(String hjqksm) {
        this.hjqksm = hjqksm;
    }

    @Column(name = "ESAH", length = 40)
    public String getEsah() {
        return this.esah;
    }

    public void setEsah(String esah) {
        this.esah = esah;
    }

    @Column(name = "ESLARQ", length = 23)
    public Date getEslarq() {
        return this.eslarq;
    }

    public void setEslarq(Date eslarq) {
        this.eslarq = eslarq;
    }

    @Column(name = "ESCPWS")
    public byte[] getEscpws() {
        return this.escpws;
    }

    public void setEscpws(byte[] escpws) {
        this.escpws = escpws;
    }

    @Column(name = "ESJARQ", length = 23)
    public Date getEsjarq() {
        return this.esjarq;
    }

    public void setEsjarq(Date esjarq) {
        this.esjarq = esjarq;
    }

    @Column(name = "ESHYJAFS", length = 10)
    public String getEshyjafs() {
        return this.eshyjafs;
    }

    public void setEshyjafs(String eshyjafs) {
        this.eshyjafs = eshyjafs;
    }

}
