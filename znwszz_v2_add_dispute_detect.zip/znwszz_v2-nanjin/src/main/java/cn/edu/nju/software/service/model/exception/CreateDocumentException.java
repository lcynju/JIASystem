package cn.edu.nju.software.service.model.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  创建文档实例失败异常
 * @author 13314
 * @date 2018/8/7
 */
@Data
@AllArgsConstructor
public class CreateDocumentException extends RuntimeException {
    private String fileName ;
}
