package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.AydmModel;

import java.util.List;

/**
 *  案由service
 * @author 13314
 * @date 2018/8/14
 */
public interface AyDmbService {
    List<AydmModel> getAydmByAjxh(String fydm,int ajxh) ;
}
