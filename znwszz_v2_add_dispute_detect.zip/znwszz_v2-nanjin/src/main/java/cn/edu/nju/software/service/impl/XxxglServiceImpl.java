package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.XxxglDao;
import cn.edu.nju.software.data.dataobject.XxxglDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.XxxService;
import cn.edu.nju.software.service.convertor.XxxConvertor;
import cn.edu.nju.software.service.model.XxxModel;
import cn.edu.nju.software.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author 13314
 * @date 2018/8/13
 */
@Service
public class XxxglServiceImpl implements XxxService {
    @Autowired
    private XxxglDao xxxglDao ;

    private static final String DSR_TABLE_NAME = "DSR_JB" ;
    private static final String DSR_COLUMN_NAME = "DSRSSDW" ;

    private Logger logger = LoggerFactory.getLogger(XxxglServiceImpl.class);
    @Override
    public XxxModel findByTableAndColumn(String fydm,String szb, String szl) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        XxxglDO xxxglDO = xxxglDao.findBySzbAndSzl(szb, szl);
        DynamicDataSource.router(curDB);
        return XxxConvertor.DO2Model(xxxglDO);
    }

    @Override
    public String getSsdwLbbhByAjxzAndSpcx(String fydm,String ajxz, String spcx) {
        if (!StringUtil.isBlank(ajxz)) {
            ajxz = StringUtil.trim(ajxz);
        }
        if ("2".equals(ajxz) || "3".equals(ajxz)
                || "4".equals(ajxz) || "5".equals(ajxz)) {
            ajxz = "2";
        }
        if (!StringUtil.isBlank(spcx)) {
            spcx = StringUtil.trim(spcx);
        }
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        XxxglDO xxxglDO = xxxglDao.findBySzbAndSzl(DSR_TABLE_NAME, DSR_COLUMN_NAME);
        String sjxx = xxxglDO.getSjxx() ;
        DynamicDataSource.router(curDB);

        String ssdwLbbh = "" ;

        if (StringUtil.indexOf(sjxx, ",") < 0) {
            ssdwLbbh =  sjxx ;
        }

        int index = sjxx.indexOf(ajxz + spcx);
        if (index > 0
                && !StringUtil.equals(sjxx.substring(index - 1, index), ",")) {
            index = -1;
        }
        if (index == -1) {
            index = sjxx.indexOf(ajxz + "*");
        }
        if (index == -1) {
            String errStr = "getCasecode() 无法匹配多重代码！" + " temp_ajxz："
                    + ajxz + ",temp_spcx： " + spcx + ", sjxx:"
                    + sjxx;
            logger.error(errStr);
            return null;
        }

        int endIndex = sjxx.indexOf(",", index);
        if (endIndex == -1) {
            ssdwLbbh = sjxx.substring(index + 2, sjxx.length());
        } else {
            ssdwLbbh = sjxx.substring(index + 2, endIndex);
        }
        return ssdwLbbh ;
    }
}
