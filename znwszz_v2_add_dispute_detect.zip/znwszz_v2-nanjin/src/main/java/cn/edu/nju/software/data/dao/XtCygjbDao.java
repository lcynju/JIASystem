package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.XtCygjbDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author 13314409603@163.com
 * @date 2018/10/24
 * @time 16:10
 * @Description
 */
@Repository
public interface XtCygjbDao extends JpaRepository<XtCygjbDO,Integer> {
    XtCygjbDO findByGjmc(String gjmc) ;
}
