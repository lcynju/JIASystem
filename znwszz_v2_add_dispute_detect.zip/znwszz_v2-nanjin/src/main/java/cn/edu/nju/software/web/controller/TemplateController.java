package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.TemplateService;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.StringUtil;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
@Api(tags = "模板相关接口")
@Controller
public class TemplateController {
    @Autowired
    private TemplateService templateService ;

    @ApiOperation(value = "获取模板目录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "type" ,value = "模板类型，包括通用类：1，案件关联类：2",paramType = "query",required = true),
            @ApiImplicitParam(name = "ajxh" ,value = "案件序号，案件关联类模板时，则必须有案件序号",paramType = "query"),
    })
    @ResponseBody
    @GetMapping("/getTemplateMl")
    public ResultVO<MlModel> getTemplateMl(HttpServletRequest request,String type,int ajxh){
        ResultVO resultVO = null ;
        if(StringUtil.equals(type,"1")){
            /**
             * 通用类模板
             */
        }else if(StringUtil.equals(type,"2")){
            /**
             * 案件关联类模板
             */
            YhModel user = (YhModel) request.getSession().getAttribute("user");
            if(user == null) {
                throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
            }
            MlModel templateMl = templateService.getAjglTemplateMl(user.getFydm(),ajxh);
            resultVO = new ResultVO<MlModel>() ;
            resultVO.setSucceed(true);
            resultVO.setObject(templateMl);
        }
        return resultVO ;
    }

    @ApiOperation(value = "获取开庭信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ajxh",value = "案件序号",paramType = "query"),
    })
    @ResponseBody
    @GetMapping("/getTemplateKtxx")
    public ResultVO<List<String>> getKtxx(HttpServletRequest request, int ajxh) {
        ResultVO resultVO = new ResultVO<List<String>>();
        List<String> result = templateService.getKtxxByAjxh(ajxh);
        for (int i = 0; i < result.size(); i ++) {
            result.set(i, result.get(i) + " 第" + (i + 1) + "次开庭");
        }
        resultVO.setObject(result);
        resultVO.setSucceed(true);
        return resultVO;
    }

    @ApiOperation(value = "获取模板文件")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "templateBh",value = "模板编号",required = true,paramType = "query"),
            @ApiImplicitParam(name = "ajxh",value = "案件序号：当案件序号为空时，模板编号为通用类模板；当案件序号不为空，则模板为案件关联类模板",paramType = "query"),
            @ApiImplicitParam(name = "ktbh", value = "开庭编号：当当前案件有超过一次开庭记录时，传入对应的开庭编号", required = false, paramType = "query"),
    })
    @ResponseBody
    @GetMapping("/getTemplateWd")
    public ResultVO<DocumentModel> getTemplate(HttpServletRequest request, int templateBh,String ajxh, String ktbh){
        ResultVO resultVO = new ResultVO<DocumentModel>();
        if(StringUtil.isEmpty(ajxh)){
            /**
             * 通用类模板处理
             */
        }else {
            /**
             * 案件关联类模板处理
             */
            YhModel user = (YhModel) request.getSession().getAttribute("user");
            if(user==null) {
                throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
            }
            int ktBh = 0;
            if (ktbh != null && !"".equals(ktbh)) {
                ktBh = Integer.parseInt(ktbh);
            }
            DocumentModel docTemplate = templateService.getAjglTemplate(user, Integer.parseInt(ajxh), templateBh, ktBh);
            resultVO.setObject(docTemplate);
        }
        resultVO.setSucceed(true);
        return resultVO ;
    }


}
