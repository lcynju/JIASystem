package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;

/**
 *    案件关联类模板，需要指定的案件信息组成模板内容，例如：当事人信息，审判人员信息
 * @author 13314
 * @date 2018/8/8
 */
@ApiModel
public enum AjGlTemplateTypeEnum {

    /**
     * 刑事
     */
    //判决书
//    XSYSPJS(1,"刑事一审判决书","11","刑事一审判决书.ftl") ,
    XSESPJS(2,"刑事二审判决书","12","刑事二审判决书.ftl") ,
    XSZSPJS(3,"刑事再审判决书","13","刑事再审判决书.ftl") ,
    //裁定书
//    XSYSCDS(4,"刑事一审裁定书","11","刑事一审裁定书.ftl") ,
    XSESCDS(5,"刑事二审裁定书","12","刑事二审裁定书.ftl") ,
    XSZSCDS(6,"刑事再审裁定书","13","刑事再审裁定书.ftl") ,
    //调解书
//    XSYSTJS(7,"刑事一审调解书","11","刑事一审调解书.ftl") ,
    XSESTJS(8,"刑事二审调解书","12","刑事二审调解书.ftl") ,
    XSZSTJS(9,"刑事再审调解书","13","刑事再审调解书.ftl") ,
    
    /**
     * 民事
     */
    //判决书



    MSESPJS(11,"民事二审判决书","22","民事二审判决书.ftl") ,
    MSZSPJS(12,"民事再审判决书","23","民事再审判决书.ftl") ,
    //裁定书
//    MSYSCDS(13,"民事一审裁定书","21","民事一审裁定书.ftl") ,
    MSESCDS(14,"民事二审裁定书","22","民事二审裁定书.ftl") ,
    MSZSCDS(15,"民事再审裁定书","23","民事再审裁定书.ftl") ,
    //调解书
//    MSYSTJS(16,"民事一审调解书","21","民事一审调解书.ftl") ,
    MSESTJS(17,"民事二审调解书","22","民事二审调解书.ftl") ,
    MSZSTJS(18,"民事再审调解书","23","民事再审调解书.ftl") ,
    
    
    /**
     * 行政
     */
    //判决书
//    XZYSPJS(19,"行政一审判决书","61","行政一审判决书.ftl") ,
    XZESPJS(20,"行政二审判决书","62","行政二审判决书.ftl") ,
    XZZSPJS(21,"行政再审判决书","63","行政再审判决书.ftl") ,
    //裁定书
//    XZYSCDS(22,"行政一审裁定书","61","行政一审裁定书.ftl") ,
    XZESCDS(23,"行政二审裁定书","62","行政二审裁定书.ftl") ,
    XZZSCDS(24,"行政再审裁定书","63","行政再审裁定书.ftl") ,
    //调解书
//    XZYSTJS(25,"行政一审调解书","61","行政一审调解书.ftl") ,
    XZESTJS(26,"行政二审调解书","62","行政二审调解书.ftl") ,
    XZZSTJS(27,"行政再审调解书","63","行政再审调解书.ftl") ,

    PJS(28,"判决书","","判决书.ftl") ,
    CDS(29,"裁定书","","裁定书.ftl") ,
    TJS(30,"调解书","","调解书.ftl") ,
    KTBL(31,"开庭笔录","","开庭笔录.ftl"),


    /**
     * 民事一审
     */
    MSYSPJS_DYSPTCXY(32,"民事判决书（第一审普通程序用）","21","民事一审判决书（第一审普通程序用）.ftl") ,
    MSYSPJS_JYCX_DSRDAJSSYZYY(33,"民事判决书（简易程序-当事人对案件事实有争议用）","21","民事一审判决书（简易程序-当事人对案件事实有争议用）.ftl") ,
    MSYSPJS_JYCX_DSRDAJSSMYZYY(34,"民事判决书（简易程序-当事人对案件事实没有争议用）","21","民事一审判决书（简易程序-当事人对案件事实没有争议用）.ftl") ,
    MSYSPJS_JYCX_BGCRYGQBSSQQY(35,"民事判决书（简易程序-被告承认原告全部诉讼请求用）","21","民事一审判决书（简易程序-被告承认原告全部诉讼请求用）.ftl") ,

    MSYSTJS_DYSPTCXY(36,"民事调解书（第一审普通程序用）","21","民事一审调解书（第一审普通程序用）.ftl") ,
    MSYSTJS_JYCXY(37,"民事调解书（简易程序用）","21","民事一审调解书（简易程序用）.ftl") ,
    MSYSTJS_XESSCXY(38,"民事调解书（小额诉讼程序用）","21","民事一审调解书（小额诉讼程序用）.ftl") ,

    MSYSCDS_SQCCBQY(39,"民事裁定书（诉前财产保全用）","21","民事一审裁定书（诉前财产保全用）.ftl") ,
    MSYSCDS_DQSBYSLY(40,"民事裁定书（对起诉不予受理用）","21","民事一审裁定书（对起诉不予受理用）.ftl") ,
    MSYSCDS_BHQSY(41,"民事裁定书（驳回起诉用）","21","民事一审裁定书（驳回起诉用）.ftl") ,

    /**
     * 刑事一审
     */
    XSYSPJS_GSZREFZY(42,"刑事判决书（公诉自然人犯罪用）","11","刑事一审判决书（公诉自然人犯罪用）.ftl") ,
    XSYSPJS_GSDWFZY(43,"刑事判决书（公诉单位犯罪用）","11","刑事一审判决书（公诉单位犯罪用）.ftl") ,
    XSYSPJS_ZSY(44,"刑事判决书（自诉用）","11","刑事一审判决书（自诉用）.ftl") ,

    XSYSCDS_BHQSY(45,"刑事裁定书（驳回自诉用）","11","刑事一审裁定书（驳回自诉用）.ftl") ,
    XSYSCDS_CSY(46,"刑事裁定书（自诉撤诉用）","11","刑事一审裁定书（自诉撤诉用）.ftl") ,

    /**
     * 行政一审
     */
    XZYSPJS_CXBGXZXWY(47,"行政判决书（撤销、变更行政行为用）","61","行政一审判决书（撤销、变更行政行为用）.ftl") ,
    XZYSPJS_QQLXFDZZY(48,"行政判决书（请求履行法定职责用）","61","行政一审判决书（请求履行法定职责用）.ftl") ,
    XZYSPJS_QQQRWFHWXY(49,"行政判决书（请求确认违法或无效用）","61","行政一审判决书（请求确认违法或无效用）.ftl") ,
    XZYSTJS(50,"行政调解书","61","行政一审调解书.ftl") ,
    XZYSCDS_BHQSY(51,"行政裁定书（驳回起诉用）","61","行政一审裁定书（驳回起诉用）.ftl") ,
    XZYSCDS_CSY(52,"行政裁定书（撤诉用）","61","行政一审裁定书（撤诉用）.ftl") ,
    XZYSCDS_ACSCLY(53,"行政裁定书（按撤诉处理用）","61","行政一审裁定书（按撤诉处理用）.ftl") ,
    XZYSCDS_BYLAY(54,"行政裁定书（不予立案用）","61","行政一审裁定书（不予立案用）.ftl") ,
    ;

    @ApiModelProperty(value = "模板id")
    private int id ;
    @ApiModelProperty(value = "模板名称")
    private String text ;
    @ApiModelProperty(value = "模板类别，ajxz+spcx")
    private String lb ;
    @ApiModelProperty(value = "模板文件名")
    private String templateFileName ;

    AjGlTemplateTypeEnum(int id, String text, String lb, String templateFileName){
        this.id = id ;
        this.text = text ;
        this.lb = lb ;
        this.templateFileName = templateFileName ;
    }

    /**
     * 根据模板编号返回模板文件
     * @param bh
     * @return 可为null
     */
    public static AjGlTemplateTypeEnum findByBh(int bh){
        for(AjGlTemplateTypeEnum theTemplate: AjGlTemplateTypeEnum.values()){
            if (theTemplate.id==bh) {
                return theTemplate ;
            }
        }
        return null ;
    }

    public int getId() {
        return id;
    }

    public String getText() {
        return text;
    }

    public String getTemplateFileName() {
        return templateFileName;
    }

    public String getLb() {
        return lb;
    }

    /**
     * 根据案件性质+审判程序获得相应的模板，若无匹配的则返回案件通用的判决书、裁定书、调解书。
     * @param lb
     * @return
     */
    public static List<AjGlTemplateTypeEnum> getByLb(String lb){
        List<AjGlTemplateTypeEnum> result = new ArrayList<>() ;
        for(AjGlTemplateTypeEnum ajGlTemplateTypeEnum: AjGlTemplateTypeEnum.values()){
            if(StringUtil.equals(lb,ajGlTemplateTypeEnum.getLb())){
                result.add(ajGlTemplateTypeEnum) ;
            }
        }
        if(result.isEmpty()){
            result.add(PJS) ;
            result.add(CDS) ;
            result.add(TJS) ;
        }
        return result ;
    }
}
