/**
 * Created by YuanHao on 2018/7/25.
 *  初始化页面
 */

$(document).ready(function () {

});

function getFlfgList() {
    $.ajax({
        url: '/getFlfgList',
        type: 'get',
        success: function (data) {
            var result = data.object;
            for (var i = 0; i < result.length; i++) {
                if (result[i].jc === 'fx') {
                    vm.fx_url = result[i].url;
                    vm.flfg_web_site[0]['url'] = result[i].url;
                } else if(result[i].jc === 'llzs') {
                    vm.llzu_url = result[i].url;
                    vm.flfg_web_site[1]['url'] = result[i].url;
                }
            }
        }

    })
}
