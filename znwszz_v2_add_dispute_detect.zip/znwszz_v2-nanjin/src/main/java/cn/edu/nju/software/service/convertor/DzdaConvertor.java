package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.DzdaWdWjDO;
import cn.edu.nju.software.data.dataobject.DzdaWdWjjDO;
import cn.edu.nju.software.data.dataobject.DzjzWdWjDO;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;

import javax.print.Doc;

/**
 * Created by 13314 on 2018/9/12.
 */
public class DzdaConvertor {
    public static MlModel mlDO2MlModel(DzdaWdWjjDO wjjDO){
        MlModel mlModel = new MlModel() ;
        mlModel.setId(wjjDO.getWjjid());
        mlModel.setMc(wjjDO.getWjjmc());
        return mlModel ;
    }
    /**
     * 构造文档model时，id加上电子档案前缀，用于与基表文书、本地文档、电子卷宗区别
     * @param wjDO
     * @return
     */
    public static WdModel wjDO2WjModel(String fydm,DzdaWdWjDO wjDO){
        WdModel wdModel = new WdModel() ;
        wdModel.setId(DocSourceEnum.YSDA.getPrefix()+DocSourceEnum.CONNECTOR+fydm+ DocSourceEnum.CONNECTOR +wjDO.getWjid());
        wdModel.setMc(wjDO.getWjmc());
        return wdModel ;
    }
}
