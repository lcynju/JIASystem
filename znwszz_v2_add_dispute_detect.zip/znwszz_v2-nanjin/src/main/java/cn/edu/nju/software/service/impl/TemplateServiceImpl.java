package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.FtnqFtsysqdjDao;
import cn.edu.nju.software.data.dao.PubAjJbDao;
import cn.edu.nju.software.data.dataobject.FtnqFtsysqdjDO;
import cn.edu.nju.software.data.dataobject.PubAjJbDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.manager.TemplateManager;
import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.TemplateService;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.AjGlTemplateTypeEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.DateUtil;
import cn.edu.nju.software.util.StringUtil;
import freemarker.template.Template;
import org.docx4j.Docx4J;
import org.docx4j.openpackaging.packages.WordprocessingMLPackage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
@Service
public class TemplateServiceImpl implements TemplateService{
    @Autowired
    private TemplateManager templateManager ;
    @Autowired
    private DocumentService documentService ;
    @Autowired
    private freemarker.template.Configuration cfg ;

    @Autowired
    private PubAjJbDao ajJbRepostiy ;
    @Autowired
    private FtnqFtsysqdjDao ftnqFtsysqdjDao;
    private Logger logger = LoggerFactory.getLogger(TemplateServiceImpl.class) ;
    @Override
    public DocumentModel getAjglTemplate(YhModel user, int ajxh, int templateBh, int ktbh) {
        Map<String ,Object> data = templateManager.getTemplateData(user.getFydm(),ajxh,ktbh) ;
        try {

            AjGlTemplateTypeEnum ajGlTemplateTypeEnum = AjGlTemplateTypeEnum.findByBh(templateBh) ;
            String ah = (String) data.get("ah");
            if(StringUtil.isEmpty(ah)){
                logger.error("获取模板信息-案号为空,fydm:"+user.getFydm()+",ajxh:"+ajxh);
                throw new BaseException("案件信息错误") ;
            }
            String fileName = ah+"-"+ ajGlTemplateTypeEnum.getText()+".doc" ;
            /**
             * 构造模板文件xml格式，doc结尾
             */
            File file = documentService.getFile(user, null, fileName);
            PrintWriter writer = new PrintWriter(file, "UTF-8");
            Template template = cfg.getTemplate(ajGlTemplateTypeEnum.getTemplateFileName(),"UTF-8");
            template.process(data,writer);
            writer.flush();
            writer.close();

            /**
             * 将初步生成的文件转换为完整docx格式
             */
            WordprocessingMLPackage load = WordprocessingMLPackage.load(file);
            File newFile = documentService.getFile(user,null,ah+"-"+ ajGlTemplateTypeEnum.getText()+".docx") ;
            load.save(newFile, Docx4J.FLAG_SAVE_ZIP_FILE);
            return documentService.createDocumentBySavePath(newFile.getPath()) ;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(String.format("创建电子卷宗模板失败，fydm:%s,ajxh:%s,templateBh:%s,message:%s",user.getFydm(),ajxh,templateBh,e.getMessage()));
            throw new BaseException("创建模板失败") ;
        }
    }

    @Override
    public MlModel getTyTemplateMl() {
        return null;
    }

    @Override
    public MlModel getAjglTemplateMl(String fydm,int ajxh) {
        MlModel mlModel = new MlModel() ;
        mlModel.setMc("模板");
        mlModel = new MlModel() ;
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        PubAjJbDO ajXx = ajJbRepostiy.findByAjxh(ajxh);
        DynamicDataSource.router(curDB);
        String lb = ajXx.getAjxz()+ajXx.getSpcx() ;
        if(ajXx==null){
            throw new BaseException("根据法院代码："+fydm+"，案件序号ajxh:"+ajxh+"获取案件信息失败") ;
        }
        List<WdModel> templates = new ArrayList<>() ;
        for(AjGlTemplateTypeEnum templateTypeEnum:AjGlTemplateTypeEnum.getByLb(lb)){
            templates.add(fomateTemplateWdModel(templateTypeEnum)) ;
        }
        List<FtnqFtsysqdjDO> ktxx = ftnqFtsysqdjDao.findByAjxh(ajxh);
        if (ktxx.size() != 0) {
            templates.add(fomateTemplateWdModel(AjGlTemplateTypeEnum.KTBL));
        }
        mlModel.setWds(templates);
        return mlModel;
    }

    private WdModel fomateTemplateWdModel(AjGlTemplateTypeEnum ajGlTemplateTypeEnum){
        WdModel wdModel = new WdModel() ;
        wdModel.setId(ajGlTemplateTypeEnum.getId()+"");
        wdModel.setMc(ajGlTemplateTypeEnum.getText());
        wdModel.setWjsx(ajGlTemplateTypeEnum.getId());
        return wdModel ;
    }

    @Override
    public List<String> getKtxxByAjxh(int ajxh){
        List<String> result = new ArrayList<String>();
        List<FtnqFtsysqdjDO> ktxx = ftnqFtsysqdjDao.findByAjxh(ajxh);
        for (FtnqFtsysqdjDO kt : ktxx) {
            result.add(DateUtil.format(kt.getRq(),DateUtil.chineseDtFormat));
        }
        return result;
    }
}
