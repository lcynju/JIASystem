package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.AydmbDO;
import cn.edu.nju.software.data.dataobject.AydmbDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by 13314 on 2018/8/14.
 */
@Repository
public interface AyDmbDao extends JpaRepository<AydmbDO,AydmbDOId> {
    AydmbDO findByDmbh(String dmbh) ;
}
