package cn.edu.nju.software.service.model.events;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.ToString;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.io.Serializable;
import java.util.*;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:40
 * @Description
 */
@Data
@AllArgsConstructor
@ToString
public class BaseEvent {
    /**
     * 是否原告
     */
    private boolean isYg ;
    protected String trigger;
    private IndexPair trigger_index_pair ;
    private String sentence ;
    protected String negated ;

    //存储哪些索引的字需要被高亮
    protected List<ArrayList<Integer>> forRendaring ;

    private String renderedSentence ;
    protected String title ;
    public BaseEvent(HashMap<String,Object> map){
        this.trigger = (String) map.get("trigger");
        this.trigger_index_pair = new IndexPair((ArrayList<Integer>) map.get("trigger_index_pair")) ;

        this.sentence = (String) map.get("sentence");
        this.negated = (String) map.get("negated");
        forRendaring = new ArrayList<>(8) ;
//        forRendaring.add((ArrayList<Integer>) map.get("trigger_index_pair")) ;
        forRendaring.add((ArrayList<Integer>) map.get("negated_index_pair")) ;
    }
    public void render(){
        this.setTitle();
        this.setRenderSentence() ;
    }
    protected void setTitle(){
        throw new NotImplementedException() ;
    }
    private void setRenderSentence(){
        List<IndexPair> indexPairs = new ArrayList<>(this.forRendaring.size()) ;
        for(ArrayList<Integer> indexPair:forRendaring){
            if(indexPair==null){
                continue;
            }else {
                indexPairs.add(new IndexPair(indexPair)) ;
            }
        }

        //设置需要高亮的索引位置
        int[] ifRender = new int[this.sentence.length()] ;
        Arrays.fill(ifRender,0);

        //一般参数高亮用1标识
        for(IndexPair indexPair:indexPairs){
            for(int i=indexPair.beginIndex;i<indexPair.endIndex;i++){
                ifRender[i] = 1 ;
            }
        }

        //触发词高亮用2标识
        for(int i=trigger_index_pair.beginIndex;i<trigger_index_pair.endIndex;i++){
            ifRender[i] = 2 ;
        }

        StringBuilder sb = new StringBuilder();
        if(this.isYg){
            sb.append("原告： ") ;
        }else {
            sb.append("被告： ") ;
        }
        boolean isBeginRender = false ;
        int currentRenderType=0 ;
        char[] chars = this.sentence.toCharArray() ;
        for(int i=0;i<this.sentence.length();i++){
            if(ifRender[i]==1||ifRender[i]==2){
                if(isBeginRender){
                    if(currentRenderType==ifRender[i]) {
                        //连续render
                        sb.append(chars[i]);
                    }else {
                        //连在一起的但不是同一种render
                        //先结束上一个render
                        sb.append("</span>") ;
                        //开始下一个render
                        isBeginRender = true ;
                        currentRenderType = ifRender[i] ;
                        if(currentRenderType==1) {
                            sb.append("<span class='highlight'>");
                        }else {
                            sb.append("<span class='highlight2'>") ;
                        }
                        sb.append(chars[i]) ;
                    }
                }else {
                    //开始一个render
                    isBeginRender = true ;
                    currentRenderType = ifRender[i] ;
                    if(currentRenderType==1) {
                        sb.append("<span class='highlight'>");
                    }else {
                        sb.append("<span class='highlight2'>") ;
                    }
                    sb.append(chars[i]) ;
                }
            }else {
                if(isBeginRender){
                    //结束一个render
                    sb.append("</span>") ;
                    sb.append(chars[i]) ;
                    isBeginRender = false ;
                }else {
                    sb.append(chars[i]) ;
                }
            }
        }

        this.renderedSentence = sb.toString() ;
    }

    @Data
    class IndexPair implements Comparable<IndexPair>,Serializable{
        int beginIndex ;
        int endIndex ;
        IndexPair(ArrayList<Integer> ints){
//            String[] split = str.split(",");
//            beginIndex = Integer.parseInt(split[0].trim().substring(1)) ;
//            endIndex = Integer.parseInt(split[1].trim().substring(0,split[1].trim().length()-1)) ;
            beginIndex = ints.get(0);
            endIndex = ints.get(1) ;
        }

        @Override
        public int compareTo(IndexPair o) {
            return beginIndex-o.beginIndex;
        }
    }
}
