package cn.edu.nju.software.service;


import cn.edu.nju.software.service.model.Dsr;
import cn.edu.nju.software.service.model.Ssr;

import java.util.List;
import java.util.Map;

/**
 * 当事人service
 * @author 13314
 * @date 2018/8/10
 */
public interface DsrService {
    List<Ssr> getDsrXxByAjxh(String fydm, int ajxh) ;
}
