package cn.edu.nju.software.data.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;
import java.util.Map;

/**
 * Created by 13314 on 2018/9/13.
 */
@Repository
public class SqlDao{
    @PersistenceContext
    private EntityManager em ;
    public List<Object[]> excuSql(String sql){
//        List<Map<String, Object>> maps = getJdbcTemplate().queryForList(sql);
        Query nativeQuery = em.createNativeQuery(sql);
        List resultList = nativeQuery.getResultList();
        return resultList ;
    }
}
