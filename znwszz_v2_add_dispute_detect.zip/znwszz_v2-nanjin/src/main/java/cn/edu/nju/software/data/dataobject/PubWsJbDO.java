package cn.edu.nju.software.data.dataobject;

import javax.persistence.*;
import java.util.Arrays;

/**
 * @author 13314
 */
@Entity
@Table(name="PUB_WS_JB")
@IdClass(PubWsJbIdDO.class)
public class PubWsJbDO implements java.io.Serializable {

	private Integer ajxh;
	private Integer wsjbbh;
	private String wslb;
	private String wsmc;
	private byte[] wsnr;
	private String wswjm;
	
	public PubWsJbDO() {
	}
	
	public PubWsJbDO(Integer ajxh, Integer wsjbbh) {
		this.ajxh = ajxh;
		this.wsjbbh = wsjbbh;
	}
	
	public PubWsJbDO(Integer ajxh, Integer wsjbbh, String wslb, String wsmc, byte[] wsnr, String wswjm) {
		this.ajxh = ajxh;
		this.wsjbbh = wsjbbh;
		this.wslb = wslb;
		this.wsmc = wsmc;
		this.wsnr = wsnr;
		this.wswjm = wswjm;
	}
	
	@Column(name="AJXH", nullable=false)
	@Id
    public Integer getAjxh() {
        return this.ajxh;
    }
    
    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }
    
    @Column(name="WSJBBH", nullable=false)
    @Id
    public Integer getWsjbbh() {
    	return this.wsjbbh;
    }
    
    public void setWsjbbh(Integer wsjbbh) {
        this.wsjbbh = wsjbbh;
    }
    
    @Column(name = "WSLB", length = 50)
	public String getWslb() {
		return this.wslb;
	}

    public void setWslb(String wslb) {
    	this.wslb = wslb;
    }
    
    @Column(name = "WSMC", length = 255)
	public String getWsmc() {
		return this.wsmc;
	}

    public void setWsmc(String wsmc) {
    	this.wsmc = wsmc;
    }

	@Column(name="WSNR")
	public byte[] getWsnr() {
		return this.wsnr;
	}

	public void setWsnr(byte[] wsnr) {
		this.wsnr = wsnr;
	}

	@Column(name="WSWJM")
	public String getWswjm() {
		return this.wswjm;
	}

	public void setWswjm(String wswjm) {
		this.wswjm = wswjm;
	}

    @Override
    public String toString() {
        return "PubWsJbDO{" +
                "ajxh=" + ajxh +
                ", wsjbbh=" + wsjbbh +
                ", wslb='" + wslb + '\'' +
                ", wsmc='" + wsmc + '\'' +
                ", wswjm='" + wswjm + '\'' +
                '}';
    }
}
