package cn.edu.nju.software.service.model.enums;

import java.util.regex.Pattern;

/**
 * Created by 13314 on 2018/9/13.
 */
public enum YsXxEnum {
    /**
     * 原审信息枚举
     */
    SPJD(1,"PUB_LA_SPJD","YSXAH","YSXCPFY","审判监督","^[126]34.{0,2}|^[126]3") ,
    ZX(2,"ZX_JB","YSAH","YSFY","执行","^8.{1,3}") ,
    XS(3,"Y_LA_ES","YSAH","YSFY","刑事二审","^12.{0,2}") ,
    MSXZ(4,"MJZX_LA_SS","YSAH","YSFY","民事、行政二审","^[26]2.{0,2}") ,
    SQZS(5,"SSFC_LA","YSAH","YSFY","申请再审","^[125]3[123]|^.A")
    ;
    private int bh ;
    private String table ;
    private String ysah ;
    private String ysfy ;
    private String mc ;
    private String exp ;

    YsXxEnum(int bh, String table, String ysah, String ysfy, String mc, String exp) {
        this.bh = bh;
        this.table = table;
        this.ysah = ysah;
        this.ysfy = ysfy;
        this.mc = mc;
        this.exp = exp;
    }
    public static YsXxEnum getAjYsXxEnum(String ajxzSpcxSpcxdz){
        for(YsXxEnum ysXxEnum:YsXxEnum.values()){
            if(Pattern.matches(ysXxEnum.exp,ajxzSpcxSpcxdz)){
                return ysXxEnum ;
            }
        }
        return null ;
    }

    public int getBh() {
        return bh;
    }

    public String getTable() {
        return table;
    }

    public String getYsah() {
        return table+"."+ysah;
    }

    public String getYsfy() {
        return table+"."+ysfy;
    }

    public String getMc() {
        return mc;
    }

    public String getExp() {
        return exp;
    }
}
