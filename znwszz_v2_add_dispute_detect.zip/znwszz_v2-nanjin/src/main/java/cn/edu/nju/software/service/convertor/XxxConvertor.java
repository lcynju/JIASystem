package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.XxxglDO;
import cn.edu.nju.software.service.model.XxxModel;
import cn.edu.nju.software.service.model.enums.DataTypeEnum;

/**
 *
 * @author 13314
 * @date 2018/8/13
 */
public class XxxConvertor {
    public static XxxModel DO2Model(XxxglDO DO){
        DataTypeEnum dataTypeEnum = DataTypeEnum.getEnumByBh(DO.getDatatype()) ;
        XxxModel xxxModel = new XxxModel() ;
        xxxModel.setDatatype(dataTypeEnum);
        xxxModel.setFybh(DO.getFybh());
        xxxModel.setName(DO.getName());
        xxxModel.setSjxx(DO.getSjxx());
        xxxModel.setSjxx2016(DO.getSjxx2016());
        xxxModel.setSzb(DO.getSzb());
        xxxModel.setSzl(DO.getSzl());
        xxxModel.setXxxbh(DO.getXxxbh());
        xxxModel.setXxxjc(DO.getXxxjc());
        return xxxModel ;
    }
}
