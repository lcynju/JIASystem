package cn.edu.nju.software.service.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *  目录下文档model
 * @author 13314
 * @date 2018/7/30
 */
@ApiModel
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WdModel {

    @ApiModelProperty(value = "文档id")
    private String id ;
    @ApiModelProperty(value = "文档名称")
    private String mc ;
    @ApiModelProperty(value = "文档显示顺序，已排序")
    private Integer wjsx ;

    @Override
    public String toString() {
        return "WdModel{" +
                "id='" + id + '\'' +
                ", mc='" + mc + '\'' +
                ", wjsx=" + wjsx +
                '}';
    }
}
