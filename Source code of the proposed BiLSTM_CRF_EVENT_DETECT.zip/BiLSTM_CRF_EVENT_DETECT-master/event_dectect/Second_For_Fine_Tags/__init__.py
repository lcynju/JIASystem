#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__doc__ = 'description 第二个在第一个粗粒度标签结果的基础上，预测精细标签'
__author__ = '13314409603@163.com'

if __name__ == '__main__':
    pass