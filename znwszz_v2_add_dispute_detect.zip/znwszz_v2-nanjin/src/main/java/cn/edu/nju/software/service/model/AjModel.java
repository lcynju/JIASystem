package cn.edu.nju.software.service.model;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.models.auth.In;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

/**
 * Created by 13314 on 2018/7/30.
 */
@Data
@ApiModel
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AjModel {
    @ApiModelProperty(value = "案件序号，在每家法院内具有唯一性")
    private Integer ajxh ;
    @ApiModelProperty(value = "案号，在全市范围内具有唯一性")
    private String ah ;
    @ApiModelProperty(value = "案件名称")
    private String ajmc ;
    @ApiModelProperty(value = "案件性质，1-刑事，2-民事，6-行政，8-执行")
    private String ajxz ;
    @ApiModelProperty(value = "审判程序，1-一审，2-二审，3-再审")
    private String spcx ;
    @ApiModelProperty(value = "审判程序代字，辅助spcx字段确定案件信息")
    private String spcxdz ;
    @ApiModelProperty(value = "办案审判庭代码，具体名称和具体法院关联")
    private String baspt ;
    @ApiModelProperty(value = "立案日期")
    private Date larq ;
    @ApiModelProperty(value = "结案日期")
    private Date jarq ;
}
