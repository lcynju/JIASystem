package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DzdaWdWjjDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by 13314 on 2018/9/12.
 */
public interface DzdaWdWjjDao extends JpaRepository<DzdaWdWjjDO,String> {
    /**
     * 根据文档案号Id后去文件list
     * @param wdAjId
     * @return
     */
    List<DzdaWdWjjDO> findByWjjssah(String wdAjId) ;
}
