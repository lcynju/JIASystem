package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DzdaWdWjDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Created by 13314 on 2018/9/12.
 */
public interface DzdaWdWjDao extends JpaRepository<DzdaWdWjDO,String> {
    /**
     * 根据所属文件夹Id获取文件list
     * @param wjjId
     * @return
     */
    List<DzdaWdWjDO> findByWjsswjj(String wjjId) ;

    /**
     * 根据文档id获取文档
     * @param wdId
     * @return
     */
    DzdaWdWjDO findByWjid(String wdId) ;
}
