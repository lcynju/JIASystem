package cn.edu.nju.software.manager;

import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.enums.FileTypeEnum;
import cn.edu.nju.software.service.model.exception.CreateDocumentException;
import cn.edu.nju.software.util.DocumentUtil;
import cn.edu.nju.software.util.UrlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.net.UnknownHostException;

/**
 *  文档创建工厂
 * @author 13314
 * @date 2018/8/16
 */
@Component
public class DocumentModelFactory {
    /**
     * 下载文档url模板
     */
    private final String DOWNLOAD_URL_TEMPLATE = "http://%s:%s/download?wdId=%s";

    /**
     * 提供给document回调存储编辑之后文档的url模板
     */
    private final String CALLBACK_URL_TEMPLATE = "http://%s:%s/save?wdId=%s";

    private Logger logger = LoggerFactory.getLogger(DocumentModelFactory.class) ;
    @Value("${server.port}")
    private String port ;

    public DocumentModel createDocumentModelByNameAndKey(String docName,String docKey){
        DocumentModel documentModel = new DocumentModel() ;
        try{
            documentModel.setName(docName);
            documentModel.setWdId(docKey);

            FileTypeEnum fileTypeEnum = FileTypeEnum.findBySuffixName(DocumentUtil.getFileExtension(docName));
            documentModel.setDocumentType(fileTypeEnum.getDocumentType());

            String ext = DocumentUtil.getFileExtension(docName);
            Assert.notNull(ext, "文件扩展名不能为空");
            String fileType = ext.substring(1);
            documentModel.setFileType(fileType);

            String key = DocumentUtil.GenerateRevisionId(docKey);
            documentModel.setKey(key);

            String url = String.format(DOWNLOAD_URL_TEMPLATE, UrlUtil.getHostAddress(), port, docKey);

            documentModel.setUrl(url);

            String callbackUrl = String.format(CALLBACK_URL_TEMPLATE, UrlUtil.getHostAddress(), port, docKey);
            documentModel.setCallBackUrl(callbackUrl);
        } catch (UnknownHostException e) {
            logger.error("获取服务器本机ip失败:"+e.getMessage());
            throw new CreateDocumentException(docKey) ;
        } catch (Exception e){
            logger.error("创建Document:"+docKey+"失败:"+e.getMessage());
            throw new CreateDocumentException(docKey) ;
        }
        return documentModel ;
    }


}
