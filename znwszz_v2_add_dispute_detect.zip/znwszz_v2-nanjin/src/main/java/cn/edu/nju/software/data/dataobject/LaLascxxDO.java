package cn.edu.nju.software.data.dataobject;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author 13314409603@163.com
 * @date 2018/10/31
 * @time 15:53
 * @Description
 */


/**
 * LaLascxxDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_LA_LASCXX")
public class LaLascxxDO implements java.io.Serializable {

    // Fields

    private Integer ajxh;
    private String ssqqjly;
    private Date sdszrq;
    private String gxly;
    private String tnscyj;
    private String tnscr;
    private Date tnscrq;
    private String tnspyj;
    private String tnspr;
    private Date tnsprq;
    private String ynspyj;
    private String ynspr;
    private Date ynsprq;
    private String bz;
    private Date szbzrq;
    private String scjg;
    private String spjg;
    private String gxlydm;

    // Constructors

    /** default constructor */
    public LaLascxxDO() {
    }

    /** minimal constructor */
    public LaLascxxDO(Integer ajxh) {
        this.ajxh = ajxh;
    }

    /** full constructor */
    public LaLascxxDO(Integer ajxh, String ssqqjly, Date sdszrq, String gxly,
                      String tnscyj, String tnscr, Date tnscrq, String tnspyj,
                      String tnspr, Date tnsprq, String ynspyj, String ynspr,
                      Date ynsprq, String bz, Date szbzrq, String scjg, String spjg,
                      String gxlydm) {
        this.ajxh = ajxh;
        this.ssqqjly = ssqqjly;
        this.sdszrq = sdszrq;
        this.gxly = gxly;
        this.tnscyj = tnscyj;
        this.tnscr = tnscr;
        this.tnscrq = tnscrq;
        this.tnspyj = tnspyj;
        this.tnspr = tnspr;
        this.tnsprq = tnsprq;
        this.ynspyj = ynspyj;
        this.ynspr = ynspr;
        this.ynsprq = ynsprq;
        this.bz = bz;
        this.szbzrq = szbzrq;
        this.scjg = scjg;
        this.spjg = spjg;
        this.gxlydm = gxlydm;
    }

    // Property accessors
    @Id
    @Column(name = "AJXH", unique = true, nullable = false)
    public Integer getAjxh() {
        return this.ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name = "SSQQJLY")
    public String getSsqqjly() {
        return this.ssqqjly;
    }

    public void setSsqqjly(String ssqqjly) {
        this.ssqqjly = ssqqjly;
    }

    @Column(name = "SDSZRQ", length = 23)
    public Date getSdszrq() {
        return this.sdszrq;
    }

    public void setSdszrq(Date sdszrq) {
        this.sdszrq = sdszrq;
    }

    @Column(name = "GXLY", length = 250)
    public String getGxly() {
        return this.gxly;
    }

    public void setGxly(String gxly) {
        this.gxly = gxly;
    }

    @Column(name = "TNSCYJ", length = 250)
    public String getTnscyj() {
        return this.tnscyj;
    }

    public void setTnscyj(String tnscyj) {
        this.tnscyj = tnscyj;
    }

    @Column(name = "TNSCR", length = 50)
    public String getTnscr() {
        return this.tnscr;
    }

    public void setTnscr(String tnscr) {
        this.tnscr = tnscr;
    }

    @Column(name = "TNSCRQ", length = 23)
    public Date getTnscrq() {
        return this.tnscrq;
    }

    public void setTnscrq(Date tnscrq) {
        this.tnscrq = tnscrq;
    }

    @Column(name = "TNSPYJ", length = 250)
    public String getTnspyj() {
        return this.tnspyj;
    }

    public void setTnspyj(String tnspyj) {
        this.tnspyj = tnspyj;
    }

    @Column(name = "TNSPR", length = 50)
    public String getTnspr() {
        return this.tnspr;
    }

    public void setTnspr(String tnspr) {
        this.tnspr = tnspr;
    }

    @Column(name = "TNSPRQ", length = 23)
    public Date getTnsprq() {
        return this.tnsprq;
    }

    public void setTnsprq(Date tnsprq) {
        this.tnsprq = tnsprq;
    }

    @Column(name = "YNSPYJ", length = 250)
    public String getYnspyj() {
        return this.ynspyj;
    }

    public void setYnspyj(String ynspyj) {
        this.ynspyj = ynspyj;
    }

    @Column(name = "YNSPR", length = 50)
    public String getYnspr() {
        return this.ynspr;
    }

    public void setYnspr(String ynspr) {
        this.ynspr = ynspr;
    }

    @Column(name = "YNSPRQ", length = 23)
    public Date getYnsprq() {
        return this.ynsprq;
    }

    public void setYnsprq(Date ynsprq) {
        this.ynsprq = ynsprq;
    }

    @Column(name = "BZ", length = 200)
    public String getBz() {
        return this.bz;
    }

    public void setBz(String bz) {
        this.bz = bz;
    }

    @Column(name = "SZBZRQ", length = 23)
    public Date getSzbzrq() {
        return this.szbzrq;
    }

    public void setSzbzrq(Date szbzrq) {
        this.szbzrq = szbzrq;
    }

    @Column(name = "SCJG", length = 10)
    public String getScjg() {
        return this.scjg;
    }

    public void setScjg(String scjg) {
        this.scjg = scjg;
    }

    @Column(name = "SPJG", length = 10)
    public String getSpjg() {
        return this.spjg;
    }

    public void setSpjg(String spjg) {
        this.spjg = spjg;
    }

    @Column(name = "GXLYDM", length = 10)
    public String getGxlydm() {
        return this.gxlydm;
    }

    public void setGxlydm(String gxlydm) {
        this.gxlydm = gxlydm;
    }

}
