package cn.edu.nju.software.service.model.events;

import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:46
 * @Description
 */
public class FamilyConfilct extends BaseEvent {
    public FamilyConfilct(HashMap<String,Object> map){
        super(map);
    }
    @Override
    /**
     * negated: trigger
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }

        this.title = str ;
    }
}
