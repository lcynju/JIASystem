package cn.edu.nju.software.service.model.events;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:47
 * @Description
 */
public class DomesticViolence extends BaseEvent {
    private String time ;
    private String perpetrator ;
    private String victim ;

    public DomesticViolence(HashMap<String,Object> map){
        super(map);
        this.time = (String) map.get("time");
        this.forRendaring.add((ArrayList<Integer>) map.get("time_index_pair")) ;

        this.perpetrator = (String) map.get("perpetrator");
        this.forRendaring.add((ArrayList<Integer>) map.get("perpetrator_index_pair")) ;

        this.victim = (String) map.get("victim");
        this.forRendaring.add((ArrayList<Integer>) map.get("victim_index_pair")) ;
    }
    @Override
    /**
     * negated: time perpetrator trigger victim
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.time!=null && this.time.length()>0){
            if(str.length()>0){
                str = str +" "+this.time ;
            }else {
                str = this.time ;
            }
        }
        if(this.perpetrator!=null && this.perpetrator.length()>0){
            if(str.length()>0){
                str = str +" "+this.perpetrator ;
            }else {
                str = this.perpetrator ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.victim!=null && this.victim.length()>0){
            str = str+" "+this.victim ;
        }

        this.title = str ;
    }
}
