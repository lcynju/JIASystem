package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.PubAjJbDao;
import cn.edu.nju.software.data.dao.SqlDao;
import cn.edu.nju.software.data.dao.SsxxDao;
import cn.edu.nju.software.data.dataobject.PubAjJbDO;
import cn.edu.nju.software.data.dataobject.PubSsxxDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.AjService;
import cn.edu.nju.software.service.convertor.AjConvertor;
import cn.edu.nju.software.service.model.AjModel;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.enums.YsXxEnum;
import cn.edu.nju.software.util.DateUtil;
import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/7/30
 */
@Service("ajService")
public class AjServiceImpl implements AjService {
    private PubAjJbDao ajJbRepostiy ;
    @Autowired
    private SqlDao sqlDao ;
    @Autowired
    private SsxxDao ssxxDao ;
    @Autowired
    public AjServiceImpl(PubAjJbDao ajJbRepostiy) {
        this.ajJbRepostiy = ajJbRepostiy;
    }

    @Override
    public List<AjModel> getZbByName(String fydm,String name) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<PubAjJbDO> wjAjs = ajJbRepostiy.getZb(name);
        List<AjModel> ajModels = new ArrayList<>() ;
        if(wjAjs==null||wjAjs.isEmpty()) {
            return ajModels;
        }
        for (PubAjJbDO aj:wjAjs){
            ajModels.add(AjConvertor.ajDO2AjModel(aj)) ;
        }
        DynamicDataSource.router(curDB);
        return ajModels;

    }

    @Override
    public List<AjModel> getYjByName(String fydm,String begin,String end,String name) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<PubAjJbDO> yjAjs = ajJbRepostiy.getYj(begin,end,name);
        List<AjModel> ajModels = new ArrayList<>() ;
        if(yjAjs==null||yjAjs.isEmpty()) {
            return ajModels;
        }
        for (PubAjJbDO aj:yjAjs){
            ajModels.add(AjConvertor.ajDO2AjModel(aj)) ;
        }
        DynamicDataSource.router(curDB);
        return ajModels;
    }

    @Override
    public List<AjModel> getCsByName(String fydm,String name) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<PubAjJbDO> csAjs = ajJbRepostiy.getCs(name);
        List<AjModel> ajModels = new ArrayList<>() ;
        if(csAjs==null||csAjs.isEmpty()) {
            return ajModels;
        }
        for (PubAjJbDO aj:csAjs){
            ajModels.add(AjConvertor.ajDO2AjModel(aj)) ;
        }
        DynamicDataSource.router(curDB);
        return ajModels;
    }

    @Override
    public boolean checkAccess(String fydm, String name, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        int i = ajJbRepostiy.checkAccess(name, ajxh);
        DynamicDataSource.router(curDB);
        if(i>0) {
            return true;
        }
        return false;
    }

    @Override
    public String[] getYsfyAndYsah(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        PubAjJbDO ajXx = ajJbRepostiy.findByAjxh(ajxh);
        if(ajXx==null){
            return null ;
        }
        String dm = ajXx.getAjxz()+ajXx.getSpcx() ;
        /**
         * 2016后需要考虑spcxdz
         */
        if(DateUtil.compareDate(ajXx.getLarq(), DateUtil.createDate(2016,1,1))>=0){
            dm = dm + (ajXx.getSpcxdz()==null?"":ajXx.getSpcxdz()) ;
        }
        YsXxEnum ajYsXxEnum = YsXxEnum.getAjYsXxEnum(dm);
        if(ajYsXxEnum==null){
            return null ;
        }
        String ysajSql = "SELECT %s , %s FROM %s WHERE AJXH= %s" ;
        ysajSql = String.format(ysajSql, ajYsXxEnum.getYsah(), ajYsXxEnum.getYsfy(), ajYsXxEnum.getTable(),ajxh);
        List<Object[]> objects = sqlDao.excuSql(ysajSql);
        String[] ysfyAndYsah = null ;
        if(objects!=null&&!objects.isEmpty()){
            ysfyAndYsah = new String[2] ;
            /**
             * 获取原审法院，如果原审法院未填写，则默认为本法院
             */
            ysfyAndYsah[0] = (String)objects.get(0)[1]==null?fydm:(String)objects.get(0)[1];

            ysfyAndYsah[1]= ((String)objects.get(0)[0]).trim() ;
        }
        DynamicDataSource.router(curDB);
        return ysfyAndYsah ;
    }

    @Override
    public List<String[]> getGlaj(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);

        List<String[]> fyAndAjxh = new ArrayList<>() ;

        /**
         * 向后挖掘
         */
        DynamicDataSource.router(fydm);

        //先获取上诉信息
        PubSsxxDO ssxxDO = ssxxDao.findByAjxh(ajxh);
        while(ssxxDO!=null){
            //默认上诉案件一定是在上级法院
            FyEnum sjFy = FyEnum.getSjFy(fydm);
            //去上级法院拿去 上诉案件基本信息
            DynamicDataSource.router(sjFy.getFydm());
            PubAjJbDO jbDO = ajJbRepostiy.findByAh(ssxxDO.getEsah());
            if(jbDO==null){
                break;
            }else {
                fyAndAjxh.add(new String[]{sjFy.getFydm(),ssxxDO.getEsah(),jbDO.getAjxh()+""}) ;
                ssxxDO = ssxxDao.findByAjxh(jbDO.getAjxh()) ;
            }
        }

        /**
         * 向前挖掘
         */
        //获取原审信息
        String[] ysfyAndYsah = getYsfyAndYsah(fydm, ajxh);
        while (ysfyAndYsah!=null){
            //去原审法院获取原审案件基本信息
            DynamicDataSource.router(ysfyAndYsah[0]);
            PubAjJbDO jbDO = ajJbRepostiy.findByAh(ysfyAndYsah[1]);
            if(jbDO!=null){
                fyAndAjxh.add(new String[]{ysfyAndYsah[0],ysfyAndYsah[1],jbDO.getAjxh()+""}) ;
                ysfyAndYsah = getYsfyAndYsah(ysfyAndYsah[0],jbDO.getAjxh()) ;
            }else{
                //如果原审案件不存在，则跳出
                break ;
            }
        }

        return fyAndAjxh;
    }

    @Override
    public List<AjModel> getYjajList(String fydm,String begin, String end) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<PubAjJbDO> yj = ajJbRepostiy.getYj(begin, end);
        List<AjModel> ajModels = new ArrayList<>() ;
        if(yj==null||yj.isEmpty()) {
            return ajModels;
        }
        for (PubAjJbDO aj:yj){
            ajModels.add(AjConvertor.ajDO2AjModel(aj)) ;
        }
        DynamicDataSource.router(curDB);
        return ajModels;
    }

    @Override
    public List<AjModel> findByAy(String fydm,String ay,String begin,String end) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<PubAjJbDO> yj = ajJbRepostiy.getByAy("%"+ay+"%",begin,end);
        List<AjModel> ajModels = new ArrayList<>() ;
        if(yj==null||yj.isEmpty()) {
            return ajModels;
        }
        for (PubAjJbDO aj:yj){
            ajModels.add(AjConvertor.ajDO2AjModel(aj)) ;
        }
        DynamicDataSource.router(curDB);
        return ajModels;
    }
}
