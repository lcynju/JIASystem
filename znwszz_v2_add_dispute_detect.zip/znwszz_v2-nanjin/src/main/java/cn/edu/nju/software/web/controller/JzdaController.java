package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.*;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.thread.OcrThread;
import cn.edu.nju.software.util.StringUtil;
import cn.edu.nju.software.util.UserUtil;
import cn.edu.nju.software.web.vo.OcrResult;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @author 13314
 * @date 2018/7/30
 */
@Api(tags = "卷宗档案相关接口")
@RestController
public class JzdaController {
    @Autowired
    private DzjzWjService dzjzWjService;
    @Autowired
    private AjService ajService;
    @Autowired
    private WsService wsService;
    @Autowired
    private DzdaWjService dzdaWjService;

    @Autowired
    private DocumentService documentService ;
//    @Autowired
//    private StringRedisTemplate stringRedisTemplate;

    private Logger logger = Logger.getLogger(JzdaController.class);

    @ApiOperation(value = "获取单个案件电子卷宗、法律文书等档案目录，必须账户已登陆")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ajxh", value = "案件序号", required = true, paramType = "query")
    })
    @GetMapping("/getDzjzWdMl")
    public ResultVO<MlModel> getWdMlByAjxh(HttpServletRequest request, int ajxh) {
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        if (user == null) {
            throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
        }
        List<MlModel> mlModels = null;
        boolean checkAccess = ajService.checkAccess(user.getFydm(), user.getName(), ajxh);
        if (checkAccess) {
            mlModels = new ArrayList<>();
            /**
             * 档案卷宗模块目前展示电子卷宗、基表文书、原审档案
             */

            //电子卷宗目录
            mlModels.add(dzjzWjService.getDzjzMlByAjxh(user.getFydm(), ajxh));

            //文书信息目录
            mlModels.add(wsService.getWsMlByAjxh(user.getFydm(), ajxh));

            //原审档案目录
            /**
             * 先获取原审信息
             */
            String[] ysfyAndYsah = ajService.getYsfyAndYsah(user.getFydm(), ajxh);
            /**
             * 获取原审目录,即电子档案信息
             */
            if (ysfyAndYsah != null) {
                mlModels.add(dzdaWjService.getDzdaMlByAjxh(ysfyAndYsah[0], ysfyAndYsah[1]));
            }

            //关联案件
            List<String[]> glajs = ajService.getGlaj(user.getFydm(), ajxh);
            if(glajs!=null&&!glajs.isEmpty()){
                //关联案件总目录
                MlModel glMl = new MlModel() ;
                glMl.setMc(DocSourceEnum.GLAJ.getMc());
                glMl.setId(DocSourceEnum.GLAJ.getPrefix());
                glMl.setXssx(DocSourceEnum.GLAJ.getXssx());

                //存储每个案件
                List<MlModel> ajMls = new ArrayList<>() ;
                for(int i=0;i<glajs.size();i++){
                    //每个关联案件目录
                    String[] glaj = glajs.get(i) ;
                    MlModel glajMl = new MlModel() ;
                    glajMl.setMc(glaj[1]);
                    glajMl.setId(glaj[0]+"_"+glaj[2]);
                    glajMl.setXssx(i);
                    //获取每个关联案件的电子卷宗信息和文书基表信息
                    List<MlModel> zml = new ArrayList<>(2) ;
                    MlModel dzjzMl = dzjzWjService.getDzjzMlByAjxh(glaj[0],Integer.parseInt(glaj[2]));
                    if(dzjzMl!=null){
                        zml.add(dzjzMl) ;
                    }
                    MlModel wsMl = wsService.getWsMlByAjxh(glaj[0],Integer.parseInt(glaj[2])) ;
                    if(wsMl!=null){
                        zml.add(wsMl) ;
                    }
                    glajMl.setZml(zml);

                    ajMls.add(glajMl) ;
                }
                glMl.setZml(ajMls);
                mlModels.add(glMl) ;
            }
        } else {
            throw new BaseException("用户无权限访问该案件");
        }
        ResultVO resultVO = new ResultVO<MlModel>();
        resultVO.setSucceed(true);
        resultVO.setObject(mlModels);
        return resultVO;
    }

    @ApiOperation(value = "获取单个电子卷宗文档类型文件，必须账户已登陆")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId", value = "文档id", required = true, paramType = "query")
    })
    @GetMapping("/getDzjzWd")
    public ResultVO<DocumentModel> getWd(HttpServletRequest request, String wdId) {
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        if (user == null) {
            throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
        }
        if (StringUtil.isEmpty(wdId)) {
            throw new BaseException("文档id为空");
        }
        /**
         * 文档可能来自与电子卷宗、文书基表，通过prefix区分
         */
        DocumentModel document = null;
        if (wdId.startsWith(DocSourceEnum.DZJZ.getPrefix())) {
            document = dzjzWjService.getDzjzDocumentModel(wdId);
        } else if (wdId.startsWith(DocSourceEnum.WSXX.getPrefix())) {
            document = wsService.getWsDocumentModel(wdId);
        } else if(wdId.startsWith(DocSourceEnum.YSDA.getPrefix())) {
            document = dzdaWjService.getDzjzDocumentModel(wdId) ;
        }else {
                throw new BaseException("文档id无法识别");
        }
        ResultVO resultVO = new ResultVO<DocumentModel>();
        resultVO.setSucceed(true);
        resultVO.setObject(document);
        return resultVO;
    }

    @ApiOperation(value = "获取电子卷宗图片ocr识别结果")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "wdId", value = "目标文档id", required = true),
            @ApiImplicitParam(name = "ajxh", value = "文档所属案件序号", required = true),
    })
    @PostMapping("/getOcr")
    public ResultVO<OcrResult> getOcrResult(HttpServletRequest request, String wdId, int ajxh) {
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        if (user == null) {
            throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
        }
        if (StringUtil.isEmpty(wdId)) {
            throw new BaseException("文档id为空");
        }
        if (wdId.startsWith(DocSourceEnum.DZJZ.getPrefix())) {
            String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);
            Map<String, ArrayList<String>> ajWdsOcrResult = dzjzWjService.getOcrResult(ajxh, user.getFydm());
            String key = FyEnum.findByFydm(user.getFydm()).getFybh() + "_0_" + split_wdId[1];
            ArrayList<String> wdOcrResultList = ajWdsOcrResult.get(key);
            if (wdOcrResultList == null || wdOcrResultList.isEmpty()) {
                logger.error(String.format("法院%s案件%s文档%socr识别结果为空", user.getFydm(), ajxh, wdId));
                throw new BaseException("无该文档ocr识别结果");
            }
            ResultVO result = new ResultVO<OcrResult>();
            result.setSucceed(true);
            OcrResult ocrResult = new OcrResult(wdId, wdOcrResultList.get(0));
            result.setObject(ocrResult);
            return result;
        } else {
            logger.error(String.format("法院%s案件%s文档%socr识别,文档id格式错误，只支持电子卷宗文档", user.getFydm(), ajxh, wdId));
            throw new BaseException("文档id格式错误");
        }
    }

    @PostMapping("/getOcrResultAll")
    public ResultVO getOcrResultAll(HttpServletRequest request, String wdIdListString, Integer ajxh) {
//        YhModel user = UserUtil.checkUserLogin(request);
//        String[] wdIdList = wdIdListString.split("__");
//        if (wdIdList.length == 0) {
//            throw new BaseException("文档id为空");
//        }
//
//        String session_key = user.getDm() + "_" + ajxh + "_ocr_map";
        ResultVO result = new ResultVO<OcrResult>();
//        Map<Object, Object> ocrResultMap = stringRedisTemplate.opsForHash().entries(session_key);
//        Set ocrResultKeys = ocrResultMap.keySet();
//        for (String wdId : wdIdList) {
//            OcrThread ocrThread = new OcrThread();
//            if (!ocrResultKeys.contains(wdId)) {
//                ocrThread.initOcrModel(stringRedisTemplate, user, ajxh, wdId, dzjzWjService);
//                Thread thread = new Thread(ocrThread);
//                thread.start();
//            }
//
//        }

        result.setSucceed(true);
        result.setMessage("开启OCR多线程成功");
        return result;
    }

    @PostMapping("/checkOcrResult")
    public ResultVO checkOcrResult(HttpServletRequest request, String ajxh) {
        YhModel user = UserUtil.checkUserLogin(request);
        String session_key = user.getDm() + "_" + ajxh + "_ocr_map";
//        Map<Object, Object> ocrResultMap = stringRedisTemplate.opsForHash().entries(session_key);
        ResultVO resultVO = new ResultVO();
        resultVO.setSucceed(true);
//        resultVO.setObject(ocrResultMap);
        return resultVO;
    }

    @ApiOperation(value = "将本地文档存入电子卷宗")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ajxh",value = "案件序号",required = true) ,
            @ApiImplicitParam(name = "wdId",value = "文档Id,目前只支持服务器本地文档，即以local_开头",required = true),
            @ApiImplicitParam(name = "newFileName",value = "上传到电子卷宗时，确定上传文件的名称,必须以.doc结尾")
    })
    @PostMapping("saveToDzjz")
    public ResultVO<DocumentModel> saveToDzjz(HttpServletRequest request,String ajxh,String wdId,String newFileName) throws IOException {
        logger.info("将本地文档存入电子卷宗：ajxh-"+ajxh+"wdId-"+wdId);
        YhModel yhModel = UserUtil.checkUserLogin(request);
        ResultVO resultVO = new ResultVO() ;
        if(StringUtil.isEmpty(ajxh)){
            logger.error("案件序号为空");
            resultVO.setSucceed(false);
            resultVO.setMessage("案件序号为空");
        }
        if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
            DocumentModel documentModel = null ;
            String[] split = wdId.split(DocSourceEnum.CONNECTOR);
            //如果没有新文件名，则使用原文件名
            if(StringUtil.isEmpty(newFileName)){
                newFileName = split[1] ;
            }
            //如果新文件名和原文件名不同，则调用更新文件名操作
            if(!StringUtil.equals(split[1],newFileName)){
//                documentModel = documentService.updateDocumentName(split[1],newFileName);
                documentModel = documentService.updateDocumentNameByYhmodelAndIpAddress(yhModel,null,split[1],newFileName) ;
            }
            //上传
            dzjzWjService.uploadFileToDzjz(yhModel,Integer.parseInt(ajxh), newFileName,documentService.getFile(yhModel,null,newFileName));
            resultVO.setSucceed(true);
            resultVO.setObject(documentModel);
        }else {
            logger.error("上传的文档不是本地文档");
            resultVO.setSucceed(false);
            resultVO.setMessage("服务器不存在该文档："+wdId);
        }
        return resultVO ;
    }
}
