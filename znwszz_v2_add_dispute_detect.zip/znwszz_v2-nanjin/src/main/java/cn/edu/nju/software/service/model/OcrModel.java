package cn.edu.nju.software.service.model;

import cn.edu.nju.software.service.DzjzWjService;
//import org.springframework.data.redis.core.StringRedisTemplate;

public class OcrModel {
    private int ajxh;
    private String wdId;
    private YhModel user;
//    private StringRedisTemplate stringRedisTemplate;
    private DzjzWjService dzjzWjService;

    public int getAjxh() {
        return ajxh;
    }

    public void setAjxh(int ajxh) {
        this.ajxh = ajxh;
    }

    public String getWdId() {
        return wdId;
    }

    public void setWdId(String wdId) {
        this.wdId = wdId;
    }

    public YhModel getUser() {
        return user;
    }

    public void setUser(YhModel user) {
        this.user = user;
    }

    public DzjzWjService getDzjzWjService() {
        return dzjzWjService;
    }

    public void setDzjzWjService(DzjzWjService dzjzWjService) {
        this.dzjzWjService = dzjzWjService;
    }

//    public StringRedisTemplate getStringRedisTemplate() {
//        return stringRedisTemplate;
//    }
//
//    public void setStringRedisTemplate(StringRedisTemplate stringRedisTemplate) {
//        this.stringRedisTemplate = stringRedisTemplate;
//    }
}
