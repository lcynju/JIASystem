package cn.edu.nju.software.service.model;

import lombok.Data;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 17:16
 * @Description
 */
@Data
public class FlfgModel {
    private String mc ;
    private String jc ;
    private String url ;
}
