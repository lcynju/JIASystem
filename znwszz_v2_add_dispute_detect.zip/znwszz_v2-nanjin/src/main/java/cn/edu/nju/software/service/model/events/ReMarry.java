package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:44
 * @Description
 */
public class ReMarry extends BaseEvent{
    private String person1 ;
//    private String person2 ;
    public ReMarry(HashMap<String,Object> map){
        super(map);
        this.person1 = (String) map.get("participant");
        this.forRendaring.add((ArrayList<Integer>) map.get("participant_index_pair")) ;
    }
    @Override
    /**
     * negated: person1 trigger
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.person1!=null && this.person1.length()>0){
            if(str.length()>0){
                str = str+" "+this.person1 ;
            }else {
                str = this.person1 ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }

        this.title = str ;
    }
}
