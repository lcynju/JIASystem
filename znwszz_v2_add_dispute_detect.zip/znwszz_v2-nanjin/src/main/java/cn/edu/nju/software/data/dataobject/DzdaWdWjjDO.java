package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DZDA_WD_WJJ")
public class DzdaWdWjjDO implements java.io.Serializable{


  /**
   * null
   */
  private String wjjid;

  /**
   * null
   */
  private String wjjssah;

  /**
   * null
   */
  private String wjjmc;

  /**
   * null
   */
  private Integer wjjbh;

  /**
   * null
   */
  private Integer wdly;

  /**
   * null
   */
  private String wdlybz;

  /**
   * null
   */
  private Integer wdsfpx;

  /**
   * null
   */
  private String wdpxbz;

  /**
   * null
   */
  private Integer wdsx;

  /**
   * null
   */
  private Integer wdqx;

  /**
   * null
   */
  private Integer wdxz;

  /**
   * null
   */
  private String wdxzbz;

  /**
   * null
   */
  private Integer wjjcjrly;

  /**
   * null
   */
  private String wjjcjr;

  /**
   * null
   */
  private java.util.Date wjjcjsj;

  /**
   * null
   */
  private Integer wjjsfzj;

  /**
   * null
   */
  private Integer wjjsffk;

  /**
   * null
   */
  private String wjjfkbz;

  /**
   * null
   */
  private String sfzxswf;


  @Id
  @Column(name = "WJJID")
  public String getWjjid() {
    return wjjid;
  }

  public void setWjjid(String wjjid) {
    this.wjjid = wjjid;
  }

    @Column(name = "WJJSSAH")
  public String getWjjssah() {
    return wjjssah;
  }

  public void setWjjssah(String wjjssah) {
    this.wjjssah = wjjssah;
  }

    @Column(name = "WJJMC")
  public String getWjjmc() {
    return wjjmc;
  }

  public void setWjjmc(String wjjmc) {
    this.wjjmc = wjjmc;
  }

    @Column(name = "WJJBH")
  public Integer getWjjbh() {
    return wjjbh;
  }

  public void setWjjbh(Integer wjjbh) {
    this.wjjbh = wjjbh;
  }

    @Column(name = "WDLY")
  public Integer getWdly() {
    return wdly;
  }

  public void setWdly(Integer wdly) {
    this.wdly = wdly;
  }

    @Column(name = "WDLYBZ")
  public String getWdlybz() {
    return wdlybz;
  }

  public void setWdlybz(String wdlybz) {
    this.wdlybz = wdlybz;
  }

    @Column(name = "WDSFPX")
  public Integer getWdsfpx() {
    return wdsfpx;
  }

  public void setWdsfpx(Integer wdsfpx) {
    this.wdsfpx = wdsfpx;
  }

    @Column(name = "WDPXBZ")
  public String getWdpxbz() {
    return wdpxbz;
  }

  public void setWdpxbz(String wdpxbz) {
    this.wdpxbz = wdpxbz;
  }

    @Column(name = "WDSX")
  public Integer getWdsx() {
    return wdsx;
  }

  public void setWdsx(Integer wdsx) {
    this.wdsx = wdsx;
  }

    @Column(name = "WDQX")
  public Integer getWdqx() {
    return wdqx;
  }

  public void setWdqx(Integer wdqx) {
    this.wdqx = wdqx;
  }

    @Column(name = "WDXZ")
  public Integer getWdxz() {
    return wdxz;
  }

  public void setWdxz(Integer wdxz) {
    this.wdxz = wdxz;
  }

    @Column(name = "WDXZBZ")
  public String getWdxzbz() {
    return wdxzbz;
  }

  public void setWdxzbz(String wdxzbz) {
    this.wdxzbz = wdxzbz;
  }

    @Column(name = "WJJCJRLY")
  public Integer getWjjcjrly() {
    return wjjcjrly;
  }

  public void setWjjcjrly(Integer wjjcjrly) {
    this.wjjcjrly = wjjcjrly;
  }

    @Column(name = "WJJCJR")
  public String getWjjcjr() {
    return wjjcjr;
  }

  public void setWjjcjr(String wjjcjr) {
    this.wjjcjr = wjjcjr;
  }

    @Column(name = "WJJCJSJ")
  public java.util.Date getWjjcjsj() {
    return wjjcjsj;
  }

  public void setWjjcjsj(java.util.Date wjjcjsj) {
    this.wjjcjsj = wjjcjsj;
  }

    @Column(name = "WJJSFZJ")
  public Integer getWjjsfzj() {
    return wjjsfzj;
  }

  public void setWjjsfzj(Integer wjjsfzj) {
    this.wjjsfzj = wjjsfzj;
  }

    @Column(name = "WJJSFFK")
  public Integer getWjjsffk() {
    return wjjsffk;
  }

  public void setWjjsffk(Integer wjjsffk) {
    this.wjjsffk = wjjsffk;
  }

    @Column(name = "WJJFKBZ")
  public String getWjjfkbz() {
    return wjjfkbz;
  }

  public void setWjjfkbz(String wjjfkbz) {
    this.wjjfkbz = wjjfkbz;
  }

    @Column(name = "SFZXSWF")
  public String getSfzxswf() {
    return sfzxswf;
  }

  public void setSfzxswf(String sfzxswf) {
    this.sfzxswf = sfzxswf;
  }

}
