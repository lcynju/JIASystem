/**
 * Created by YuanHao on 2018/7/25.
 *  项目中的恒量
 */

var baseUrl = "";

var LEFT_VIEW_STATE = {
    'BDWD': 1,
    'FLFG': 2,
    'DZJZ': 3
};
var SHOW_STATE = {
    'SHOW': 1,
    'HIDE': 0
};
var LOGIN_STATE = {
    'LOGIN': 1,
    'UNLOGIN': 0,
    'SUCCESS': '登陆成功',
    'FAILED': '账户密码或密码错误',
    'UNEXPECTED': '登陆失败，请检查网络是否连接',
    'LOGIN_INVALID': '用户未登录或用户登陆失效，请重新登陆'
};

var DOC_IMAGE_STATE = {
    'DOCUMENT': 2,
    'IMAGE': 1,
    'EMPTY': 0
};

var SELECTED_MB = {
    'EMPTY': 0,
    'YS': 1,
    'ZS': 2,
    'ES': 3
};

var ERROR_MESSAGE = {
    'UNEXPECTED': '数据获取出错，请检查网络连接或联系管理员',
    'UPLOAD_FAILED': '上传文件失败，请检查网络连接或联系管理员'
};

var AJ_STATE = {
    'HIDE': 0,
    'AJ_LIST': 1,
    'AJXQ': 2
};

var AJLX = {
    'ZB': 'zb',
    'CS': 'cs',
    'YJ': 'yj'
};

var FY_LIST = ["高院", "一中院", "二中院", "海事法院", "滨海新区", "和平法院", "河东法院", "河西法院",
    "河北法院", "南开法院", "红桥法院", "东丽法院", "西青法院", "津南法院", "北辰法院", "武清法院",
    "宝坻法院", "静海法院", "宁河法院", "蓟州法院", "塘沽法院", "汉沽法院",
    "大港法院", "功能审判区", "铁路运输"];

var LOGIN_USERNAME = {'UNLOGIN': '未登录用户'};

var FOLD_TREE_VIEW = {'EXPANDED': '收起导航栏', 'FOLD': '展开导航栏'};

var EMPTY_LIST = {
    'ZB_EMPTY': [{'ah': '暂无在审案件', 'ajmc': '----------', 'larq': '----------', 'jarq': '----------'}],
    'YJ_EMPTY': [{'ah': '暂无已结案件', 'ajmc': '----------', 'larq': '----------', 'jarq': '----------'}],
    'CS_EMPTY': [{'ah': '暂无参审案件', 'ajmc': '----------', 'larq': '----------', 'jarq': '----------'}]
};

var LOGIN_TIP = {
    'LOGIN_ING': '登陆中',
    'LOGIN_FAILED': '登陆失败,请检查账户名或密码',
    'LOGIN_SUCCESS': '登陆成功',
    'LOGIN': '登陆'
};

var GET_DATA_TIP = {
    'GET_DATA_ING': '正在获取数据，请稍后',
    'GET_DATA_FAILED': '获取数据失败，请检查网络或稍后再试'
};

var LOAD_DOCUMENT = {
    'LOADING_IMAGE': '正在获取图片',
    'LOADING_IMAGE_FAILED': '正在获取图片失败，请检查网络或稍后再试',
    'LOADING_DOCUMENT': '正在获取文档',
    'LOADING_DOCUMENT_FAILED': '正在获取文档失败，请检查网络或稍后再试',
    'LOADING_AJXQ': '正在获取案件详情，请稍后',
    'LOADING_AJXQ_FAILED':'获取案件详情失败，请检查网络或稍后再试'
};

var FOLD_TREE_MARGIN = {
    'MARGIN_1': '0px',
    'MARGIN_2': '-110px',
    'MARGIN_3': '-155px',
    'MARGIN_4': '-200px'
};

var LOGIN_TEXT = {
    'LOGIN': '登陆',
    'EXIT': '退出'
};

var FLFG_WEBSITE = [
    {
    'id': 'fx',
    'name': '法信',
    'url': 'http://192.0.100.106:8086'
    },
    // {
    //     'id': 'llzs',
    //     'name': '律例注疏',
    //     'url': 'http://192.2.2.16/login'
    // },
    {
        'id': 'yyzc',
        'name': '中国审判法律应用支持系统',
        'url': 'http://130.1.1.155/law/'
    }];

var UPLOAD_MESSAGE = [{
    'UNSURPPORTED_FILE': '文件格式不支持'
}];

var NO_SELECTED_FILE = [{
    "RIGHT": "当前没有正在编辑的文档"
}];

var IMPORT_TIP = {
    'confirm':'确认',
    'wait':'正在导入，请稍后...',
    'finish':'导入电子卷宗完成!'
};
