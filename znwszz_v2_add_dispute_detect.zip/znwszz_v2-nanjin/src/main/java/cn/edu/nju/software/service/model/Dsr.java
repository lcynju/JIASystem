package cn.edu.nju.software.service.model;

import cn.edu.nju.software.util.StringUtil;
import lombok.Data;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/8
 */
public class Dsr {
    /**
     * 当事人类别
     */
    private String dsrlb ;
    /**
     * 当事人名称
     */
    private String mc ;

    /**
     * 当事人地址
     */
    private String dz ;

    /**
     * 其他诉讼参与人
     */
    private List<Qtsscyr> qtsscyr ;

    public Dsr() {
    }

    public Dsr(String mc, String dz) {
        this.mc = mc;
        this.dz = dz;
    }

    public String getDsrlb() {
        return dsrlb;
    }

    public void setDsrlb(String dsrlb) {
        if(!StringUtil.isEmpty(dsrlb)) {
            this.dsrlb = dsrlb.trim();
        }
    }

    public String getMc() {
        return mc;
    }

    public void setMc(String mc) {
        if (!StringUtil.isEmpty(mc)) {
            this.mc = mc.trim();
        }
    }

    public String getDz() {
        return dz;
    }

    public void setDz(String dz) {
        if(!StringUtil.isEmpty(dz)) {
            this.dz = dz.trim();
        }
    }

    public List<Qtsscyr> getQtsscyr() {
        return qtsscyr;
    }

    public void setQtsscyr(List<Qtsscyr> qtsscyr) {
        if(qtsscyr!=null && qtsscyr.size()>0) {
            this.qtsscyr = qtsscyr;
        }
    }
}
