package cn.edu.nju.software.data.dataobject;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DZDA_WD_WJ")
public class DzdaWdWjDO implements java.io.Serializable{

  /**
   * null
   */
  private String wjid;

  /**
   * null
   */
  private String wjsswjj;

  /**
   * null
   */
  private Integer wjbh;

  /**
   * null
   */
  private String wjmc;

  /**
   * null
   */
  private java.util.Date wjscsj;

  /**
   * null
   */
  private String wjlj;

  /**
   * null
   */
  private String wjbz;

  /**
   * null
   */
  private String wjscr;

  /**
   * null
   */
  private String swfsc;


  @Id
  @Column(name = "WJID")
  public String getWjid() {
    return wjid;
  }

  public void setWjid(String wjid) {
    this.wjid = wjid;
  }


  @Column(name = "WJSSWJJ")
  public String getWjsswjj() {
    return wjsswjj;
  }

  public void setWjsswjj(String wjsswjj) {
    this.wjsswjj = wjsswjj;
  }

    @Column(name = "WJBH")
  public Integer getWjbh() {
    return wjbh;
  }

  public void setWjbh(Integer wjbh) {
    this.wjbh = wjbh;
  }

  @Column(name = "WJMC")
  public String getWjmc() {
    return wjmc;
  }

  public void setWjmc(String wjmc) {
    this.wjmc = wjmc;
  }

  @Column(name = "WJSCSJ")
  public java.util.Date getWjscsj() {
    return wjscsj;
  }

  public void setWjscsj(java.util.Date wjscsj) {
    this.wjscsj = wjscsj;
  }

  @Column(name = "WJLJ")
  public String getWjlj() {
    return wjlj;
  }

  public void setWjlj(String wjlj) {
    this.wjlj = wjlj;
  }

  @Column(name = "WJBZ")
  public String getWjbz() {
    return wjbz;
  }

  public void setWjbz(String wjbz) {
    this.wjbz = wjbz;
  }

    @Column(name = "WJSCR")
  public String getWjscr() {
    return wjscr;
  }

  public void setWjscr(String wjscr) {
    this.wjscr = wjscr;
  }

    @Column(name = "SWFSC")
  public String getSwfsc() {
    return swfsc;
  }

  public void setSwfsc(String swfsc) {
    this.swfsc = swfsc;
  }


}
