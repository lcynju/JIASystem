package cn.edu.nju.software.service.model;

import cn.edu.nju.software.util.StringUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author 13314409603@163.com
 * @date 2018/10/24
 * @time 17:01
 * @Description
 */
public enum BgJzEnum {
    LAXGCL("立案相关材料","立案|收案","流程管理"),
    BLLCL("笔录类材料","笔录|提纲|建议|报告"),
    TZLCL("通知类材料","公告|通知|传票|告知"),
    CPWS("裁判文书","判决|裁判"),
    LCLWS("流程类文书","");
    private String jzlx;
    private String key;
    private String ignore;

    private BgJzEnum(String jzlx, String key) {
        this.jzlx = jzlx;
        this.key = key;
    }


    private BgJzEnum(String jzlx, String key, String ignore) {
        this.jzlx = jzlx;
        this.key = key;
        this.ignore = ignore;
    }


    public String getJzlx() {
        return jzlx;
    }


    public void setJzlx(String jzlx) {
        this.jzlx = jzlx;
    }


    public String getKey() {
        return key;
    }


    public void setKey(String key) {
        this.key = key;
    }


    public String getIgnore() {
        return ignore;
    }


    public void setIgnore(String ignore) {
        this.ignore = ignore;
    }

    /**
     * 根据表格名称获取匹配电子卷宗目录
     * @param bgmc
     * @return
     */
    public static String getMatchJz(String bgmc){
        if(StringUtil.isBlank(bgmc)) {
            return null;
        }
        Pattern pattern=null;
        Matcher matcher=null;
        for(BgJzEnum bg:BgJzEnum.values()){
            String key=bg.getKey();
            String ignore=bg.getIgnore();
            if(StringUtil.isBlank(key)) {
                continue;
            }
            pattern=Pattern.compile(key);
            matcher=pattern.matcher(bgmc);
            if(matcher.find()){
                if(StringUtil.isBlank(ignore)){
                    return bg.getJzlx();
                }else{
                    pattern=Pattern.compile(ignore);
                    matcher=pattern.matcher(bgmc);
                    if(matcher.find()){
                        continue;
                    }else{
                        return bg.getJzlx();
                    }
                }
            }
        }
        return BgJzEnum.LCLWS.getJzlx();
    }
}
