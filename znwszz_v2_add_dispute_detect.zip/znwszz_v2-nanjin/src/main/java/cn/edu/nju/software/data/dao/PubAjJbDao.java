package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.PubAjJbDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/7/30.
 */
@Repository
public interface PubAjJbDao extends JpaRepository<PubAjJbDO,Integer> {

    @Query(value = "SELECT PUB_AJ_JB.* FROM PUB_AJ_JB JOIN PUB_SPRY ON PUB_AJ_JB.AJXH=PUB_SPRY.AJXH AND XM=:XM AND PUB_SPRY.SFCBR='Y' WHERE " +
            "PUB_AJ_JB.JARQ >= :BEGIN and DATEDIFF(DD,PUB_AJ_JB.JARQ,:END ) >= 0 ORDER BY PUB_AJ_JB.LARQ DESC"
            ,nativeQuery = true)
    List<PubAjJbDO> getYj(@Param("BEGIN") String begin, @Param("END") String end, @Param("XM") String xm) ;

    @Query(value = "SELECT PUB_AJ_JB.* FROM PUB_AJ_JB WHERE " +
            "PUB_AJ_JB.JARQ >= :BEGIN and DATEDIFF(DD,PUB_AJ_JB.JARQ,:END ) >= 0 ORDER BY PUB_AJ_JB.LARQ DESC"
            ,nativeQuery = true)
    List<PubAjJbDO> getYj(@Param("BEGIN") String begin, @Param("END") String end) ;

    @Query(nativeQuery = true,value = "SELECT PUB_AJ_JB.* FROM PUB_AJ_JB JOIN PUB_SPRY ON PUB_AJ_JB.AJXH=PUB_SPRY.AJXH AND XM=:XM WHERE " +
            " PUB_AJ_JB.JARQ is NULL AND PUB_SPRY.SFCBR='Y' ORDER BY PUB_AJ_JB.LARQ DESC")
    List<PubAjJbDO> getZb(@Param("XM") String xm) ;

    @Query(nativeQuery = true,value = "SELECT PUB_AJ_JB.* FROM PUB_AJ_JB JOIN PUB_SPRY ON PUB_AJ_JB.AJXH=PUB_SPRY.AJXH AND XM=:XM WHERE "+
            "PUB_AJ_JB.JARQ is NULL AND PUB_SPRY.SFCBR<>'Y' ORDER BY PUB_AJ_JB.LARQ DESC")
    List<PubAjJbDO> getCs(@Param("XM") String xm) ;

    @Query(nativeQuery = true,value = "SELECT count(*) FROM PUB_AJ_JB JOIN PUB_SPRY ON PUB_AJ_JB.AJXH=PUB_SPRY.AJXH AND PUB_SPRY.XM=:XM WHERE PUB_AJ_JB.AJXH= :AJXH ")
    int checkAccess(@Param("XM") String xm, @Param("AJXH") int ajxh) ;

    PubAjJbDO findByAjxh(int ajxh) ;

    PubAjJbDO findByAh(String ah) ;

    @Query(nativeQuery = true,value = "SELECT PUB_AJ_JB.* FROM PUB_AJ_JB JOIN PUB_LA_AY ON PUB_AJ_JB.AJXH=PUB_LA_AY.AJXH AND (PUB_LA_AY.LAAY LIKE :AY OR PUB_LA_AY.AY LIKE :AY)" +
            "WHERE " +
            "PUB_AJ_JB.JARQ >= :BEGIN and DATEDIFF(DD,PUB_AJ_JB.JARQ,:END ) >= 0 ORDER BY PUB_AJ_JB.LARQ DESC")
    List<PubAjJbDO> getByAy(@Param("AY") String ay,@Param("BEGIN")String begin,@Param("END")String end) ;
}
