package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.AydmbDO;
import cn.edu.nju.software.service.model.AydmModel;

/**
 *
 * @author 13314
 * @date 2018/8/14
 */
public class AydmbConvertor {
    public static AydmModel DO2Model(AydmbDO DO){
        if(DO==null){
            return null ;
        }
        AydmModel model = new AydmModel() ;
        model.setAydmbh(DO.getDmbh());
        model.setAylb(DO.getAylb());
        model.setAymc(DO.getAymc());
        model.setBbh(DO.getBbh());
        model.setBz(DO.getBz());
        model.setDmms(DO.getDmms());
        model.setDqbs(DO.getDqbs());
        model.setSjdm(DO.getSjdm());
        model.setXgsj(DO.getXgsj());
        return model ;
    }
}
