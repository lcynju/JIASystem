# znwszz_v2

spring boot 版

# 安装先置服务documentServer
1、下载安装docker，
2、运行sudo docker run -i -t -d -p 9000:80 --restart=alwarys onlyoffice/documentserver,下载安装最新documentserver镜像

3、待下载完成后，运行localhost:9000查看documentServer是否正常启动

## WIN7服务器

ip:130.1.61.219
user: dell
pass: 1

package -Dmaven.test.skip=true