package cn.edu.nju.software.service.model.enums;

/**
 *  文档来源枚举，目前包括：
 *  1、本地文档，即用户上传存储在系统本地,id：local_文档名称
 *  2、电子卷宗，id:dzjz_fydm_文档id
 *  3、文书信息,id:wsxx_fydm_ajxh_文书bh
 *  4、原审档案,即电子档案信息，id：ysda_fydm_文档id
 *  5、关联案件，流程案件的电子卷宗和文书信息，所以id同电子卷宗和文书信息
 *  在文档id前加各自的前缀prefix区分
 * @author 13314
 * @date 2018/8/16
 */
public enum DocSourceEnum {
    /**
     * 本地文档
     */
    LOCAL("local","本地文档",0),
    /**
     * 电子卷宗
     */
    DZJZ("dzjz","电子卷宗",1) ,
    /**
     * 文书基表
     */
    WSXX("wsxx","文书信息",2) ,
    YSDA("ysda","原审档案",3) ,

    GLAJ("glaj","关联案件",4) ,
    ;
    /**
     * 作为文档id的前缀，用于区别文档来源
     */
    private String prefix;
    private String mc ;
    private int xssx ;

    /**
     * 连接符
     */
    public static final  String CONNECTOR ="_" ;
    DocSourceEnum(String prefix, String mc, int xssx){
        this.prefix = prefix ;
        this.mc = mc ;
        this.xssx = xssx ;
    }

    public String getPrefix() {
        return prefix;
    }

    public String getMc() {
        return mc;
    }

    public int getXssx() {
        return xssx;
    }
}
