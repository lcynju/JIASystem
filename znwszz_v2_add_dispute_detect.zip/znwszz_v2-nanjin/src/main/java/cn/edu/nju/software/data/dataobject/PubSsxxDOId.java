package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import java.util.Objects;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 10:21
 * @Description
 */
public class PubSsxxDOId implements java.io.Serializable {

    // Fields

    private Integer ajxh;
    private Integer bh;

    // Constructors

    /** default constructor */
    public PubSsxxDOId() {
    }

    /** full constructor */
    public PubSsxxDOId(Integer ajxh, Integer bh) {
        this.ajxh = ajxh;
        this.bh = bh;
    }

    // Property accessors

    @Column(name = "AJXH", nullable = false)
    public Integer getAjxh() {
        return this.ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name = "BH", nullable = false)
    public Integer getBh() {
        return this.bh;
    }

    public void setBh(Integer bh) {
        this.bh = bh;
    }

    @Override
    public boolean equals(Object other) {
        if ((this == other)) {
            return true;
        }
        if ((other == null)) {
            return false;
        }
        if (!(other instanceof PubSsxxDOId)) {
            return false;
        }
        PubSsxxDOId castOther = (PubSsxxDOId) other;

        return ((Objects.equals(this.getAjxh(), castOther.getAjxh())) || (this.getAjxh() != null
                && castOther.getAjxh() != null && this.getAjxh().equals(
                castOther.getAjxh())))
                && ((Objects.equals(this.getBh(), castOther.getBh())) || (this.getBh() != null
                && castOther.getBh() != null && this.getBh().equals(
                castOther.getBh())));
    }

    @Override
    public int hashCode() {
        int result = 17;

        result = 37 * result
                + (getAjxh() == null ? 0 : this.getAjxh().hashCode());
        result = 37 * result + (getBh() == null ? 0 : this.getBh().hashCode());
        return result;
    }

}
