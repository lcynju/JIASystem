package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.XxxglDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/13
 */
@Repository
public interface XxxglDao extends JpaRepository<XxxglDO,Integer> {
    XxxglDO findBySzbAndSzl(String szb,String szl) ;
}
