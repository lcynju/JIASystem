package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DsrDwDO;
import cn.edu.nju.software.data.dataobject.DsrDwDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/10.
 */
@Repository
public interface DsrDwDao extends JpaRepository<DsrDwDO,DsrDwDOId> {
    List<DsrDwDO> findByAjxh(int ajxh) ;
}
