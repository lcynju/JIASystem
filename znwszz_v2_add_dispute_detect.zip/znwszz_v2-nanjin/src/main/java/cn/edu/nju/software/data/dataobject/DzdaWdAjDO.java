package cn.edu.nju.software.data.dataobject;


import javax.persistence.*;
import java.util.List;

/**
 * Created by 13314 on 2018/9/12.
 */

@Entity
@Table(name = "DZDA_WD_AJ")
public class DzdaWdAjDO implements java.io.Serializable{


    /**
     * null
     */

    private String ajid;

    /**
     * null
     */
    private String ah;

    /**
     * null
     */
    private java.util.Date cjsj;

    /**
     * null
     */
    private String cjr;

    /**
     * null
     */
    private Integer shzt;

    /**
     * null
     */
    private java.util.Date shsj;

    /**
     * null
     */
    private String shyj;

    /**
     * null
     */
    private java.util.Date swfzhsj;

    @OneToMany(cascade = {CascadeType.ALL})
    @JoinColumn(name = "wjjssah")
    private List<DzdaWdWjDO> wjs ;
    @Id
    @Column(name = "AJID")
    public String getAjid() {
        return ajid;
    }

    public void setAjid(String ajid) {
        this.ajid = ajid;
    }

    @Column(name = "AH")
    public String getAh() {
        return ah;
    }

    public void setAh(String ah) {
        this.ah = ah;
    }

    @Column(name = "CJSJ")
    public java.util.Date getCjsj() {
        return cjsj;
    }

    public void setCjsj(java.util.Date cjsj) {
        this.cjsj = cjsj;
    }

    @Column(name = "CJR")
    public String getCjr() {
        return cjr;
    }

    public void setCjr(String cjr) {
        this.cjr = cjr;
    }

    @Column(name = "SHZT")
    public Integer getShzt() {
        return shzt;
    }

    public void setShzt(Integer shzt) {
        this.shzt = shzt;
    }

    @Column(name = "SHSJ")
    public java.util.Date getShsj() {
        return shsj;
    }

    public void setShsj(java.util.Date shsj) {
        this.shsj = shsj;
    }

    @Column(name = "SHYJ")
    public String getShyj() {
        return shyj;
    }

    public void setShyj(String shyj) {
        this.shyj = shyj;
    }

    @Column(name = "SWFZHSJ")
    public java.util.Date getSwfzhsj() {
        return swfzhsj;
    }

    public void setSwfzhsj(java.util.Date swfzhsj) {
        this.swfzhsj = swfzhsj;
    }

}

