package cn.edu.nju.software.configuration.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 电子卷宗服务配置映射的properties
 * @author 13314
 * @date 2018/8/7
 */
@Component
@ConfigurationProperties("jzda-service")
@Data
public class JzdaServiceProperties {
    private String dzjzDownloadUrl ;
    private String dzdaDownloadUrl ;
    private String timeout ;
}
