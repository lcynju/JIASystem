package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:45
 * @Description
 */
public class Bear extends BaseEvent {
    private String time ;
    private String childGender ;
    private String childName ;
    private String childAge ;
    public Bear(HashMap<String,Object> map){
        super(map);
        this.time = (String) map.get("dateOfBirth");
        this.forRendaring.add((ArrayList<Integer>) map.get("dateOfBirth_index_pair")) ;

        this.childGender = (String) map.get("gender");
        this.forRendaring.add((ArrayList<Integer>) map.get("gender_index_pair")) ;

        this.childName = (String) map.get("childName");
        this.forRendaring.add((ArrayList<Integer>) map.get("childName_index_pair")) ;

        this.childAge = (String) map.get("childAge");
        this.forRendaring.add((ArrayList<Integer>) map.get("childAge_index_pair")) ;

    }
    @Override
    /**
     * negated：time trigger childGender childName childAge
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.time!=null && this.time.length()!=0){
            if(str.length()>0){
                str = str+" "+this.time ;
            }else {
                str = this.time ;
            }
        }

        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.childGender!=null && this.childGender.length()>0){
            str = str +" "+this.childGender ;
        }
        if(this.childName!=null && this.childName.length()>0){
            str = str +" "+this.childName ;
        }
        if(this.childAge!=null && this.childAge.length()>0){
            str = str +" "+this.childAge ;
        }
        this.title = str ;
    }
}
