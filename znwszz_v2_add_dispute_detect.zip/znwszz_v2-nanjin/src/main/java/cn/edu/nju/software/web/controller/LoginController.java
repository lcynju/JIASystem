package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.FyService;
import cn.edu.nju.software.service.UserService;
import cn.edu.nju.software.service.model.FyModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.enums.YhCheckResult;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.StringUtil;
import cn.edu.nju.software.web.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import sun.misc.BASE64Decoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/7/17
 */
@Api(tags = "用户登陆相关接口")
@Controller
public class LoginController {
    @Autowired
    private UserService userService ;
    @Autowired
    private FyService fyService ;

    private Logger logger = Logger.getLogger(LoginController.class) ;
    @GetMapping("/")
    public String home(){
        return "home" ;
    }

    @ApiOperation(value = "获取法院列表接口")
    @ApiImplicitParam(name="lx",value = "列表类型，0：无上下级关系的法院列表，1：有上下级关系的法院列表")
    @GetMapping("/getFyList")
    @ResponseBody
    public List<FyModel> getFyList(String lx){
        if(StringUtil.equals(lx,"0")){
            return fyService.getOrdinaryFyList() ;
        }else if(StringUtil.equals(lx,"1")){
            return fyService.getFyList() ;
        }
        logger.error("获取法院列表错误，列表类型无法识别:"+lx);
        throw new BaseException("列表类型错误。法院列表类型，0：无上下级关系的法院列表，1：有上下级关系的法院列表") ;
    }

    @ApiOperation(value = "登陆接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "fy",value = "用户法院简称，包括：高院、一中院、二中院、海事法院、滨海新区、功能审判区、" +
                    "大港法院、铁路法院、和平法院、河东法院、河西法院、蓟州法院等",required = true,paramType = "query") ,
            @ApiImplicitParam(name = "name",value = "用户登陆代码",required = true,paramType = "query") ,
            @ApiImplicitParam(name = "password",value = "用户登陆口令",required = true,paramType = "query") ,
    })
    @ResponseBody
    @PostMapping("/login")
    public ResultVO<YhModel> login(HttpServletRequest request, String fy, String name, String password){
        String fydm = FyEnum.findByJc(fy).getFydm();
        ResultVO result = new ResultVO<YhModel>() ;
        YhCheckResult checkResult = userService.login(fydm, name,password);
        if(checkResult.isSuccess()){
            result.setSucceed(true);
            result.setObject(checkResult.getXtyh());
            request.getSession().setAttribute("user",checkResult.getXtyh());
        }else{
            result.setSucceed(false);
            result.setMessage(checkResult.getResultCode().getMessage());
        }
        return result ;
    }

    @ApiOperation(value = "检查特定账户是否属于登陆状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name="name",value = "用户登陆代码",required = true,paramType = "query"),
    })
    @ResponseBody
    @GetMapping("/checkLogin")
    public ResultVO<YhModel> checkLogin(HttpServletRequest request, String name){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        ResultVO resultModel = new ResultVO<YhModel>() ;
        if(user!=null && user.getDm().equals(name)){
            resultModel.setSucceed(true);
            resultModel.setObject(user);
            resultModel.setMessage("已登陆");
        }else {
            resultModel.setSucceed(false);
            resultModel.setMessage("未登陆");
        }
        return resultModel ;
    }

    @ApiOperation(value = "注销登陆账户接口")
    @ResponseBody
    @GetMapping("/cancelLogin")
    public ResultVO cancelLogin(HttpServletRequest request){
        ResultVO resultModel = new ResultVO() ;
        HttpSession session = request.getSession();
        session.removeAttribute("user");
        resultModel.setSucceed(true);
        return resultModel ;
    }

    @ApiOperation(value = "免密登陆接口")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "param",value = "加密参数",required = true,paramType = "query") ,
            @ApiImplicitParam(name = "sign",value = "签名",required = true,paramType = "query")
    })
    @GetMapping("/znwszzGateway")
    public String gateway(HttpServletRequest request, HttpServletResponse response){
        String base64Param = request.getParameter("param") ;
        String signature = request.getParameter("sign") ;
        logger.info("免密登陆入口param:"+base64Param+",sign:"+signature);
        if(StringUtil.isBlank(base64Param) || StringUtil.isBlank(signature)){
            logger.error("免密登陆失败，参数为空");
            throw new BaseException("参数为空") ;
        }
        //前面验证
        String key = "211bfa7efbcbe28431ceb328969cb15e";
        try {
            String s = DigestUtils.md5Hex((base64Param + key).getBytes("UTF-8"));
            if(!StringUtil.equals(s,signature)){
                logger.error("免密登陆失败，签名错误");
                throw new BaseException("签名错误param:"+base64Param+",sign:"+signature) ;
            }
        } catch (UnsupportedEncodingException e) {
            logger.error("免密登陆失败，编码格式错误，应为utf-8。错误信息："+e.getMessage());
            throw new BaseException("编码格式错误，应为utf-") ;
        }

        //解析参数
        String paramStr = "" ;
        BASE64Decoder decoder = new BASE64Decoder() ;
        try {
            byte[] bytes = decoder.decodeBuffer(base64Param);
            paramStr = new String(bytes,"UTF-8") ;
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("免密登陆失败，解析用户信息失败。错误信息："+e.getMessage());
            throw new BaseException("base64解析用户信息失败") ;
        }

        //fydm=120000 200&yhdm=gaojh
        String[] params = paramStr.split("&");
        String fydm = params[0].substring(StringUtil.indexOf(params[0], "=") + 1);
        String yhdm = params[1].substring(StringUtil.indexOf(params[1], "=")+1) ;

        YhModel yhModel = userService.findByYhdm(fydm, yhdm);
        if(yhModel==null){
            logger.error("免密登陆失败，未查到该用户:fydm="+fydm+",yhdm="+yhdm);
            throw new BaseException("免密登陆失败，未查到该用户:fydm="+fydm+",yhdm="+yhdm) ;
        }
        request.getSession().setAttribute("user",yhModel);

        Cookie cookie = new Cookie("dm",yhdm) ;
        response.addCookie(cookie);
        return "home" ;
    }
}
