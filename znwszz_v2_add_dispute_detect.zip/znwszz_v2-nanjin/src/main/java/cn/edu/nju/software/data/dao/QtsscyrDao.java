package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.QtsscyrDO;
import cn.edu.nju.software.data.dataobject.QtsscyrDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/15.
 */
@Repository
public interface QtsscyrDao extends JpaRepository<QtsscyrDO,QtsscyrDOId> {
    List<QtsscyrDO> findByAjxh(int ajxh) ;
}
