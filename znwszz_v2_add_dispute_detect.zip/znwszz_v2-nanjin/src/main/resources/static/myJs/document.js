/**
 * Created by YuanHao on 2018/8/14.
 *  管理文档加载
 */

/**
 * 表示加载文档的三种状态
 * left 表示左边加载本地文档，tree表示左边的树状目录的文档加载状态，right表示右边文档状态
 * true表示已加载，false表示未加载
 * @type {{left: boolean, right: boolean, tree: boolean}}
 */
var docStatus = {'left': false, 'right': false, 'tree': false};

// 加载空文档
function load_empty_document() {
    $.ajax({
        url: baseUrl + '/getEmptyDocx',
        type: 'get',
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (doc) {
            var dom_name = 'rightView' + doc.object.key;

            load_document(dom_name, doc, 'right');
        },
        error: function () {
            error_tip(ERROR_MESSAGE.UNEXPECTED);
        }
    });
}

/**
 * 加载文档
 * @param wrapId
 * @param document
 * @param type
 */
function load_document(wrapId, document, type) {
    change_document_size();
    var wrapControl = $('#' + wrapId);
    //是否可编辑
    var edit = false;
    var mode = 'view';
    if (type === 'left') {
        wrapControl = $('#' + 'left_content');
        wrapControl.animate({width: '100%'}, 100);
        wrapControl.animate({marginTop: '0'}, 100);
        wrapControl.animate({height: vm.left_win_height + 'px'}, 100);
        hide_left_content();
        vm.show_case_modeling=false;
        vm.left_opened_document_list.push(document.object);
        vm.left_selected_document = document.object.key;
    }
    else if (type === 'right') {
        edit = true;
        mode = 'edit';
        wrapControl = $('#' + 'right_content');
        wrapControl.animate({width: '100%'}, 100);
        wrapControl.animate({marginTop: '0'}, 100);
        wrapControl.animate({height: vm.right_win_height + 'px'}, 100);
        hide_right_content();
        vm.right_opened_document_model_dict[document.object.key] = document.object;
        vm.right_opened_document_model_state += 1;
        vm.right_opened_document_list.push(document.object);
        vm.right_selected_document = document.object.key;
    }
    //根据电子卷宗的树状目录加载doc
    else if (type === 'tree') {
        wrapControl.animate({width: '75%'}, 100);
        wrapControl.animate({marginTop: '0'}, 100);
        wrapControl.animate({height: '100vh'}, 100);
    }
    var config = {
        width: "100%",
        height: "100%",
        type: "desktop",
        documentTypeEnum: document.object.documentType,
        document: {
            fileType: document.object.fileType,
            key: document.object.key,
            title: document.object.name,
            url: document.object.url,
            permissions: {
                comment: false,
                review: false,
                edit: edit
            }
        },
        editorConfig: {
            callbackUrl: document.object.callBackUrl,
            lang: "zh-CN",
            mode: mode,
            customization: {
                autosave: true,
                chat: false,
                comments: false,
                compactToolbar: false,
                feedback: false,
                forcesave: true,
                logo: {
                    image: "http://130.39.110.38:8080//image/word_32px.png",
                    imageEmbedded: "http://130.39.110.38:8080//image/word_32px.png",
                    url: "http://130.39.110.38:8080/"
                }
            }
        }
    };

    if (type === 'left') {
        vm.left_document_editor_dict[document.object.key] = new DocsAPI.DocEditor(wrapId, config);
    } else if (type === 'right') {
        vm.right_document_editor_dict[document.object.key] = new DocsAPI.DocEditor(wrapId, config);
    } else if (type === 'tree') {
        //treeDocEditor = new DocsAPI.DocEditor(wrapId, config);
        vm.tree_document_editor_dict[document.object.key] = new DocsAPI.DocEditor(wrapId, config)
    }
}

/**
 * 点击上传按钮之后进行上传文件
 * @param wrapId 控件ID，用于展示文档的控件，通常为空
 * @param formId 传递数据的表格名
 * @param type 用以区分是左边还是右边的文档上传
 */
function uploadFile(formId, type) {
    var formData = new FormData(document.getElementById(formId));
    $.ajax({
        url: baseUrl + '/upload',
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        dataType: 'json',
        success: function (doc) {
            if (check_result(doc)) {
                vm.selectedWdId = doc.object.wdId
                if (type === 'right') {
                    var right_dom_name = 'rightView' + doc.object.key;
                    load_document(right_dom_name, doc, type);
                } else if (type === 'left') {
                    //将 案件建模 按钮名称复原
                    vm.case_modeling_text = '案件建模' ;
                    var left_dom_name = 'leftView' + doc.object.key;
                    load_document(left_dom_name, doc, type);
                }
            } else {
                error_tip(doc.message)
            }
        },
        error: function () {
            error_tip(ERROR_MESSAGE.UPLOAD_FAILED);
        }
    });
}

/**
 * 初始化空白文档
 */
function getEmptyDocument() {
    load_empty_document();
}

function deleteDocumentModel(key) {
    $.ajax({
        url: '/deleteDocumentModel',
        data: {
            document_key: key
        },
        type: 'get',
        success: function (data) {
            if (check_result(data)) {
                console.log(data);
            }

        }
    })
}

function getDocumentModel() {
    $.ajax({
        url: '/getDocumentModelList',
        type: 'get',
        success: function (res) {
            console.log(res.length);
            if (res.length === 0) {
                getEmptyDocument();
            }
            else {
                res.forEach(function (doc) {
                    var right_dom_name = 'rightView' + doc.object.key;
                    var key = doc.object.key;
                    if (!vm.right_opened_document_model_dict[key]) {
                        load_document(right_dom_name, doc, "right");
                    }
                });
            }
        }
    })
}

function deleteDocument(key, type) {
    if (type === 'right') {
        delete vm.right_opened_document_model_dict[key];
        deleteDocumentModel(key);
        vm.right_selected_document = doDeleteDocument(vm.right_document_editor_dict, vm.right_opened_document_list, vm.right_selected_document, key)
    } else if (type === 'left') {
        vm.left_selected_document = doDeleteDocument(vm.left_document_editor_dict, vm.left_opened_document_list, vm.left_selected_document, key);
    }
    else if (type === 'tree') {
        vm.tree_selected_document = doDeleteDocument(vm.tree_document_editor_dict, vm.tree_opened_document_list, vm.tree_selected_document, key);
    }
}

function doDeleteDocument(editor_dict, document_list, selected_document, key) {
    var doc_editor;
    var index = -1;
    doc_editor = editor_dict[key];
    delete editor_dict[key];
    index = get_index(document_list, key);
    document_list.splice(index, 1);
    if (selected_document) {
        if (document_list.length > 0) {
            selected_document = document_list[0].key;
        } else {
            selected_document = '';
        }
    }
    if (doc_editor) {
        doc_editor.destroyEditor();
    }
    return selected_document;
}

function load_tree_document(node) {
    if (!vm.tree_opened_document_key_dict[node.id]) {
        vm.load_document_tip = LOAD_DOCUMENT.LOADING_DOCUMENT;
        var wait2 = setInterval(function () {
            if (vm.load_document_tip.length > 20) {
                vm.load_document_tip = LOAD_DOCUMENT.LOADING_DOCUMENT;
            } else {
                vm.load_document_tip += '.';
            }
        }, 500);
        $.ajax({
            url: baseUrl + '/getDzjzWd?wdId=' + node.id,
            type: 'get',
            success: function (doc) {
                clearInterval(wait2);
                if (check_result(doc)) {
                    vm.selectedAj = vm.true_selectedAj;
                    vm.tree_document_key_ajxh_dict[doc.object.key] = vm.true_selectedAj;
                    vm.tree_selected_document = doc.object.key;
                    vm.tree_opened_document_list.push(doc.object);
                    vm.tree_opened_document_key_dict[node.id] = doc.object.key;
                    var wrapId = 'treeView' + doc.object.key;
                    vm.doc_image_state = DOC_IMAGE_STATE.DOCUMENT;
                    load_document(wrapId, doc, 'tree');
                    $('#load_document_tip').css('display', 'none');
                } else {
                    vm.load_document_tip = doc.message;
                    $('#load_document_tip').css('color', 'red');
                }
            },
            error: function (data, status, e) {
                clearInterval(wait2);
                $('#load_document_tip').css('color', 'red');
                vm.load_document_tip = ERROR_MESSAGE.UNEXPECTED;
            }
        })
    } else {
        var key = vm.tree_opened_document_key_dict[node.id];
        if (key !== vm.tree_selected_document){
            vm.change_opened_document(key, 'tree');
        }
        vm.doc_image_state = DOC_IMAGE_STATE.DOCUMENT;
    }
}
