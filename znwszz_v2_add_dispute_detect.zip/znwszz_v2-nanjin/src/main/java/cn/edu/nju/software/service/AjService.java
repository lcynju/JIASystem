package cn.edu.nju.software.service;


import cn.edu.nju.software.service.model.AjModel;

import java.util.List;

/**
 * 案件service
 * @author 13314
 * @date 2018/7/30
 */
public interface AjService {
    /**
     * 当前在办案件
     * @param fydm
     * @param name
     * @return
     */
    List<AjModel> getZbByName(String fydm, String name) ;

    /**
     * 获取已结案件
     * @param fydm
     * @param begin
     * @param end
     * @param name
     * @return
     */
    List<AjModel> getYjByName(String fydm, String begin, String end, String name) ;

    /**
     * 当前参审案件
     * @param fydm
     * @param name
     * @return
     */
    List<AjModel> getCsByName(String fydm, String name) ;

    /**
     * 检查是否由权限访问该案件信息
     * @param fydm
     * @param name
     * @param ajxh
     * @return
     */
    boolean checkAccess(String fydm, String name, int ajxh) ;

    /**
     * 获取原审法院和原审案号
     * @param fydm
     * @param ajxh
     * @return
     */
    String[] getYsfyAndYsah(String fydm, int ajxh) ;

    /**
     * 获取关联案件，案件所属法院，案号和案件序号
     * @param fydm
     * @param ajxh
     * @return
     */
    List<String[]> getGlaj(String fydm,int ajxh) ;

    /**
     * 获取时间范围内的所有已结案件
     * @param begin
     * @param end
     * @return
     */
    List<AjModel> getYjajList(String fydm,String begin,String end) ;

    /**
     * @param fydm
     * @param ay
     * @return
     */
    List<AjModel> findByAy(String fydm,String ay,String begin,String end) ;
}
