package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.FtnqFtsysqdjDO;
import cn.edu.nju.software.data.dataobject.FtnqFtsysqdjDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by WeaVer on 18/10/26.
 */

@Repository
public interface FtnqFtsysqdjDao extends JpaRepository<FtnqFtsysqdjDO,FtnqFtsysqdjDOId> {
    List<FtnqFtsysqdjDO> findByAjxh(int ajxh) ;
}