package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * XtCygjbDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "PUB_XTGL_CYGJB")
public class XtCygjbDO implements java.io.Serializable {

    // Fields

    private Integer cygjbh;
    private String gjmc;
    private Integer mrxssx;
    private Integer lx;
    private String lj;

    // Constructors

    /** default constructor */
    public XtCygjbDO() {
    }

    /** full constructor */
    public XtCygjbDO(Integer cygjbh, String gjmc, Integer mrxssx,Integer lx,String lj) {
        this.cygjbh = cygjbh;
        this.gjmc = gjmc;
        this.mrxssx = mrxssx;
        this.lx=lx;
        this.lj=lj;
    }

    @Id
    @Column(name = "CYGJBH", nullable = false)
    public Integer getCygjbh() {
        return this.cygjbh;
    }

    public void setCygjbh(Integer cygjbh) {
        this.cygjbh = cygjbh;
    }

    @Column(name = "GJMC", nullable = false, length = 50)
    public String getGjmc() {
        return this.gjmc;
    }

    public void setGjmc(String gjmc) {
        this.gjmc = gjmc;
    }

    @Column(name = "MRXSSX")
    public Integer getMrxssx() {
        return this.mrxssx;
    }

    public void setMrxssx(Integer mrxssx) {
        this.mrxssx = mrxssx;
    }

    @Column(name = "LX")
    public Integer getLx() {
        return lx;
    }

    public void setLx(Integer lx) {
        this.lx = lx;
    }

    @Column(name = "LJ", length = 250)
    public String getLj() {
        return lj;
    }

    public void setLj(String lj) {
        this.lj = lj;
    }

}
