package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.CodeItem;
import cn.edu.nju.software.service.model.XxxModel;

import java.util.Date;
import java.util.List;

/**
 *  信息项service
 * @author 13314
 * @date 2018/8/13
 */
public interface XxxService {
    XxxModel findByTableAndColumn(String fydm,String szb, String szl) ;

    String getSsdwLbbhByAjxzAndSpcx(String fydm,String ajxz,String spcx) ;
}
