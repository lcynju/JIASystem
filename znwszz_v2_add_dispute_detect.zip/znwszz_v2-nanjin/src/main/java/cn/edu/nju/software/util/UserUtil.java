package cn.edu.nju.software.util;

import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.exception.BaseException;

import javax.servlet.http.HttpServletRequest;

public class UserUtil {
    public static YhModel checkUserLogin(HttpServletRequest request){
        YhModel user = (YhModel) request.getSession().getAttribute("user");
        if (user == null) {
            throw new BaseException("用户未登录或用户登陆失效，请重新登陆");
        }
        return user;
    }
}
