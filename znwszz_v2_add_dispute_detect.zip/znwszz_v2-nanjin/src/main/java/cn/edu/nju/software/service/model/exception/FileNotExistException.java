package cn.edu.nju.software.service.model.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  目标文档不存在exception
 * @author 13314
 * @date 2018/8/11
 */
@Data
@AllArgsConstructor
public class FileNotExistException extends RuntimeException{
    private String fileName ;
}
