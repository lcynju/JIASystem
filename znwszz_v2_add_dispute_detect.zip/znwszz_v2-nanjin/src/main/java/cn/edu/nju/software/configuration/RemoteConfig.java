package cn.edu.nju.software.configuration;

import cn.edu.nju.software.manager.webServiceManager.wsjcManager.LawyeeCheckSoap;
import cn.edu.nju.software.manager.webServiceManager.ocrManager.SpAndZsService;
import cn.edu.nju.software.util.UrlUtil;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.jaxws.JaxWsPortProxyFactoryBean;
import org.springframework.remoting.jaxws.SimpleJaxWsServiceExporter;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

/**
 * Created by 13314 on 2018/9/6.
 */
@Configuration
public class RemoteConfig implements InitializingBean{

    private static String WEBSERVICE_BASE_URL = "http://%s:%s/webServices/";
    private static Logger logger = Logger.getLogger(RemoteConfig.class) ;

    @Value("${wsjcService.callBackPort}")
    private String port ;

//    @Bean
    public SimpleJaxWsServiceExporter jaxWsExporter(){
        SimpleJaxWsServiceExporter simpleJaxWsServiceExporter = new SimpleJaxWsServiceExporter();
        simpleJaxWsServiceExporter.setBaseAddress(WEBSERVICE_BASE_URL);
        return simpleJaxWsServiceExporter;
    }
//    @Bean
    public JaxWsPortProxyFactoryBean ocrService(){
        JaxWsPortProxyFactoryBean proxy = new JaxWsPortProxyFactoryBean() ;
        try {
            URL wsdlUrl = new URL("http://130.1.1.215:9001/ZhfyService?wsdl") ;
            proxy.setWsdlDocumentUrl(wsdlUrl);
            proxy.setServiceName("zhfy");
            proxy.setPortName("SpAndZsServiceImplPort");
            proxy.setServiceInterface(SpAndZsService.class);
            proxy.setNamespaceUri("http://spzsService.ExtInterface.software.nju/");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return proxy ;
    }

//    @Bean
    public JaxWsPortProxyFactoryBean wsjcService(){
        JaxWsPortProxyFactoryBean proxy = new JaxWsPortProxyFactoryBean() ;
        try {
            URL wsdlURL = new URL("http://130.39.112.42:8604/LawyeeService/LawyeeCheck.asmx?wsdl") ;
            proxy.setWsdlDocumentUrl(wsdlURL);
            proxy.setServiceName("LawyeeCheck");
            proxy.setPortName("LawyeeCheckSoap");
            proxy.setServiceInterface(LawyeeCheckSoap.class);
            proxy.setNamespaceUri("http://tempuri.org/");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return proxy ;
    }

    public static String getWebserviceBaseUrl(){
        return WEBSERVICE_BASE_URL ;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        try {
            WEBSERVICE_BASE_URL = String.format(WEBSERVICE_BASE_URL,UrlUtil.getHostAddress(),"8081") ;
        } catch (UnknownHostException e) {
            logger.error("获取本机ip错误，错误信息："+e.getMessage());
            e.printStackTrace();
        }
    }
}
