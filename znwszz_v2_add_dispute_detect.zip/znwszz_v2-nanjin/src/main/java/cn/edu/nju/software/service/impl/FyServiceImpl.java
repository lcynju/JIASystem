package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.service.FyService;
import cn.edu.nju.software.service.model.FyModel;
import cn.edu.nju.software.service.model.enums.FyEnum;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2018/9/21
 * @time 10:32
 * @Description
 */
@Service
public class FyServiceImpl implements FyService {
    @Override
    public List<FyModel> getFyList() {
        /**
         * 一级法院
         */
        List<FyModel> yjFy = new ArrayList<>(6) ;

        //高院
        FyModel gy = new FyModel(FyEnum.TJGY.getName(),FyEnum.TJGY.getFydm(),FyEnum.TJGY.getJc()) ;

        //一中院
        FyModel yzy = new FyModel(FyEnum.TJYZY.getName(),FyEnum.TJYZY.getFydm(),FyEnum.TJYZY.getJc()) ;

        //二中院
        FyModel ezy = new FyModel(FyEnum.TJEZY.getName(),FyEnum.TJEZY.getFydm(),FyEnum.TJEZY.getJc()) ;

        //滨海
        FyModel bh = new FyModel(FyEnum.TJBH.getName(),FyEnum.TJBH.getFydm(),FyEnum.TJBH.getJc()) ;

        //海事
        FyModel hs = new FyModel(FyEnum.TJHS.getName(),FyEnum.TJHS.getFydm(),FyEnum.TJHS.getJc()) ;

        //铁路
        FyModel tl = new FyModel(FyEnum.TJTL.getName(),FyEnum.TJTL.getFydm(),FyEnum.TJTL.getJc()) ;

        List<FyModel> yzyXjfys = new ArrayList<>() ;
        List<FyModel> ezyXjfys = new ArrayList<>() ;
        List<FyModel> bhXjfys = new ArrayList<>() ;
        for(FyEnum fyEnum:FyEnum.values()){
            if(fyEnum.getFydm().charAt(8)=='1'&&!fyEnum.equals(FyEnum.TJYZY)){
                //一中院下级法院
                yzyXjfys.add(new FyModel(fyEnum.getName(),fyEnum.getFydm(),fyEnum.getJc())) ;
            }else if(fyEnum.equals(FyEnum.TJTG)||fyEnum.equals(FyEnum.TJHG)||fyEnum.equals(FyEnum.TJDG)||fyEnum.equals(FyEnum.TJKFQ)){
                //滨海新区下级法院
                //先提取出滨海新区的下级法院，避免进入二中院下级法院
                bhXjfys.add(new FyModel(fyEnum.getName(),fyEnum.getFydm(),fyEnum.getJc())) ;
            }else if(fyEnum.getFydm().charAt(8)=='2'&&!fyEnum.equals(FyEnum.TJEZY)&&!fyEnum.equals(FyEnum.TJBH)){
                //二中院下级法院
                ezyXjfys.add(new FyModel(fyEnum.getName(),fyEnum.getFydm(),fyEnum.getJc())) ;
            }
        }
        yzy.setXjFy(yzyXjfys);
        ezy.setXjFy(ezyXjfys);
        bh.setXjFy(bhXjfys);

        yjFy.add(gy) ;
        yjFy.add(yzy) ;
        yjFy.add(ezy) ;
        yjFy.add(bh) ;
        yjFy.add(hs) ;
        yjFy.add(tl) ;
        return yjFy ;
    }

    @Override
    public List<FyModel> getOrdinaryFyList() {
        List<FyModel> allFys = new ArrayList<>(25) ;
        for(FyEnum fyEnum:FyEnum.values()){
            allFys.add(new FyModel(fyEnum.getName(),fyEnum.getFydm(),fyEnum.getJc())) ;
        }
        return allFys ;
    }
}
