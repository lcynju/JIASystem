package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.LaAyDO;
import cn.edu.nju.software.data.dataobject.LaAyDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/14
 */
@Repository
public interface LaAyDao extends JpaRepository<LaAyDO,LaAyDOId> {
    List<LaAyDO> findByAjxh(int ajxh) ;
}
