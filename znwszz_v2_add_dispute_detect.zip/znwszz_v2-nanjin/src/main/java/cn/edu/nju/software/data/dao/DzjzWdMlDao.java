package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DzjzWdMlDO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/7/30.
 */
@Repository
public interface DzjzWdMlDao extends JpaRepository<DzjzWdMlDO,String> {
    List<DzjzWdMlDO> getByMlid(String mlid) ;
    List<DzjzWdMlDO> getByAjxhAndMlmcNotLike(int ajxh,String hsz) ;
}
