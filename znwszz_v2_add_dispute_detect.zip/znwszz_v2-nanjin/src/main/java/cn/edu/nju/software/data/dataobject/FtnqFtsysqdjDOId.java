package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.util.Objects;

/**
 * 不用
 * FtnqFtsysqdjDOId entity. @author MyEclipse Persistence Tools
 */
@Embeddable
public class FtnqFtsysqdjDOId implements java.io.Serializable {

	// Fields

	private Integer ajxh;
	private Integer sqbh;

	// Constructors

	/** default constructor */
	public FtnqFtsysqdjDOId() {
	}

	/** full constructor */
	public FtnqFtsysqdjDOId(Integer ajxh, Integer sqbh) {
		this.ajxh = ajxh;
		this.sqbh = sqbh;
	}

	// Property accessors

	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Column(name = "SQBH", nullable = false)
	public Integer getSqbh() {
		return this.sqbh;
	}

	public void setSqbh(Integer sqbh) {
		this.sqbh = sqbh;
	}

	@Override
    public boolean equals(Object other) {
		if ((this == other)) {
            return true;
        }
		if ((other == null)) {
            return false;
        }
		if (!(other instanceof FtnqFtsysqdjDOId)) {
            return false;
        }
		FtnqFtsysqdjDOId castOther = (FtnqFtsysqdjDOId) other;

		return ((Objects.equals(this.getAjxh(), castOther.getAjxh())) || (this.getAjxh() != null
				&& castOther.getAjxh() != null && this.getAjxh().equals(
				castOther.getAjxh())))
				&& ((Objects.equals(this.getSqbh(), castOther.getSqbh())) || (this.getSqbh() != null
				&& castOther.getSqbh() != null && this.getSqbh()
				.equals(castOther.getSqbh())));
	}

	@Override
    public int hashCode() {
		int result = 17;

		result = 37 * result
				+ (getAjxh() == null ? 0 : this.getAjxh().hashCode());
		result = 37 * result
				+ (getSqbh() == null ? 0 : this.getSqbh().hashCode());
		return result;
	}

}