package cn.edu.nju.software.service.model;


import lombok.Data;

import java.util.Arrays;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
@Data
public class WsModel {
    private Integer ajxh ;
    private Integer wsbh ;
    private String wslb ;
    private String wswjm ;

    @Override
    public String toString() {
        return "WsModel{" +
                "ajxh=" + ajxh +
                ", wsbh=" + wsbh +
                ", wslb='" + wslb + '\'' +
                ", wswjm='" + wswjm + '\'' +
                '}';
    }
}
