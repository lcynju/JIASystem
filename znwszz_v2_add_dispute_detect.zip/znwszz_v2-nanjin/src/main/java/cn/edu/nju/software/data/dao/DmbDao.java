package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DmbDO;
import cn.edu.nju.software.data.dataobject.DmbDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/10.
 */
@Repository
public interface DmbDao extends JpaRepository<DmbDO,DmbDOId> {
    List<DmbDO> findByLbbh(String lbbh) ;
    DmbDO findByLbbhAndDmbh(String lbbh, String dmbh) ;
}
