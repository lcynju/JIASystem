package cn.edu.nju.software.service.model;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 *  目录model
 * @author 13314
 * @date 2018/7/30
 */
@ApiModel
@Data
public class MlModel {
    @ApiModelProperty(value = "目录id")
    private String id ;
    @ApiModelProperty(value = "目录名称")
    private String mc ;
    @ApiModelProperty(value = "目录显示顺序，目录已排序")
    private Integer xssx ;
    @ApiModelProperty(value = "子目录列表")
    private List<MlModel> zml ;
    @ApiModelProperty(value = "目录下文档，只有在叶节点目录下才会有文档")
    private List<WdModel> wds ;

    public MlModel() {
    }

    public MlModel(String id, String mc, Integer xssx) {
        this.id = id;
        this.mc = mc;
        this.xssx = xssx;
    }

    @Override
    public String toString() {
        return "MlModel{" +
                "id='" + id + '\'' +
                ", mc='" + mc + '\'' +
                ", xssx=" + xssx +
                ", zml=" + zml +
                ", wds=" + wds +
                '}';
    }
}
