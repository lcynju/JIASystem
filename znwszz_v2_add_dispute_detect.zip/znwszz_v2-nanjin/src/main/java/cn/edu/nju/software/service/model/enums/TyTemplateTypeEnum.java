package cn.edu.nju.software.service.model.enums;

/**
 *  通用类模板，即不需要案件信息
 * @author 13314
 * @date 2018/8/17
 */
public enum TyTemplateTypeEnum {
}
