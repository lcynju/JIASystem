package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.DmbDO;
import cn.edu.nju.software.service.model.DmbModel;

/**
 *
 * @author 13314
 * @date 2018/8/14
 */
public class DmbConvertor {

    public static DmbModel DO2Model(DmbDO DO){
        DmbModel model = new DmbModel() ;
        model.setBz(DO.getBz());
        model.setDmbh(DO.getDmbh());
        model.setDmms(DO.getDmms());
        model.setDqbs(DO.getDqbs());
        model.setFybh(DO.getFybh() == null ? -1 : DO.getFybh());
        model.setLbbh(DO.getLbbh());
        model.setXgdm(DO.getXgdm());
        model.setXgdm2(DO.getXgdm2());
        model.setXgsj(DO.getXgsj());
        model.setXssx((Double)DO.getXssx() == null ? 0 : DO.getXssx());
        return model ;
    }
}
