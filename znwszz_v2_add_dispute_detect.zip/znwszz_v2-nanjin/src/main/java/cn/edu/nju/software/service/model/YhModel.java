package cn.edu.nju.software.service.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.io.Serializable;

/**
 *
 * @author 13314
 * @date 2018/7/27
 */
@ApiModel
@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class YhModel implements Serializable{
    @ApiModelProperty("用户编号")
    private Integer yhbh ;
    @ApiModelProperty("用户名称")
    private String name ;
    @ApiModelProperty("用户代码")
    private String dm ;
    @ApiModelProperty("用户法院代码")
    private String fydm ;
    @ApiModelProperty("用户部门代码")
    private String bm ;
    @ApiModelProperty("用户身份")
    private String sf ;
    @ApiModelProperty("用户口令")
    private String password ;
}
