/**
 * Created by YuanHao on 2018/7/25.
 *  核心页面
 */
var vm = avalon.define({
    $id: 'dzjz',
    user: '',
    password: '',
    ajlx: AJLX,
    selectedAjlx: AJLX.ZB,
    selectedWdId: '',
    selectedAjxh: '',
    selectedMb: SELECTED_MB.EMPTY,
    selectedEmptyMb: SHOW_STATE.SHOW,
    showOcrContent: SHOW_STATE.HIDE,
    login_state: LOGIN_STATE.LOGIN,
    aj_list: {
        'zb': [],
        'cs': [],
        'yj': []
    },
    confirm_import_tip:IMPORT_TIP.confirm,
    right_selected_document_name_tail: '.docx',
    right_selected_document_name: '',
    true_selectedAj: '',
    selected_ocr_map: {},
    part_aj_list: [],
    zjIdxList: [],
    selectedZj: 1,
    selectedAj: '',
    fold_tree_margin: FOLD_TREE_MARGIN.MARGIN_2,
    time_begin: begin_time.Format('yyyy-MM-dd'),
    time_end: today_time.Format('yyyy-MM-dd'),
    select_time_state: SHOW_STATE.HIDE,
    left_view_state: LEFT_VIEW_STATE.FLFG,
    query_aj_state: AJ_STATE.HIDE,
    ajxh_state: SHOW_STATE.HIDE,
    flfg_view_state: SHOW_STATE.HIDE,
    doc_image_state: DOC_IMAGE_STATE.EMPTY,
    fyList: FY_LIST,
    selectedFy: FY_LIST[0],
    login_username: LOGIN_USERNAME.UNLOGIN,
    left_label_state: SHOW_STATE.SHOW,
    right_label_state: SHOW_STATE.SHOW,
    mblx: [],
    right_win_height: 1080,
    left_win_height: 1080,
    tree_win_height: 1080,
    right_document_editor_dict: {},
    left_document_editor_dict: {},
    right_opened_document_model_state: 0,
    right_opened_document_model_dict: {},
    right_opened_document_list: [],
    load_tree_view_finish: true,
    tree_opened_document_list: [],
    tree_document_editor_dict: {},
    tree_document_key_ajxh_dict: {},
    tree_selected_document: '',
    //保存树状图中的文档id和生成的key值
    tree_opened_document_key_dict: {},
    left_opened_document_list: [],
    right_selected_document: '',
    left_selected_document: '',
    tree_image_list: [],
    tree_image_ocr_dict: {},
    extract_text: '',
    keep_get_ocr_v: null,
    login_tip: LOGIN_TIP.LOGIN_ING,
    get_data_tip: GET_DATA_TIP.GET_DATA_ING,
    load_document_tip: LOAD_DOCUMENT.LOADING_IMAGE,
    login_text: '登陆',
    login_button_text: LOGIN_TIP.LOGIN_ING,
    flfg_web_site: FLFG_WEBSITE,
    selected_web_site: '',
    selected_aj_ktxx_list: ["正在加载开庭笔录..."],
    selected_aj_ktxx: 0,
    fx_url: 'http://192.0.100.106:8086',
    llzu_url: 'http://192.2.2.16/login',

    //缓存所有的modeling
    case_modeling_dict:{},
    show_case_modeling:false ,
    //按钮名称
    case_modeling_text:'案件建模' ,


    show_login: function () {
        if (this.login_text === LOGIN_TEXT.LOGIN) {
            vm.login_button_text = LOGIN_TIP.LOGIN;
            $('#login_form').modal('show');
        } else {
            this.cancel_login();
        }
    },

    change_opened_document: function (key, type) {
        if (type === 'right') {
            vm.right_selected_document = key;
        } else if (type === 'left') {
            vm.left_selected_document = key;
            vm.render_case_modeling()
        } else if (type === 'tree') {
            vm.tree_selected_document = key;
        }
    },

    change_web_site: function (id, url) {
        if (id === 0) {
            vm.flfg_view_state = SHOW_STATE.HIDE;
        } else {
            vm.selected_web_site = id;
            vm.load_flfg_website(url);
        }
    },
    delete_document: function (key, type) {
        deleteDocument(key, type);
    },
    change_mb: function (type) {
        var btn = $('#change_mb_button');
        btn.button('loading');
        if (type === 0) {
            vm.selectedEmptyMb = SHOW_STATE.SHOW;
            getEmptyDocument();
            setTimeout(function () {
                btn.button('reset');
            }, 1000);
        } else {
            if (vm.selectedMb !== "31") {
                vm.do_change_mb('');
            } else {
                vm.get_ktxx_list();
            }
        }
    },

    get_ktxx_list: function () {
        $('#ktbl_form').modal('show');
        $.ajax({
            url: '/getTemplateKtxx',
            data: {
                ajxh: vm.selectedAjxh
            },
            type: 'get',
            success: function (data) {
                if (check_result(data)) {
                    vm.selected_aj_ktxx_list = data.object;
                }
            }
        })
    },
    get_ktxx: function (ktxx) {
        vm.selected_aj_ktxx = vm.selected_aj_ktxx_list.indexOf(ktxx);
        vm.do_change_mb(vm.selected_aj_ktxx);

    },

    import_dzjz: function () {
        if (vm.right_opened_document_list.length > 0) {
            vm.confirm_import_tip = IMPORT_TIP.confirm;
            $('#import_dzjz_form').modal('show');

        } else {
            error_tip(NO_SELECTED_FILE.right)
        }

    },

    show_off_ktbl: function () {
        $('#ktbl_form').modal('hide');
        var btn = $('#change_mb_button');
        btn.button('reset');
    },
    show_off_dzjz: function () {
        $('#import_dzjz_form').modal('hide');
    },

    do_change_mb: function (ktxx) {
        var btn = $('#change_mb_button');
        vm.selectedEmptyMb = SHOW_STATE.HIDE;
        $.ajax({
            url: '/getTemplateWd',
            type: 'get',
            data: {
                ajxh: vm.selectedAjxh,
                templateBh: vm.selectedMb,
                ktbh: ktxx,
            },
            success: function (result) {
                if (check_result(result)) {
                    var dom_name = 'rightView' + result.object.key;
                    load_document(dom_name, result, 'right');
                    setTimeout(function () {
                        btn.button('reset');
                    }, 1000);
                    if (ktxx !== '') {
                        setTimeout(function () {
                            $('#ktbl_form').modal('hide');
                        }, 500)
                    }
                }
            },
            error: function () {
                error_tip(ERROR_MESSAGE.UNEXPECTED);
                setTimeout(function () {
                    btn.button('reset');
                }, 1000);
            }
        })
    },

    load_flfg_website: function (url) {
        var flfg = $('#flfgViewContent');
        var btn = $('#return_flfg');
        btn.button('loading');
        flfg.attr('src', url);
        this.flfg_view_state = SHOW_STATE.SHOW;
        switch (url) {
            case FLFG_WEBSITE[0].url:
                this.selected_web_site = FLFG_WEBSITE[0].id;
                break;
            case FLFG_WEBSITE[1].url:
                this.selected_web_site = FLFG_WEBSITE[1].id;
                break;
            case FLFG_WEBSITE[2].url:
                this.selected_web_site = FLFG_WEBSITE[2].id;
                break;
        }
        setTimeout(function () {
            btn.button('reset');
        }, 1000);
    },

    queryAJ: function (force) {
        //进行查询之前先清空之前的数据
        vm.part_aj_list.removeAll();
        var selectedAjlx = vm.selectedAjlx;
        //如果缓存中存在则不再重新请求
        if (vm.aj_list[selectedAjlx].length !== 0 && force === 0) {
            vm.fresh_aj_list();
        }
        else {
            vm.query_aj_state = AJ_STATE.AJ_LIST;
            $('#get_data_tip').css('display', 'block');
            $('#get_data_tip').css('color', 'black');
            vm.get_data_tip = GET_DATA_TIP.GET_DATA_ING;
            var wait = setInterval(function () {
                if (vm.get_data_tip.length > 20) {
                    vm.get_data_tip = GET_DATA_TIP.GET_DATA_ING;
                } else {
                    vm.get_data_tip = vm.get_data_tip + '.';
                }
            }, 500);
            $.ajax({
                url: baseUrl + '/getAjList',
                type: 'get',
                data: {
                    begin: vm.time_begin,
                    end: vm.time_end,
                    type: vm.selectedAjlx
                },
                success: function (res) {
                    if (check_result(res)) {
                        clearInterval(wait);
                        $('#get_data_tip').css('display', 'none');
                        var aj_list = res.object;
                        aj_list.forEach(function (aj) {
                            aj.larq = (new Date(aj.larq)).Format('yyyy-MM-dd');
                            if (aj.jarq !== null) {
                                aj.jarq = (new Date(aj.jarq)).Format('yyyy-MM-dd');
                            } else {
                                aj.jarq = '----:--:--';
                            }
                        });
                        if (aj_list.length === 0) {
                            switch (selectedAjlx) {
                                case 'zb':
                                    vm.aj_list[selectedAjlx] = EMPTY_LIST.ZB_EMPTY.slice(0, 1);
                                    break;
                                case 'cs':
                                    vm.aj_list[selectedAjlx] = EMPTY_LIST.CS_EMPTY.slice(0, 1);
                                    break;
                                case 'yj':
                                    vm.aj_list[selectedAjlx] = EMPTY_LIST.YJ_EMPTY.slice(0, 1);
                                    break;
                            }
                        } else {
                            vm.aj_list[selectedAjlx] = aj_list;
                        }
                        vm.fresh_aj_list();
                    } else {
                        $('#get_data_tip').css('color', 'red');
                        vm.get_data_tip = res.message;
                    }
                },
                error: function (data, status, e) {
                    $('#get_data_tip').css('color', 'red');
                    vm.get_data_tip = ERROR_MESSAGE.UNEXPECTED;
                }
            })
        }

    },
    //刷新列表
    fresh_aj_list: function () {
        create_pagination(vm.aj_list[vm.selectedAjlx].length);
        vm.changeZj(1);
        vm.query_aj_state = AJ_STATE.AJ_LIST;
    },

    check_mb_visible: function () {
        return this.query_aj_state === AJ_STATE.AJXQ && this.left_view_state === LEFT_VIEW_STATE.DZJZ;
    },

    changeAjlx: function (type) {
        switch (type) {
            case AJLX.ZB:
                this.selectedAjlx = 'zb';
                this.select_time_state = SHOW_STATE.HIDE;
                this.queryAJ(0);
                break;
            case AJLX.CS:
                this.selectedAjlx = 'cs';
                this.select_time_state = SHOW_STATE.HIDE;
                this.queryAJ(0);
                break;
            case AJLX.YJ:
                this.selectedAjlx = 'yj';
                this.select_time_state = SHOW_STATE.SHOW;
                this.queryAJ(0);
                break;
        }
        change_document_size();
    },

    changeZj: function (index) {
        var aj_list = vm.aj_list[vm.selectedAjlx];
        this.selectedZj = index;
        if (aj_list.length < 15) {
            $('.aj_table').css('height', 'auto');
            $('.aj_table tbody tr td').css('height', '60px');
            this.part_aj_list = aj_list.slice(0, aj_list.length);
            return;
        }
        if (index === Math.ceil(aj_list.length / 15)) {
            this.part_aj_list = aj_list.slice((index - 1) * 15);
            $('.aj_table').css('height', 'auto');
            $('.aj_table tbody tr td').css('height', '60px');
        }
        else {
            $('.aj_table tbody tr td').css('height', 'auto');
            $('.aj_table').css('height', '80vh');
            this.part_aj_list = aj_list.slice((index - 1) * 15, index * 15);
        }

    },
    /**
     * 由案件详情页面返回到案件列表
     */
    return_queryAj: function () {
        $('#view_dzjz_image').attr("src", "");
        vm.query_aj_state = AJ_STATE.AJ_LIST;
    },
    /**
     * 获取电子卷宗文档目录
     * @param ajxh 案件的id
     * @param ajah 案件案号
     * @param ajmc 案件名称
     */
    get_ajxh: function (ajxh, ajah, ajmc) {
        if (ajmc === EMPTY_LIST.YJ_EMPTY[0].ajmc) {
            return;
        }
        //用于后面请求关联模板
        vm.load_tree_view_finish = false;
        vm.selectedAjxh = ajxh;
        vm.selectedAj = ajah;
        vm.true_selectedAj = ajah;
        vm.query_aj_state = AJ_STATE.AJXQ;
        var tree_view = $('#left_tree_view');
        vm.load_document_tip = LOAD_DOCUMENT.LOADING_AJXQ;
        tree_view.treeview('collapseAll', {silent: true});
        $('#load_document_tip').css('color', 'black');
        $('#load_document_tip').css('display', 'block');
        var wait1 = setInterval(function () {
            if (vm.load_document_tip.length > 20) {
                vm.load_document_tip = LOAD_DOCUMENT.LOADING_AJXQ;
            } else {
                vm.load_document_tip += '.';
            }
        }, 500);

        $.ajax({
            url: baseUrl + '/getDzjzWdMl?ajxh=' + ajxh,
            type: 'get',
            success: function (result) {
                clearInterval(wait1);
                if (check_result(result)) {
                    vm.load_tree_view_finish = true;
                    var res = result.object;
                    if (res.length === 3) {
                        vm.fold_tree_margin = FOLD_TREE_MARGIN.MARGIN_3;
                    } else if (res.length === 2) {
                        vm.fold_tree_margin = FOLD_TREE_MARGIN.MARGIN_2;
                    } else if (res.length === 4) {
                        vm.fold_tree_margin = FOLD_TREE_MARGIN.MARGIN_4;
                    }
                    res = parse_dzjz_wdml(res);
                    $('#fold_tree').html(FOLD_TREE_VIEW.EXPANDED);
                    create_treeview(res);
                    vm.get_template_ml();
                    if (vm.tree_image_list.length > 0) {
                        vm.download_all_image_ocr();
                    }
                    $('#load_document_tip').css('display', 'none');
                } else {
                    vm.load_document_tip = LOAD_DOCUMENT.LOADING_AJXQ_FAILED;
                    $('#load_document_tip').css('color', 'red');
                }
            },
            error: function (data, status, e) {
                error_tip(ERROR_MESSAGE.UNEXPECTED);
            }
        });

    },
    download_all_image_ocr: function () {
        var tree_image_json_list = vm.tree_image_list.join("__");
        $.ajax({
            url: baseUrl + '/getOcrResultAll',
            type: 'post',
            data: {
                'ajxh': vm.selectedAjxh,
                'wdIdListString': tree_image_json_list
            },
            success: function (data) {
                if (check_result(data)) {
                    vm.keep_get_ocr();
                }
            }
        })
    },

    keep_get_ocr: function () {
        vm.keep_get_ocr_v = setInterval(function () {
            $.ajax({
                url: 'checkOcrResult',
                type: 'post',
                data: {
                    ajxh: vm.selectedAjxh
                },
                success: function (data) {
                    if (check_result(data)) {
                        var ocr_map = data.object;
                        if (ocr_map !== null) {
                            if (Object.keys(ocr_map).length >= vm.tree_image_list.length) {
                                clearInterval(vm.keep_get_ocr_v);
                            }
                            vm.tree_image_ocr_dict = ocr_map;
                        }
                    }
                }
            })
        }, 2000)
    },

    /**
     * 确认登陆
     */
    confirm_login: function () {
        $('#confirm_login').attr('disabled', 'disabled');
        vm.login_button_text = LOGIN_TIP.LOGIN;
        $('#login_tip').css('display', 'none');
        var wait = setInterval(function () {
            if (vm.login_button_text.length > 6) {
                vm.login_button_text = LOGIN_TIP.LOGIN_ING;
            } else {
                vm.login_button_text = vm.login_button_text + '.';
            }
        }, 500);
        $.ajax({
            url: baseUrl + '/login',
            type: "post",
            data: {
                fy: this.selectedFy,
                name: this.user,
                password: this.password
            },
            success: function (result) {
                clearInterval(wait);
                $('#confirm_login').removeAttr("disabled");
                if (check_result(result)) {
                    vm.login_state = LOGIN_STATE.LOGIN;
                    vm.login_button_text = LOGIN_TIP.LOGIN_SUCCESS;
                    vm.login_username = "欢迎您，" + result.object.name + "（" + result.object.sf + "）";
                    document.cookie = "dm=" + result.object.dm;
                    getDocumentModel();
                    setTimeout(function () {
                        $('#login_form').modal('hide');
                    }, 1000);
                } else {
                    $('#login_tip').css('display', 'inline-block');
                    $('#login_tip').css('color', 'red');
                    vm.login_button_text = LOGIN_TIP.LOGIN;
                    vm.login_tip = LOGIN_TIP.LOGIN_FAILED;
                }
            },
            error: function (data, status, e) {
                clearInterval(wait);
                $('#confirm_login').removeAttr("disabled");
                vm.login_tip = LOGIN_STATE.UNEXPECTED;
                $('#login_tip').css('color', 'red');
                clearInterval(wait);
                $('#login_tip').css('display', 'inline-block');
            }
        });
    },

    //注销登录
    cancel_login: function () {
        //  从cookie中获取用户名
        var dm = getCookie();
        // 发送请求让服务器删除session
        $.ajax({
            url: baseUrl + '/cancelLogin',
            type: "get",
            data: {
                name: dm
            },
            success: function () {
                vm.login_state = LOGIN_STATE.UNLOGIN;
                delCookie(dm);
            }
        })
    },

    show_off_login: function () {
        $('#login_form').modal('hide');
    },

    //打开电子卷宗
    open_dzjz: function () {
        vm.left_view_state = LEFT_VIEW_STATE.DZJZ;
        if (vm.query_aj_state === AJ_STATE.HIDE) {
            this.queryAJ(0);
        }
    },
    //打开本地文档
    open_bdwd: function () {
        vm.left_view_state = LEFT_VIEW_STATE.BDWD;
    },
    confirm_import: function () {

        vm.confirm_import_tip = IMPORT_TIP.wait;
        $.ajax({
            url: '/saveToDzjz',
            data: {
                ajxh: vm.selectedAjxh,
                newFileName: vm.right_selected_document_name + vm.right_selected_document_name_tail,
                wdId: vm.right_opened_document_model_dict[vm.right_selected_document].wdId
            },
            type:'post',
            success: function (result) {
                if (check_result(result)) {
                    if (result.object) {
                        vm.confirm_import_tip = IMPORT_TIP.finish;
                        var dom_name = 'rightView' + result.object.key;
                        deleteDocument(vm.right_selected_document, 'right');
                        load_document(dom_name, result, 'right');
                        setTimeout(function () {
                            $('#import_dzjz_form').modal('hide');
                        }, 1000);
                    }
                } else {
                    vm.confirm_import_tip = IMPORT_TIP.confirm;
                    error_tip(result.message);
                }
            }
        })
    },
    //打开法律法规
    open_flfg: function () {
        vm.left_view_state = LEFT_VIEW_STATE.FLFG;
    },
    get_template_ml: function () {
        $.ajax({
            url: baseUrl + '/getTemplateMl',
            type: 'get',
            data: {
                ajxh: vm.selectedAjxh,
                type: 2
            },
            success: function (result) {
                if (check_result(result)) {
                    vm.mblx = result.object.wds;
                    vm.selectedMb = vm.mblx[0].id;
                }
            }
        })
    },

    change_image_ocr: function () {
        var node_id = vm.selectedWdId;
        if (vm.showOcrContent === SHOW_STATE.HIDE) {
            $('#view_dzjz_ocr_content').fadeIn({
                duration: 500
            });
            vm.showOcrContent = SHOW_STATE.SHOW;
            vm.extract_text = vm.tree_image_ocr_dict[node_id];
        } else {
            $('#view_dzjz_ocr_content').fadeOut({
                duration: 500
            });
            vm.showOcrContent = SHOW_STATE.HIDE;
            vm.extract_text = '';
        }
    },

    change_case_modeling:function () {
        if(vm.show_case_modeling){
            vm.show_case_modeling = false ;
            vm.case_modeling_text = '案件建模' ;
        }else {
            var key = vm.left_selected_document;
            if (!vm.case_modeling_dict[key]) {
                vm.get_and_render_case_modeling()
            }else{
                vm.case_modeling_text = '返回原文';
                vm.show_case_modeling = true;
                vm.render_case_modeling()
            }
        }
    },
    render_case_modeling:function () {
        current_case_modeling = vm.case_modeling_dict[vm.left_selected_document];
        render(current_case_modeling);
    },
    get_and_render_case_modeling:function(){
        var wdId = vm.selectedWdId;
        $.ajax({
           url: baseUrl + '/getCaseModeling',
           type: 'get',
           data: {
               wdId:wdId,
           },
           success: function (result) {
               if (check_result(result)) {
                   vm.case_modeling_dict[vm.left_selected_document] = result.object ;
                   vm.case_modeling_text = '返回原文';
                   vm.show_case_modeling = true;
                   vm.render_case_modeling()
                }
            }
        })
    },
});

function render(model) {
    var res = '';
    if (model) {
        if (model.bases && model.bases.length>0) {
            res += '<div><h2>婚姻基本情况</h2>'
            model.bases.forEach(function(item) {
                res += generateEventFieldHtml(item);
            })
            res += '</div>'
        }
        if (model.lives && model.lives.length>0) {
            res += '<div><h2>生活感情情况</h2>'
            model.lives.forEach(function(item) {
                res += generateEventFieldHtml(item);
            })
            res += '</div>'
        }
        if (model.properties && model.properties.length>0) {
            res += '<div><h2>财产情况</h2>'
            model.properties.forEach(function(item) {
                res += generateEventFieldHtml(item);
            })
            res += '</div>'
        }

    }
    $('#view-divorce-case').html(res);
    console.log(res);
    $('.panel-heading').click(function() {
        $(this).next().slideToggle();
    });
}
function generateEventFieldHtml(eventField) {
    var res = '<div><h3>'+eventField.type+'</h3>';
    res += generateEventsHtml(eventField.events);
    res += '</div>';
    return res;
}
function generateEventsHtml(events) {
    var res = '';
    events.forEach(function(item) {
        res += generateBaseEventHtml(item);
    })
    return res;
}
function generateBaseEventHtml(event) {
    if(event.yg){
        return '<div class="panel panel-info"><div class="panel-heading">'
            +event.title+'</div><div class="panel-body" style="display: none;">'
            +event.renderedSentence+'</div></div>';
    }else{
        return '<div class="panel panel-success"><div class="panel-heading">'
            +event.title+'</div><div class="panel-body" style="display: none;">'
            +event.renderedSentence+'</div></div>';
    }

}

