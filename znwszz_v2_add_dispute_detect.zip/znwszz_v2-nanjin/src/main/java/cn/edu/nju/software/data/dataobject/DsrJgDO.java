package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import java.io.Serializable;

/**
 *
 * @author 13314
 * @date 2018/8/15
 */
@Entity(name = "DSR_XP_JG")
@IdClass(DsrJgDOId.class)
public class DsrJgDO implements Serializable{

    private Integer ajxh;
    private Integer dsrbh;
    private String jgmc;
    private String xzjgxz;
    private String sffy;
    private String sfpc;
    private String dh;
    private String dz;
    private String yb;
    private String fddbrxm;
    private String djzlb;
    private String djzh;

    @Column(name = "AJXH", nullable = false)
    @Id
    public Integer getAjxh() {
        return ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }
    @Column(name = "DSRBH", nullable = false)
    @Id
    public Integer getDsrbh() {
        return dsrbh;
    }

    public void setDsrbh(Integer dsrbh) {
        this.dsrbh = dsrbh;
    }
    @Column(name = "JGMC")
    public String getJgmc() {
        return jgmc;
    }

    public void setJgmc(String jgmc) {
        this.jgmc = jgmc;
    }
    @Column(name = "XZJGXZ")
    public String getXzjgxz() {
        return xzjgxz;
    }

    public void setXzjgxz(String xzjgxz) {
        this.xzjgxz = xzjgxz;
    }
    @Column(name = "SFFY")
    public String getSffy() {
        return sffy;
    }

    public void setSffy(String sffy) {
        this.sffy = sffy;
    }
    @Column(name = "SFPC")
    public String getSfpc() {
        return sfpc;
    }

    public void setSfpc(String sfpc) {
        this.sfpc = sfpc;
    }
    @Column(name = "DH")
    public String getDh() {
        return dh;
    }

    public void setDh(String dh) {
        this.dh = dh;
    }

    @Column(name = "DZ")
    public String getDz() {
        return dz;
    }

    public void setDz(String dz) {
        this.dz = dz;
    }
    @Column(name = "YB")
    public String getYb() {
        return yb;
    }

    public void setYb(String yb) {
        this.yb = yb;
    }
    @Column(name = "FDDBRXM")
    public String getFddbrxm() {
        return fddbrxm;
    }

    public void setFddbrxm(String fddbrxm) {
        this.fddbrxm = fddbrxm;
    }
    @Column(name = "DJZLB")
    public String getDjzlb() {
        return djzlb;
    }

    public void setDjzlb(String djzlb) {
        this.djzlb = djzlb;
    }
    @Column(name = "DJZH")
    public String getDjzh() {
        return djzh;
    }

    public void setDjzh(String djzh) {
        this.djzh = djzh;
    }

    @Override
    public String toString() {
        return "DsrJgDO{" +
                "ajxh='" + ajxh + '\'' +
                ", dsrbh='" + dsrbh + '\'' +
                ", jgmc='" + jgmc + '\'' +
                ", xzjgxz='" + xzjgxz + '\'' +
                ", sffy='" + sffy + '\'' +
                ", sfpc='" + sfpc + '\'' +
                ", dh='" + dh + '\'' +
                ", dz='" + dz + '\'' +
                ", yb='" + yb + '\'' +
                ", fddbrxm='" + fddbrxm + '\'' +
                ", djzlb='" + djzlb + '\'' +
                ", djzh='" + djzh + '\'' +
                '}';
    }
}
