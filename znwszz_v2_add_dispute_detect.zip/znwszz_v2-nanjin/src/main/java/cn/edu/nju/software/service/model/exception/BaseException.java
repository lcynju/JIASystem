package cn.edu.nju.software.service.model.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  通用错误
 * @author 13314
 * @date 2018/8/11
 */
@Data
@AllArgsConstructor
public class BaseException extends RuntimeException{
    private String message ;
}
