package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.PubXtglYhbDao;
import cn.edu.nju.software.data.dataobject.PubXtglYhbDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.UserService;
import cn.edu.nju.software.service.convertor.YhConvertor;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.YhCheckResult;
import cn.edu.nju.software.service.model.enums.YhCheckResultCodeEnum;
import cn.edu.nju.software.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/7/27
 */
@Service("userService")
public class UserServiceImpl implements UserService {
    private PubXtglYhbDao yhbRepostiy ;

    @Autowired
    public UserServiceImpl(PubXtglYhbDao yhbRepostiy) {
        this.yhbRepostiy = yhbRepostiy;
    }

    @Override
    public YhCheckResult login(String fydm, String userName,String password) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        YhCheckResult checkResult = new YhCheckResult() ;
        List<PubXtglYhbDO> yhs = yhbRepostiy.findByYhdm(userName);
        DynamicDataSource.router(curDB);
        if(yhs==null||yhs.isEmpty()){
            checkResult.setSuccess(false);
            checkResult.setResultCode(YhCheckResultCodeEnum.ILLEGAL_USERNAME);
            return checkResult ;
        }else {
            for (PubXtglYhbDO yhbDO:yhs){
                if(StringUtil.equals(yhbDO.getYhkl(),password)){
                    checkResult.setSuccess(true);
                    checkResult.setXtyh(YhConvertor.yhDO2Model(fydm,yhbDO));
                    return checkResult ;
                }
            }
            checkResult.setSuccess(false);
            checkResult.setResultCode(YhCheckResultCodeEnum.ILLEGAL_PASSWORD);
        }

        return checkResult ;
    }

    @Override
    public YhModel findByYhdm(String fydm, String yhdm) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        YhCheckResult checkResult = new YhCheckResult() ;
        List<PubXtglYhbDO> yhs = yhbRepostiy.findByYhdm(yhdm);
        DynamicDataSource.router(curDB);
        if(yhs==null||yhs.isEmpty()){
            return null ;
        }
        return YhConvertor.yhDO2Model(fydm,yhs.get(0));
    }
}
