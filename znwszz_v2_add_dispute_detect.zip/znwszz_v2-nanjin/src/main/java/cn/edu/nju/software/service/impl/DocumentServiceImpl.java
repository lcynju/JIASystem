package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.configuration.RemoteConfig;
import cn.edu.nju.software.manager.DocumentModelFactory;
import cn.edu.nju.software.manager.webServiceManager.wsjcManager.CaseIdHolder;
import cn.edu.nju.software.manager.webServiceManager.wsjcManager.LawyeeCheckSoap;
import cn.edu.nju.software.manager.webServiceManager.wsjcManager.WsjcCallBackService;
import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.YhModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.service.model.exception.FileNotExistException;
import cn.edu.nju.software.util.DocumentUtil;
import cn.edu.nju.software.util.StringUtil;
import cn.edu.nju.software.util.UrlUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/11
 */
@Service
public class DocumentServiceImpl implements DocumentService,InitializingBean {

    @Autowired
    private DocumentModelFactory documentModelFactory ;



//    @Autowired
    private LawyeeCheckSoap wsjcService ;

    @Autowired
    private WsjcCallBackService wsjcCallBackService ;
    /**
     * 上传文件临时位置
     */
    @Value("${spring.servlet.multipart.location}")
    private String tempDir ;

    /**
     * 存储上传文件的地址
     */
    @Value("${files.storage.location:data}")
    private String saveDir ;

    private Logger logger = LoggerFactory.getLogger(DocumentServiceImpl.class) ;

    @Override
    public DocumentModel saveDocumentByYhmodeAndIpAddress(YhModel yhModel, String ipAddress, String fileName, byte[] content) {
        String dirPath = getSaveDirByYhModelAndIpAddress(yhModel,ipAddress) ;
        logger.info("save新文件"+dirPath+fileName);
        File dir = new File(dirPath) ;
        if(!dir.exists()&&!dir.mkdirs()){
            logger.error("创建上传文件文件夹失败，请重试");
            throw new BaseException("创建上传文件文件夹失败，请重试") ;
        }
        String correctPathToSave = getCorrectPathToSave(dirPath, fileName) ;
        logger.info("save新文件名称为"+correctPathToSave) ;
        File file = new File(correctPathToSave) ;
        try {
            if(content!=null&&content.length>0){
                FileOutputStream fos = new FileOutputStream(file) ;
                fos.write(content);
                fos.flush();
                fos.close();
            }else {
                if(!file.createNewFile()){
                    logger.error("save文件失败,地址:"+correctPathToSave);
                    throw new BaseException("创建失败，请重试") ;
                }
            }
        }catch (IOException e){
            logger.error("save文件失败，message:"+e.getMessage());
            throw new BaseException("创建失败，请联系管理员") ;
        }
        return createDocumentBySavePath(correctPathToSave);
    }

    /**
     * 根据个人信息和登陆ip地址获取在服务器上的文档存储文件夹
     * @param yhModel
     * @param ipAddress
     * @return
     */
    private String getSaveDirByYhModelAndIpAddress(YhModel yhModel,String ipAddress){
        String dirPath  ;
        if(yhModel!=null){
            dirPath = saveDir+File.separator+FyEnum.findByFydm(yhModel.getFydm())+File.separator+yhModel.getName() ;
        }else {
            dirPath = saveDir+File.separator+ipAddress.replaceAll(":",".") ;
        }
        return dirPath ;
    }
    /**
     * 获得应该存储的绝对路径
     * @param submitFileRelativePath
     * @return savepath
     */
    private String getCorrectPathToSave(String dirPath,String submitFileRelativePath) {
        if(StringUtil.isEmpty(dirPath)){
            dirPath = saveDir ;
        }
        String baseName = DocumentUtil.getFileNameWithoutExtension(submitFileRelativePath) ;
        String ext = DocumentUtil.getFileExtension(submitFileRelativePath) ;
        String name = submitFileRelativePath ;
        String savePath = dirPath+File.separator+name ;
        File file = new File(savePath) ;
        for (int i=1;file.exists();i++){
            name = baseName + "(" + i + ")" +ext ;
            savePath = dirPath+File.separator+name ;
            file = new File(savePath) ;
        }
        return savePath ;
    }

    @Override
    public DocumentModel updateDocumentNameByYhmodelAndIpAddress(YhModel yhModel, String ipAddress, String oldFileName, String newFileName) {
        String dirPath = getSaveDirByYhModelAndIpAddress(yhModel,ipAddress) ;
        logger.info("更新文件名，文件夹："+dirPath+",原文件名："+oldFileName+"，新文件名："+newFileName);
        File oldFile = new File(dirPath+File.separator+oldFileName) ;
        if(!oldFile.exists()){
            logger.error("更新文档名失败，源文件不存在");
            throw new BaseException("更新文档名失败，源文件不存在");
        }
        File newFile = new File(dirPath+File.separator+newFileName) ;
        if(!oldFile.exists()){
            logger.warn("更新文档时，已存在一个新名称文件："+dirPath+File.separator+newFileName);
            String correctPathToSave = getCorrectPathToSave(dirPath, newFileName);
            boolean renameIsSuccessed = newFile.renameTo(new File(correctPathToSave));
            if(renameIsSuccessed){
                logger.warn("把原新名称文件："+newFileName+"更名为"+correctPathToSave);
            }
            newFile = new File(dirPath+File.separator+newFileName) ;
        }
        boolean renameTo = oldFile.renameTo(newFile);
        if(renameTo){
            logger.info("更新文件名称成功，文件夹"+dirPath+",原名称："+oldFileName+"新名称："+newFileName);
        }else {
            logger.error("更新文件名称失败，文件夹"+dirPath+",原名称："+oldFileName+"新名称："+newFileName);
        }
        return createDocumentBySavePath(dirPath+File.separator+newFileName);
    }

    @Override
    public boolean deleteDocumentByYhmodelAndIpAddress(YhModel yhModel, String ipAddress, String fileName) {
        String dirPath = getSaveDirByYhModelAndIpAddress(yhModel,ipAddress) ;
        logger.info("删除文件，文件夹："+dirPath+"文件名："+fileName);
        File file = new File(dirPath+File.separator+fileName) ;
        if(file.exists()){
            if(!file.delete()){
                logger.error("删除文件失败："+dirPath+File.separator+fileName);
                return false ;
            }else {
                logger.info("删除文件成功"+dirPath+File.separator+fileName);
            }
        }else {
            logger.warn("删除的目标文件不存在"+dirPath+File.separator+fileName);
        }
        return true;
    }

    @Override
    public String[] getFileNamesListByYhmodelAndIpAddress(YhModel yhModel, String ipAddress) {
        String dirPath = getSaveDirByYhModelAndIpAddress(yhModel,ipAddress) ;
        logger.info("获取文件名数组，文件夹："+dirPath);
        File file = new File(dirPath) ;
        if(file.exists()){
            return file.list();
        }else {
            file.mkdirs() ;
        }
        return null;
    }

    @Override
    public DocumentModel getDocumentByYhmodeAndIpAddressAndFileName(YhModel yhModel, String ipAddress, String fileName) {
        String dirPath = getSaveDirByYhModelAndIpAddress(yhModel,ipAddress) ;
        logger.info("获取目标文件的documentModel"+dirPath+File.separator+fileName);
        /**
         * 检查文件是否存在
         */
        File file = new File(dirPath+File.separator+fileName) ;
        if(!file.exists()){
            logger.error("目标文件不存在:"+dirPath+File.separator+fileName);
            throw new BaseException("目标文件不存在") ;
        }
        return createDocumentBySavePath(dirPath+File.separator+fileName);
    }


    /**
     * 构造documentModel
     * @param absolatePath 文件保存的绝对路径
     * @return document实例
     */
    @Override
    public DocumentModel createDocumentBySavePath (String absolatePath) {

        DocumentModel documentModel = null ;
        String name = DocumentUtil.getDocumentName(absolatePath);
        String docKey = DocSourceEnum.LOCAL.getPrefix()+DocSourceEnum.CONNECTOR+getRelativePath(absolatePath) ;

        documentModel =documentModelFactory.createDocumentModelByNameAndKey(name,docKey) ;
        return documentModel ;
    }

    /**
     * 获取路径相对存储根目录的相对路径
     * @param absolatePath
     * @return
     */
    private String getRelativePath(String absolatePath){
        if(absolatePath.startsWith(saveDir)){
            return absolatePath.substring((saveDir+File.separator).length()) ;
        }
        return absolatePath ;
    }

    @Override
    public DocumentModel save(String relativePath, byte[] content) {
        logger.info("上传存储文件："+ relativePath);
        String savePath = getCorrectPathToSave(null, relativePath) ;
        try {
            FileOutputStream fos = new FileOutputStream(new File(savePath)) ;
            fos.write(content);
            fos.flush();
            fos.close();
            logger.info("储存文件："+savePath);
        } catch (IOException e) {
            logger.error("上传存储文件失败"+e.getMessage());
            throw new BaseException("上传存储文件失败") ;
        }
        return createDocumentBySavePath(savePath);
    }

    /**
     * 获取已存储文件的绝对路径
     * @param relativeFilePath 文件相对路径
     * @return
     */
    private String getSavedPath(String relativeFilePath) {
        return saveDir+File.separator+relativeFilePath ;
    }

    @Override
    public void download(HttpServletResponse response, String wdId) {
        try {
            String[] wdId_split = wdId.split(DocSourceEnum.CONNECTOR);
            String fileName = wdId_split[1] ;
            String path = getSavedPath(fileName) ;
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition","attachment;fileName="+ UrlUtil.encode(fileName));
            FileInputStream fis = new FileInputStream(path) ;
            byte[] buffer = new byte[2*1024] ;
            ServletOutputStream outputStream = response.getOutputStream();
            int len = 0 ;
            while((len = fis.read(buffer))!=-1){
                outputStream.write(buffer,0,len);
            }
            outputStream.flush();
            outputStream.close();
            fis.close();
        } catch (FileNotFoundException e) {
            logger.error("文件不存在："+wdId+",message:"+e.getMessage());
            throw new FileNotExistException(wdId) ;
        } catch (IOException e) {
            logger.error("获取response.getOutputStream失败:"+e.getMessage());
            throw new BaseException("获取response.getOutputStream失败") ;
        }
    }

    @Override
    public String wsjc(String wdId) {
        if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
            /**
             * 先判断该文档是否已经调用过且纠错成功
             */
            boolean hadJc = wsjcCallBackService.hadJc(wdId);
            if(hadJc){
                throw new BaseException("文书已经过纠错") ;
            }
            String[] split = wdId.split(DocSourceEnum.CONNECTOR);
            String savedPath = getSavedPath(split[1]);
            File savedFile = new File(savedPath);
            if(!savedFile.exists()){
                logger.error("文书纠错service出错，传入文档id不存在匹配文档");
                throw new BaseException("文件不存在，wdId:"+wdId) ;
            }
            try {
                FileInputStream fis = new FileInputStream(savedFile) ;
                byte[] content = new byte[fis.available()] ;
                fis.read(content) ;
                String caseId = CaseIdHolder.add(wdId) ;
                String wsjcShowUrl = wsjcService.checkFileCallBack(caseId,content,"",
                        RemoteConfig.getWebserviceBaseUrl()+"wsjcCallBackService", WsjcCallBackService.class.getName());
                return wsjcShowUrl ;
            } catch (IOException e) {
                e.printStackTrace();
                logger.error("文书纠错service出错，文档"+savedPath+"读取内容出错："+e.getMessage());
                throw new BaseException("文档"+savedPath+"读取出错，wdId:"+wdId) ;
            }
        }
        throw new BaseException("文书纠错service出错，传入文档id格式错误") ;
    }

    @Override
    public void updateFileContect(byte[] content, String wdId) throws IOException {
        if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())){
            String[] split = wdId.split(DocSourceEnum.CONNECTOR);
            String savedPath = getSavedPath(split[1]);
            File savedFile = new File(savedPath);
            if(savedFile.exists()) {
                savedFile.delete();
            }
            //写入
            FileOutputStream out = new FileOutputStream(savedPath);
            out.write(content);
            out.flush();
            out.close();
        }else {
            throw new BaseException("存储目标文档id错误，不是本地文档");
        }
    }

    @Override
    public DocumentModel getWsjcResult(String wdId) {
        boolean hadJc = wsjcCallBackService.hadJc(wdId);
        if(hadJc){
            if(wdId.startsWith(DocSourceEnum.LOCAL.getPrefix())) {
                String[] split = wdId.split(DocSourceEnum.CONNECTOR);
                String savedPath = getSavedPath(split[1]);
                return createDocumentBySavePath(savedPath);
            }
            return null ;
        }
        return null;
    }


    @Override
    public File getFile(YhModel yhModel,String ipAddress,String wjmc){
        String saveDirByYhModelAndIpAddress = getSaveDirByYhModelAndIpAddress(yhModel, ipAddress);
        File file = new File(saveDirByYhModelAndIpAddress+File.separator+wjmc) ;
        if(!file.exists()){
            try {
                boolean newFile = file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return file ;
    }

    @Override
    public byte[] getContent(String wdId) throws IOException {
        String[] wdId_split = wdId.split(DocSourceEnum.CONNECTOR);
        String fileName = wdId_split[1] ;
        String path = getSavedPath(fileName) ;
        FileInputStream fis = new FileInputStream(path) ;
        byte[] content = new byte[fis.available()] ;
        fis.read(content) ;
        return content ;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        /**
         * 设置上传目录
         * 1、默认为application.yml配置文件中的files.storage.location
         * 2、若配置的位置无法创建文件夹，则使用项目根目录下的data文件夹
         */
        File dir = new File(saveDir) ;
        if (!dir.exists()){
            boolean mkdirs = dir.mkdirs();
            if(!mkdirs){
                String userDir = System.getProperty("user.dir");
                saveDir = userDir+File.separator+"data" ;
                dir = new File(saveDir) ;
                if(!dir.exists()){
                    mkdirs = dir.mkdirs() ;
                    if(!mkdirs){
                        throw new BaseException("创建存储文件夹失败："+saveDir) ;
                    }
                }
            }
        }

        dir = new File(tempDir) ;
        if(!dir.exists()) {
            dir.mkdirs() ;
        }
    }
}
