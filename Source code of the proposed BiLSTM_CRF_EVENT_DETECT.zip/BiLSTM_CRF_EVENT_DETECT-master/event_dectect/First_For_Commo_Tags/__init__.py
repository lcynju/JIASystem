#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__doc__ = 'description 第一个用于预测粗粒度标签模型'
__author__ = '13314409603@163.com'

if __name__ == '__main__':
    pass