package cn.edu.nju.software.service.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 *
 * @author 13314
 * @date 2018/8/14
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DmbModel {

    private String lbbh;
    private String dmbh;
    private String dmms;
    private String xgdm;
    private String bz;
    private String modflag;
    private String transflag;
    private Date xgsj;
    private Double xssx;
    private String dqbs;
    private Integer fybh;
    private String fysx;
    private String fylbdm;
    private Integer xzqdmbh;
    private Integer dmbbh;
    private String xgdm2;
    private String bmzt;

    @Override
    public String toString() {
        return "DmbModel{" +
                "lbbh='" + lbbh + '\'' +
                ", dmbh='" + dmbh + '\'' +
                ", dmms='" + dmms + '\'' +
                ", xgdm='" + xgdm + '\'' +
                ", bz='" + bz + '\'' +
                ", modflag='" + modflag + '\'' +
                ", transflag='" + transflag + '\'' +
                ", xgsj=" + xgsj +
                ", xssx=" + xssx +
                ", dqbs='" + dqbs + '\'' +
                ", fybh=" + fybh +
                ", fysx='" + fysx + '\'' +
                ", fylbdm='" + fylbdm + '\'' +
                ", xzqdmbh=" + xzqdmbh +
                ", dmbbh=" + dmbbh +
                ", xgdm2='" + xgdm2 + '\'' +
                ", bmzt='" + bmzt + '\'' +
                '}';
    }
}
