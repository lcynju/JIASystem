package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.PubWsJbDO;
import cn.edu.nju.software.data.dataobject.PubWsJbIdDO;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
public interface PubWsJbDao extends JpaRepository<PubWsJbDO,PubWsJbIdDO> {
    List<PubWsJbDO> findByAjxhAndWsnrIsNotNull(int ajxh) ;
    PubWsJbDO findByAjxhAndWsjbbh(int ajxh,int wsjbbh) ;
}
