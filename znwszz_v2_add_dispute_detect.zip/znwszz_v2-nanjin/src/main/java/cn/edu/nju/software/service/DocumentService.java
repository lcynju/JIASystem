package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.YhModel;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

/**
 *  本地文档Service
 * @author 13314
 * @date 2018/8/6
 */
public interface DocumentService {


    /**
     * 保存本地文档,目前文档存储位置基于项目配置项中files.storage.location位置，
     * 当用户登陆状态，则在FYDM/用户名称文件夹下
     * 若用户未登陆，则在以ip为名的文件夹下
     * @param yhModel  文档所属用户
     * @param ipAddress 登陆ip
     * @param fileName 文档名称
     * @param content 文档内容，若为空，则说明是新建
     * @return
     */
    DocumentModel saveDocumentByYhmodeAndIpAddress(YhModel yhModel,String ipAddress,String fileName,byte[] content) ;

    /**
     *  更新文档名称
     * @param yhModel 文档所属用户
     * @param ipAddress 登陆ip
     * @param oldFileName 旧文件名
     * @param newFileName 新文件名
     * @return
     */
    DocumentModel updateDocumentNameByYhmodelAndIpAddress(YhModel yhModel,String ipAddress,String oldFileName,String newFileName) ;

    /**
     *  删除个人文档
     * @param yhModel
     * @param ipAddress
     * @param fileName
     * @return
     */
    boolean deleteDocumentByYhmodelAndIpAddress(YhModel yhModel,String ipAddress,String fileName) ;

    /**
     * 获取个人文档名称list
     * @param yhModel
     * @param ipAddress
     * @return
     */
    String[] getFileNamesListByYhmodelAndIpAddress(YhModel yhModel,String ipAddress) ;

    /**
     * 获取单个文档model
     * @param yhModel
     * @param ipAddress
     * @param fileName
     * @return
     */
    DocumentModel getDocumentByYhmodeAndIpAddressAndFileName(YhModel yhModel,String ipAddress,String fileName) ;
    /**
     * 构造documentModel
     * @param savePath 文件保存的绝对路径
     * @return document实例
     */
    DocumentModel createDocumentBySavePath (String savePath) ;

    /**
     * 存储文件到服务器本地相对路径
     * @param relativePath 文件相对路径名，即相对于files.storage.location配置项根目录的路径
     * @param content
     * @return
     */
    DocumentModel save(String relativePath, byte[] content) ;

    /**
     *
     * @param response
     * @param wdId
     */
    void download(HttpServletResponse response,String wdId) ;

    /***
     * 针对目标文档进行文书纠错
     * @param wdId
     * @return
     */
    String wsjc(String wdId) ;

    /**
     * 更新文档内容
     * @param context
     * @param wdId
     * @throws IOException
     */
    void updateFileContect(byte[] context, String wdId) throws IOException;

    /**
     * 获取纠错结果文档
     * @param wdId
     * @return
     */
    DocumentModel getWsjcResult(String wdId) ;

    /**
     * 根据文件名和用户信息返回文件，若不存在则新建一个空文档
     * @param yhModel
     * @param ipAddress
     * @param wjmc
     * @return
     */
    File getFile(YhModel yhModel,String ipAddress,String wjmc) ;

    /**
     * 获取文档内容
     * @param wdId
     * @return
     */
    byte[] getContent(String wdId) throws IOException;
}
