package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:50
 * @Description
 */
public class DivorceLawsuit extends BaseEvent {
    private String sueTime ;
    private String initiator ;
    private String court ;
    private String judgeTime ;
    private String result ;
    private String judgeDocument ;

    public DivorceLawsuit(HashMap<String,Object> map){
        super(map);
        this.sueTime = (String) map.get("sueTime");
        this.forRendaring.add((ArrayList<Integer>) map.get("sueTime_index_pair")) ;

        this.initiator = (String) map.get("initiator");
        this.forRendaring.add((ArrayList<Integer>) map.get("initiator_index_pair")) ;

        this.judgeTime = (String) map.get("judgeTime");
        this.forRendaring.add((ArrayList<Integer>) map.get("judgeTime_index_pair")) ;

        this.court = (String) map.get("court");
        this.forRendaring.add((ArrayList<Integer>) map.get("court_index_pair")) ;

        this.judgeDocument = (String) map.get("judgeDocument");
        this.forRendaring.add((ArrayList<Integer>) map.get("judgeDocument_index_pair")) ;

        this.result = (String) map.get("result");
        this.forRendaring.add((ArrayList<Integer>) map.get("result_index_pair")) ;
    }

    @Override
    /**
     * negated: sueTime initiator trigger judgeTime court result +(judgeDocument)
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.sueTime!=null && this.sueTime.length()>0){
            if(str.length()>0){
                str = str +" "+this.sueTime ;
            }else {
                str = this.sueTime ;
            }
        }
        if(this.initiator!=null && this.initiator.length()>0){
            if(str.length()>0){
                str = str +" "+this.initiator ;
            }else {
                str = this.initiator ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }

        if(this.judgeTime!=null && this.judgeTime.length()!=0){
            str = str+" "+this.judgeTime ;
        }

        if(this.court!=null && this.court.length()>0){
            str = str +" " +court ;
        }
        if(this.result!=null && this.result.length()>0){
            str = str+" "+result ;
        }
        if(this.judgeDocument!=null && this.judgeDocument.length()>0){
            str = str+" ("+this.judgeDocument+")" ;
        }
        this.title = str ;
    }
}
