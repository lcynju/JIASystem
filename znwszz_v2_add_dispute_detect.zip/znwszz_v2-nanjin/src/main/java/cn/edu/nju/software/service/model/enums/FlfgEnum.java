package cn.edu.nju.software.service.model.enums;

/**
 * @author 13314409603@163.com
 * @date 2018/10/26
 * @time 17:00
 * @Description
 */
public enum FlfgEnum {
    /**
     * 法律法规网站
     */
    FX(1,"发信","fx","http://192.0.100.106:8086","http://130.39.3.101:82/login/Index.aspx?authcode=%s&site=1001001008&key=%s") ,
    LLZS(2,"律例注疏","llzs","http://192.2.2.16/login","http://192.2.2.16/direct/%s/%s/%s") ,
    ZGSPFLYYZCXT(3,"中国审判法律应用支持系统","zgspflyyzcxt","http://130.1.1.155/law/","http://130.1.1.155/law/") ,
    ;
    int bh;
    String mc ;
    String jc ;
    //主页
    String url ;
    //免密登陆接口
    String gatewarUrl ;

    FlfgEnum(int bh, String mc, String jc, String url, String gatewarUrl) {
        this.bh = bh;
        this.mc = mc;
        this.jc = jc;
        this.url = url;
        this.gatewarUrl = gatewarUrl;
    }

    public int getBh() {
        return bh;
    }

    public String getMc() {
        return mc;
    }

    public String getJc() {
        return jc;
    }

    public String getUrl() {
        return url;
    }

    public String getGatewarUrl() {
        return gatewarUrl;
    }
}
