vm.$watch("query_aj_state", function (new_value, old_value) {
    change_document_size();
    vm.check_mb_visible();
    if (new_value !== AJ_STATE.AJXQ) {
        show_tree_view();
        vm.tree_image_ocr_dict = {};
        vm.tree_image_list.removeAll();
        clearInterval(vm.keep_get_ocr_v);
    }
});

vm.$watch("selectedAjxh", function () {
    vm.doc_image_state = DOC_IMAGE_STATE.EMPTY;
});

vm.$watch("left_view_state", function () {
    vm.check_mb_visible();
    change_document_size();
});

vm.$watch("login_state", function (new_value, old_value) {
    getFlfgList();
    if (new_value === LOGIN_STATE.LOGIN) {
        vm.login_text = LOGIN_TEXT.EXIT;
    } else {
        vm.login_username = LOGIN_USERNAME.UNLOGIN;
        vm.query_aj_state = AJ_STATE.HIDE;
        vm.aj_list[AJLX.ZB].removeAll();
        vm.aj_list[AJLX.CS].removeAll();
        vm.aj_list[AJLX.YJ].removeAll();
        vm.part_aj_list.removeAll();
        vm.left_view_state = LEFT_VIEW_STATE.BDWD;
        vm.login_text = LOGIN_TEXT.LOGIN;
    }
});

vm.$watch("tree_selected_document", function (new_value, old_value) {
    vm.selectedAj = vm.tree_document_key_ajxh_dict[new_value];
});

vm.$watch("right_opened_document_model_state", function (new_value, old_value) {
    console.log(new_value);
    $.ajax({
        url: '/saveDocumentModelList',
        type: 'post',
        data: JSON.stringify(vm.right_opened_document_model_dict),
        dataType: 'json',
        contentType: 'application/json',
        success: function (data) {
            console.log(data);
        }
    })
});

vm.$watch("right_selected_document", function (new_value, old_value) {
    var full_name = vm.right_opened_document_model_dict[new_value].name;
    var names = full_name.split('.');
    if (names.length === 2) {
        vm.right_selected_document_name = names[0];
        vm.right_selected_document_name_tail = '.' + names[1];
    } else if (names.length > 2) {
        vm.right_selected_document_name = names[0];
        vm.right_selected_document_name_tail = '.' + names.slice(1).join('')
    }

});
/**
 * !!！Important!!!
 * 页面加载完成后初始化页面
 */

$(document).ready(function () {
    init_view_state();
});


