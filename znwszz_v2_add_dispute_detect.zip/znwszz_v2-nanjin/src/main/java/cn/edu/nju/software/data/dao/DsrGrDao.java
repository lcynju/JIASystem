package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DsrGrDO;
import cn.edu.nju.software.data.dataobject.DsrGrDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/10.
 */
@Repository
public interface DsrGrDao extends JpaRepository<DsrGrDO,DsrGrDOId> {
    List<DsrGrDO> findByAjxh(int ajxh) ;
}
