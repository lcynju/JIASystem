package cn.edu.nju.software.service.convertor;


import cn.edu.nju.software.data.dataobject.PubXtglYhbDO;
import cn.edu.nju.software.service.model.YhModel;

/**
 * Created by 13314 on 2018/7/31.
 */
public class YhConvertor {
    public static YhModel yhDO2Model(String fydm, PubXtglYhbDO yhb){
        YhModel yhModel = new YhModel(yhb.getYhbh(),yhb.getYhmc(),yhb.getYhdm(),fydm,yhb.getYhbm(),yhb.getYhsf(),yhb.getYhkl()) ;
        return yhModel ;
    }
}
