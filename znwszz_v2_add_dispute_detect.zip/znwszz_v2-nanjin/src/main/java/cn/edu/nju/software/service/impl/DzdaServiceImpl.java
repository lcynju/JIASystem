package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.configuration.properties.JzdaServiceProperties;
import cn.edu.nju.software.data.dao.DzdaWdAjDao;
import cn.edu.nju.software.data.dao.DzdaWdWjDao;
import cn.edu.nju.software.data.dao.DzdaWdWjjDao;
import cn.edu.nju.software.data.dao.PubAjJbDao;
import cn.edu.nju.software.data.dataobject.DzdaWdAjDO;
import cn.edu.nju.software.data.dataobject.DzdaWdWjDO;
import cn.edu.nju.software.data.dataobject.DzdaWdWjjDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.manager.DocumentModelFactory;
import cn.edu.nju.software.service.DzdaWjService;
import cn.edu.nju.software.service.convertor.DzdaConvertor;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.MlModel;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by 13314 on 2018/9/12.
 */
@Service
public class DzdaServiceImpl implements DzdaWjService {
    @Autowired
    private DzdaWdAjDao dzdaWdAjDao ;
    @Autowired
    private PubAjJbDao ajJbDao ;
    @Autowired
    private DzdaWdWjjDao dzdaWdWjjDao ;
    @Autowired
    private DzdaWdWjDao dzdaWdWjDao ;

    @Autowired
    private DocumentModelFactory documentModelFactory ;
    @Autowired
    private JzdaServiceProperties jzdaServicePro ;
    @Override
    public MlModel getDzdaMlByAjxh(String fydm, String ah) {
        MlModel mlModel = new MlModel() ;
        mlModel.setId(DocSourceEnum.YSDA.getPrefix());
        mlModel.setMc(DocSourceEnum.YSDA.getMc());
        mlModel.setXssx(DocSourceEnum.YSDA.getXssx());
        if(ah==null){
            return mlModel ;
        }
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);

        DzdaWdAjDO wdAjDO = dzdaWdAjDao.findByAh(ah);
        if(wdAjDO == null){
            return mlModel ;
        }
        List<DzdaWdWjjDO> wjjs = dzdaWdWjjDao.findByWjjssah(wdAjDO.getAjid());
        if(wjjs==null||wjjs.isEmpty()){
            return mlModel ;
        }
        List<MlModel> zml = new ArrayList<>() ;
        for(DzdaWdWjjDO wjj:wjjs){
            List<DzdaWdWjDO> wjs = dzdaWdWjDao.findByWjsswjj(wjj.getWjjid());
            if(wjs!=null&&!wjs.isEmpty()){
                MlModel wjjMl = DzdaConvertor.mlDO2MlModel(wjj);
                List<WdModel> wds = new ArrayList<>() ;
                for(DzdaWdWjDO wj:wjs){
                    WdModel wdModel = DzdaConvertor.wjDO2WjModel(fydm,wj) ;
                    wds.add(wdModel) ;
                }
                wjjMl.setWds(wds);
                zml.add(wjjMl) ;
            }
        }
        mlModel.setZml(zml);
        DynamicDataSource.router(curDB);
        return mlModel ;
    }

    @Override
    public DocumentModel getDzjzDocumentModel( String wdId) {


        //wdId由"dzda-fydm_dzdaWdWjId"构成
        String[] split_wdId = wdId.split(DocSourceEnum.CONNECTOR);
        String fydm = split_wdId[1] ;
        String curDB = DynamicDataSource.getCurrentDB();
        DynamicDataSource.router(fydm);
        DzdaWdWjDO dzdaWdWjDO = dzdaWdWjDao.findByWjid(split_wdId[2]);

        /**
         * 构造documentModel
         */
        String name = dzdaWdWjDO.getWjmc() ;
        DocumentModel documentModel = documentModelFactory.createDocumentModelByNameAndKey(name, wdId);

        //电子档案文档下载地址调用远程接口
        String baseUrl = jzdaServicePro.getDzdaDownloadUrl() ;
        String downloadUrl = String.format(baseUrl, FyEnum.findByFydm(fydm).getFybh(), split_wdId[2]) ;
        documentModel.setUrl(downloadUrl);

        DynamicDataSource.router(curDB);
        return documentModel;
    }

    @Override
    public Map<String, ArrayList<String>> getOcrResult(int ajxh, String fydm) {
        return null;
    }
}
