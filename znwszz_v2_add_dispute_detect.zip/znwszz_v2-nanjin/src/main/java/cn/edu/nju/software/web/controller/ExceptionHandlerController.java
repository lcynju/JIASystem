package cn.edu.nju.software.web.controller;

import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.service.model.exception.CreateDocumentException;
import cn.edu.nju.software.service.model.exception.FileNotExistException;
import cn.edu.nju.software.web.vo.ResultVO;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *  自定义错误的处理controller
 * @author 13314
 * @date 2018/8/7
 */
@ControllerAdvice
public class ExceptionHandlerController {

    @ResponseBody
    @ExceptionHandler(CreateDocumentException.class)
    public ResultVO createFileFailed(CreateDocumentException exception){
        ResultVO error = new ResultVO() ;
        error.setSucceed(false);
        error.setMessage("创建文档model失败，文档名："+exception.getFileName()) ;
        return error ;
    }

    @ResponseBody
    @ExceptionHandler(FileNotExistException.class)
    public ResultVO fileNotExists(FileNotExistException e){
        ResultVO error = new ResultVO() ;
        error.setSucceed(false);
        error.setMessage("目标文档不存在："+e.getFileName());
        return error ;
    }

    @ResponseBody
    @ExceptionHandler(BaseException.class)
    public ResultVO baseException(BaseException e){
        ResultVO errorVO = new ResultVO() ;
        errorVO.setSucceed(false);
        errorVO.setMessage(e.getMessage());
        return errorVO ;
    }
}
