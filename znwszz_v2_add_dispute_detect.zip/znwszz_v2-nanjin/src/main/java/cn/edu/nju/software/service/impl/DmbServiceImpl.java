package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.DmbDao;
import cn.edu.nju.software.data.dataobject.DmbDO;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.DmbService;
import cn.edu.nju.software.service.XxxService;
import cn.edu.nju.software.service.convertor.DmbConvertor;
import cn.edu.nju.software.service.model.DmbModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author 13314
 * @date 2018/8/13
 */
@Service
public class DmbServiceImpl implements DmbService{
    @Autowired
    private XxxService xxxService ;
    @Autowired
    private DmbDao dmbDao ;
    private Logger logger = LoggerFactory.getLogger(DmbServiceImpl.class) ;


    @Override
    public Map<String,DmbModel> getSsdwDmModelListByAjxzAndSpcx(String fydm,String ajxz, String spcx) {
        String curDb = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        String ssdwLbbh = xxxService.getSsdwLbbhByAjxzAndSpcx(fydm,ajxz, spcx);
        List<DmbModel> dmModelListByLbbh = this.getDmModelListByLbbh(fydm, ssdwLbbh);
        Map<String,DmbModel> ssdwMap = null ;
        if(dmModelListByLbbh!=null&&!dmModelListByLbbh.isEmpty()){
            ssdwMap = new HashMap<>(dmModelListByLbbh.size()) ;
            for(DmbModel model:dmModelListByLbbh){
                ssdwMap.put(model.getDmbh(),model) ;
            }
        }
        DynamicDataSource.router(curDb);
        return ssdwMap;
    }

    @Override
    public List<DmbModel> getDmModelListByLbbh(String fydm,String lbbh) {
        String curDb = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        List<DmbDO> dms = dmbDao.findByLbbh(lbbh);
        List<DmbModel> models = new ArrayList<>() ;
        if(dms==null || dms.isEmpty()){
            return null ;
        }
        for(DmbDO DO:dms){
            models.add(DmbConvertor.DO2Model(DO)) ;
        }
        DynamicDataSource.router(curDb);
        return models;
    }

    @Override
    public DmbModel getDmModelByLbbhAndDmbh(String fydm, String lbbh,String dmbh) {
        String curDb = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        DmbDO dmbDO = dmbDao.findByLbbhAndDmbh(lbbh, dmbh);
        DynamicDataSource.router(curDb);
        return DmbConvertor.DO2Model(dmbDO);
    }
}
