package cn.edu.nju.software.service.impl;

import cn.edu.nju.software.data.dao.*;
import cn.edu.nju.software.data.dataobject.*;
import cn.edu.nju.software.data.dynamicdDatabases.DynamicDataSource;
import cn.edu.nju.software.service.DmbService;
import cn.edu.nju.software.service.convertor.QtsscyrConvertor;
import cn.edu.nju.software.service.model.*;
import cn.edu.nju.software.service.DsrService;
import cn.edu.nju.software.service.model.enums.DjzTypeEnum;
import cn.edu.nju.software.service.model.enums.FyEnum;
import cn.edu.nju.software.service.model.enums.XbEnum;
import cn.edu.nju.software.service.model.enums.ZjlbEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.DateUtil;
import cn.edu.nju.software.util.StringUtil;
import org.plutext.jaxb.svg11.G;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 *
 * @author 13314
 * @date 2018/8/10
 */
@Service
public class DsrServiceImpl implements DsrService,InitializingBean {

    private PubAjJbDao ajJbDao ;
    private DmbService dmbService ;
    private XxxglDao xxxglDao ;
    private DsrJbDao dsrJbDao ;
    private DsrGrDao dsrGrDao ;
    private DsrDwDao dsrDwDao ;
    private DsrJgDao dsrJgDao ;
    private QtsscyrDao qtsscyrDao ;
    private DsrQtsscyrGxDao dsrQtsscyrGxDao ;

    private static final String GR = "1" ;
    private static final String DW = "2" ;
    private static final String JG = "3" ;

    /**
     * 民族类别编号
     */
    private static final String MZ_LBBH="FBZ0002-97" ;
    private static Map<String,String> mzMap = new HashMap<>() ;
    /**
     * 其他诉讼参与人职务类别编号
     */
    private static final String QTSSCYR_ZW_LBBH="GB12403-90" ;
    private static Map<String,String> zwMap = new HashMap<>();

    /**
     * 籍贯
     */
    private static final String JG_LBBH = "GB2260-91" ;
    private static Map<String,String> jgMap = new HashMap<>() ;
    private Logger logger = LoggerFactory.getLogger(DsrServiceImpl.class) ;

    @Autowired
    public DsrServiceImpl(PubAjJbDao ajJbDao, DmbService dmbService, XxxglDao xxxglDao,
                          DsrJbDao dsrJbDao, DsrGrDao dsrGrDao, DsrDwDao dsrDwDao,
                          DsrJgDao dsrJgDao, QtsscyrDao qtsscyrDao,DsrQtsscyrGxDao dsrQtsscyrGxDao) {
        this.ajJbDao = ajJbDao;
        this.dmbService = dmbService;
        this.xxxglDao = xxxglDao;
        this.dsrJbDao = dsrJbDao;
        this.dsrGrDao = dsrGrDao;
        this.dsrDwDao = dsrDwDao;
        this.dsrJgDao = dsrJgDao;
        this.qtsscyrDao = qtsscyrDao;
        this.dsrQtsscyrGxDao = dsrQtsscyrGxDao;
    }


    @Override
    public List<Ssr> getDsrXxByAjxh(String fydm, int ajxh) {
        String curDB = DynamicDataSource.getCurrentDB() ;
        DynamicDataSource.router(fydm);
        PubAjJbDO ajjb = ajJbDao.findByAjxh(ajxh);
        if(ajjb==null){
            logger.error("获取案件信息失败,fydm:"+fydm+",ajxh:"+ajxh); ;
            throw new BaseException("获取案件信息失败，请确定ajxh是否正确,ajxh:"+ajxh) ;
        }

        /**
         * 先获取案件：当事人、当事人个人、当事人单位、当事人机构、其他诉讼参与人的数据库信息
         */
            //当事人基本信息-当事人基表
        List<DsrJbDO> dsrDOs = dsrJbDao.findByAjxh(ajxh);
        if(dsrDOs == null ){
            logger.warn("案件："+ajjb.getAh()+"无当事人信息");
            return null ;
        }
            //当事人详细信息：
            // 当事人个人，构造为dsrbh-dsr的map形式
        List<DsrGrDO> dsrGrDOS = dsrGrDao.findByAjxh(ajxh);
        Map<Integer,DsrGrDO> dsrGrMap = new HashMap<>(dsrGrDOS==null?0:dsrGrDOS.size()) ; ;
        if(dsrGrDOS!=null&&!dsrGrDOS.isEmpty()){
            dsrGrDOS.forEach(dsrGrDO -> dsrGrMap.put(dsrGrDO.getDsrbh(),dsrGrDO));
        }

            //当事人单位，
        List<DsrDwDO> dsrDwDOS = dsrDwDao.findByAjxh(ajxh);
        Map<Integer,DsrDwDO> dsrdwMap= new HashMap<>(dsrDwDOS==null?0:dsrDwDOS.size()) ;
        if(dsrDwDOS!=null&&!dsrDwDOS.isEmpty()){
            dsrDwDOS.forEach(dsrDwDO -> dsrdwMap.put(dsrDwDO.getDsrbh(),dsrDwDO));
        }

            //当事人机关
        List<DsrJgDO> dsrJgDOS = dsrJgDao.findByAjxh(ajxh);
        Map<Integer,DsrJgDO> dsrjgMap= new HashMap<>(dsrJgDOS==null?0:dsrJgDOS.size()) ;
        if(dsrJgDOS!=null&&!dsrJgDOS.isEmpty()){
            dsrJgDOS.forEach(dsrJgDO -> dsrjgMap.put(dsrJgDO.getDsrbh(),dsrJgDO));
        }

            //其他诉讼参与人
        List<QtsscyrDO> qtsscyrDOs = qtsscyrDao.findByAjxh(ajxh);
            //其他诉讼参与人与当事人关系
        List<DsrQtsscyrGxDO> qtsscyrGxDOs = dsrQtsscyrGxDao.findByAjxh(ajxh);


        /**
         *  然后构造出完整的当事人诉讼地位--当事人列表
         */
        Map<String,List<Dsr>> dsrXx = new HashMap<>() ;
        for(DsrJbDO dsrDO:dsrDOs){
            //获取诉讼地位名称
            String ssdwDm = dsrDO.getDsrssdw() ;
            //初始化list
            List<Dsr> dsrModelList = dsrXx.get(ssdwDm);
            if(dsrModelList==null){
                dsrModelList = new ArrayList<>() ;
            }

            //构造单个当事人model并加入dsrModelList
            //个人
            if(StringUtil.equals(dsrDO.getDsrlb(), GR)){
                DsrGr dsrModel = new DsrGr() ;
                dsrModel.setDsrlb(GR);
                dsrModel.setMc(dsrDO.getDsrjc());
                //从当事人个人中去获取性别，出生年月，民族，住址
                DsrGrDO grDO = dsrGrMap.get(dsrDO.getDsrbh()) ;
                if(grDO!=null){
                    dsrModel.setXb(XbEnum.getMcByBh(grDO.getXb()));
                    dsrModel.setCsrq(grDO.getCsnyr()==null?" 年 月 日":DateUtil.format(grDO.getCsnyr(),DateUtil.chineseDtFormat));
                    dsrModel.setMz(mzMap.get(StringUtil.trim(grDO.getMz())));
                    dsrModel.setDz(StringUtil.isEmpty(grDO.getDz())?"住址/住所地 ":StringUtil.trim(grDO.getDz()));
                    dsrModel.setZjlb(ZjlbEnum.findMcByDm(StringUtil.trim(grDO.getZjlb())));
                    //证件类别不为null的时候设置证件号
                    dsrModel.setSfzh(dsrModel.getZjlb()==null?null:grDO.getSfzhm());
                    dsrModel.setJgdm(grDO.getJg());
                    dsrModel.setJg(dsrModel.getJgdm()==null?"籍贯 ":jgMap.get(dsrModel.getJgdm()));
                    dsrModelList.add(dsrModel) ;
                }
                //构造相关的其他诉讼参与人
                List<Qtsscyr> qtsscyrOfDsr = getQtsscyrOfDsr(qtsscyrDOs, qtsscyrGxDOs, dsrDO.getDsrbh());
                dsrModel.setQtsscyr(qtsscyrOfDsr);
            }else if(StringUtil.equals(dsrDO.getDsrlb(), DW)){
                DsrDw dsrModel = new DsrDw() ;
                dsrModel.setDsrlb(DW);
                //从当事人单位中获取全称，地址,登记证号，法定代表人，法定代表人职位
                DsrDwDO dwDO = dsrdwMap.get(dsrDO.getDsrbh()) ;
                if(dwDO!=null){
                    dsrModel.setMc(dwDO.getDwmc());
                    dsrModel.setDz(StringUtil.isEmpty(dwDO.getDz())?"地址 ":StringUtil.trim(dwDO.getDz()));
                    dsrModel.setDjzlb(DjzTypeEnum.findMcByBh(dwDO.getDjzlb()));
                    //登记账户类别为空时，登记账号不显示
                    dsrModel.setDjzh(dsrModel.getDjzlb()==null?null:dwDO.getDjzh());
                    dsrModel.setFddbr(dwDO.getFddbrxm());
                    dsrModel.setDbrzw(dwDO.getDbrzw());
                    dsrModelList.add(dsrModel) ;
                }
                //构造相关的其他诉讼参与人
                List<Qtsscyr> qtsscyrOfDsr = getQtsscyrOfDsr(qtsscyrDOs, qtsscyrGxDOs, dsrDO.getDsrbh());
                dsrModel.setQtsscyr(qtsscyrOfDsr);
            }else {
                DsrJg dsrModel = new DsrJg() ;
                dsrModel.setDsrlb(JG);
                //从当事人机构中获取全称，地址,登记证号，法定代表人
                DsrJgDO jgDO = dsrjgMap.get(dsrDO.getDsrbh()) ;
                if(jgDO!=null){
                    dsrModel.setMc(jgDO.getJgmc());
                    dsrModel.setDz(StringUtil.isEmpty(jgDO.getDz())?"地址 ":StringUtil.trim(jgDO.getDz()));
                    dsrModel.setDjzlb(DjzTypeEnum.findMcByBh(jgDO.getDjzlb()));
                    dsrModel.setDjzh(dsrModel.getDjzlb()==null?null:jgDO.getDjzh());
                    dsrModel.setFddbr(jgDO.getFddbrxm());
                    dsrModelList.add(dsrModel) ;
                }
                //构造相关的其他诉讼参与人
                List<Qtsscyr> qtsscyrOfDsr = getQtsscyrOfDsr(qtsscyrDOs, qtsscyrGxDOs, dsrDO.getDsrbh());
                dsrModel.setQtsscyr(qtsscyrOfDsr);
            }

            //放入总的map
            dsrXx.put(ssdwDm,dsrModelList) ;
        }


        /**
         * 使用dsrXx map构造诉讼人list，并排序
         */
        //先获取当事人诉讼地位信息项
        Map<String,DmbModel> ssdwMap = dmbService.getSsdwDmModelListByAjxzAndSpcx(fydm,ajjb.getAjxz(), ajjb.getSpcx());
        if(ssdwMap ==null){
            logger.error("获取案件当事人诉讼地位失败,ah:"+ajjb.getAh()); ;
            throw new BaseException("获取案件当事人诉讼地位失败,ah:"+ajjb.getAh()) ;
        }

        //然后构造诉讼人
        List<Ssr> ssrs = new ArrayList<>(dsrXx.keySet().size()) ;
        for(String ssdwDm:dsrXx.keySet()){
            Ssr ssr = new Ssr() ;
            ssr.setSsdwdm(ssdwDm);
            DmbModel model = ssdwMap.get(ssdwDm);
            ssr.setSsdwmc(model==null?"":model.getDmms());
            ssr.setDsrs(dsrXx.get(ssdwDm));
            ssrs.add(ssr) ;
        }
        //排序利用诉讼地位代码排序,这样能保证原告在被告前
        Collections.sort(ssrs, new Comparator<Ssr>() {
            @Override
            public int compare(Ssr o1, Ssr o2) {
                return o1.getSsdwdm().compareTo(o2.getSsdwdm());
            }
        });

        DynamicDataSource.router(curDB);
        return ssrs ;
    }

    /**
     * 获取单个当事人相关的其他诉讼参与人list
     * @param qtsscyrDOS
     * @param qtsscyrGxDOS
     * @param dsrbh
     * @return
     */
    private List<Qtsscyr> getQtsscyrOfDsr(List<QtsscyrDO>qtsscyrDOS,List<DsrQtsscyrGxDO> qtsscyrGxDOS,int dsrbh){
        if(qtsscyrGxDOS==null||qtsscyrGxDOS.isEmpty()||qtsscyrDOS==null||qtsscyrDOS.isEmpty()) {
            return null ;
        }
        List<Qtsscyr> qtsscyrs = new ArrayList<>() ;
        for(DsrQtsscyrGxDO gxDO:qtsscyrGxDOS){
            if(gxDO.getDsrbh() == dsrbh){
                for(QtsscyrDO cyrDO:qtsscyrDOS){
                    if(cyrDO.getQtsscyrbh().equals(gxDO.getQtsscyrbh())){
                        qtsscyrs.add(QtsscyrConvertor.DO2Model(cyrDO,zwMap)) ;
                    }
                }
            }
        }
        /**
         * 其他诉讼参与人也排序，按照参与人类型代码
         */
        Collections.sort(qtsscyrs, new Comparator<Qtsscyr>() {
            @Override
            public int compare(Qtsscyr o1, Qtsscyr o2) {
                return o1.getLxDm().compareTo(o2.getLxDm());
            }
        });
        return qtsscyrs ;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        //初始化民族 map，其他诉讼参与人map，
        // 假设所有法院针对这些信息都通用，使用高院数据初始化一次，
//            initMzMap(FyEnum.TJGY.getFydm());
//            initZwMap(FyEnum.TJGY.getFydm());
    }
    /**
     * 初始化名族信息
     * @param fydm
     */
    private void initMzMap(String fydm){
        List<DmbModel> mzDmbModelList = dmbService.getDmModelListByLbbh(fydm, MZ_LBBH);
        for(DmbModel dmbModel:mzDmbModelList){
            mzMap.put(dmbModel.getDmbh(),dmbModel.getDmms()) ;
        }
    }

    /**
     * 初始化其他诉讼参与人职务信息
     * @param fydm
     */
    private void initZwMap(String fydm){
        List<DmbModel> zwDmbModelList = dmbService.getDmModelListByLbbh(fydm, QTSSCYR_ZW_LBBH);
        for(DmbModel dmbModel:zwDmbModelList){
            zwMap.put(dmbModel.getDmbh(),dmbModel.getDmms()) ;
        }
    }
    /**
     * 初始化籍贯信息
     * @param fydm
     */
    private void initJgMap(String fydm){
        List<DmbModel> zwDmbModelList = dmbService.getDmModelListByLbbh(fydm, JG_LBBH);
        for(DmbModel dmbModel:zwDmbModelList){
            jgMap.put(dmbModel.getDmbh(),dmbModel.getDmms()) ;
        }
    }
}

