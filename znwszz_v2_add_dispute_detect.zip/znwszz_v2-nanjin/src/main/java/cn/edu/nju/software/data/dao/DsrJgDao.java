package cn.edu.nju.software.data.dao;

import cn.edu.nju.software.data.dataobject.DsrJgDO;
import cn.edu.nju.software.data.dataobject.DsrJgDOId;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by 13314 on 2018/8/15.
 */
@Repository
public interface DsrJgDao extends JpaRepository<DsrJgDO,DsrJgDOId> {
    List<DsrJgDO> findByAjxh(int ajxh) ;
}
