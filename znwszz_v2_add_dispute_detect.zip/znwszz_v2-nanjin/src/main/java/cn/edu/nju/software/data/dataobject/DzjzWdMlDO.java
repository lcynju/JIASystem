package cn.edu.nju.software.data.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**电子卷宗目录表
 * Created by 13314 on 2018/7/30.
 */
@Entity(name = "DZJZ_WD_ML")
public class DzjzWdMlDO implements java.io.Serializable {


    // Fields

    private String mlid;
    private Integer ajxh;
    private String ah;
    private String mlmc;
    private Integer mlsx;
    private String fmlid;
    private Integer sfczwj;
    private String cjr;
    private Date cjsj;
    private Date jzsj;
    private String ladjh;
    private String djxh;

    // Constructors

    /** default constructor */
    public DzjzWdMlDO() {
    }

    /** full constructor */
    public DzjzWdMlDO(Integer ajxh, String ah, String mlmc, Integer mlsx,
                      String fmlid, Integer sfczwj, String cjr, Date cjsj, Date jzsj, String ladjh, String djxh) {
        this.ajxh = ajxh;
        this.ah = ah;
        this.mlmc = mlmc;
        this.mlsx = mlsx;
        this.fmlid = fmlid;
        this.sfczwj = sfczwj;
        this.cjr = cjr;
        this.cjsj = cjsj;
        this.jzsj = jzsj;
        this.ladjh = ladjh;
        this.djxh = djxh;
    }

    // Property accessors
    @Id
    @Column(name = "MLID")
    public String getMlid() {
        return this.mlid;
    }

    public void setMlid(String mlid) {
        this.mlid = mlid;
    }

    @Column(name = "AJXH")
    public Integer getAjxh() {
        return this.ajxh;
    }

    public void setAjxh(Integer ajxh) {
        this.ajxh = ajxh;
    }

    @Column(name = "AH")
    public String getAh() {
        return this.ah;
    }

    public void setAh(String ah) {
        this.ah = ah;
    }

    @Column(name = "MLMC")
    public String getMlmc() {
        return this.mlmc;
    }

    public void setMlmc(String mlmc) {
        this.mlmc = mlmc;
    }

    @Column(name = "MLSX")
    public Integer getMlsx() {
        return this.mlsx;
    }

    public void setMlsx(Integer mlsx) {
        this.mlsx = mlsx;
    }

    @Column(name = "FMLID")
    public String getFmlid() {
        return this.fmlid;
    }

    public void setFmlid(String fmlid) {
        this.fmlid = fmlid;
    }

    @Column(name = "SFCZWJ")
    public Integer getSfczwj() {
        return this.sfczwj;
    }

    public void setSfczwj(Integer sfczwj) {
        this.sfczwj = sfczwj;
    }

    @Column(name = "CJR")
    public String getCjr() {
        return this.cjr;
    }

    public void setCjr(String cjr) {
        this.cjr = cjr;
    }

    @Column(name = "CJSJ")
    public Date getCjsj() {
        return this.cjsj;
    }

    public void setCjsj(Date cjsj) {
        this.cjsj = cjsj;
    }

    @Column(name = "JZSJ")
    public Date getJzsj() {
        return jzsj;
    }

    public void setJzsj(Date jzsj) {
        this.jzsj = jzsj;
    }

    @Column(name = "LADJH")
    public String getLadjh() {
        return ladjh;
    }

    public void setLadjh(String ladjh) {
        this.ladjh = ladjh;
    }

    @Column(name = "DJXH")
    public String getDjxh() {
        return djxh;
    }

    public void setDjxh(String djxh) {
        this.djxh = djxh;
    }

    @Override
    public String toString() {
        return "DzjzWdMlDO{" +
                "mlid='" + mlid + '\'' +
                ", ajxh=" + ajxh +
                ", ah='" + ah + '\'' +
                ", mlmc='" + mlmc + '\'' +
                ", mlsx=" + mlsx +
                ", fmlid='" + fmlid + '\'' +
                ", sfczwj=" + sfczwj +
                ", cjr='" + cjr + '\'' +
                ", cjsj=" + cjsj +
                ", jzsj=" + jzsj +
                ", ladjh='" + ladjh + '\'' +
                ", djxh='" + djxh + '\'' +
                '}';
    }
}
