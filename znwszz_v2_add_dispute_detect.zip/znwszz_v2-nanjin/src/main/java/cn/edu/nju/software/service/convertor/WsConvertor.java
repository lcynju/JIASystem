package cn.edu.nju.software.service.convertor;

import cn.edu.nju.software.data.dataobject.PubWsJbDO;
import cn.edu.nju.software.service.model.WdModel;
import cn.edu.nju.software.service.model.WsModel;
import cn.edu.nju.software.service.model.enums.DocSourceEnum;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 13314
 * @date 2018/8/16
 */
public class WsConvertor {
    public static WsModel DO2Model(PubWsJbDO DO){
        if(DO==null){
            return null ;
        }
        WsModel model = new WsModel() ;
        model.setAjxh(DO.getAjxh());
        model.setWsbh(DO.getWsjbbh());
        model.setWslb(DO.getWslb());
        model.setWswjm(DO.getWswjm());
        return model ;
    }
    public static List<WsModel> DOs2Models(List<PubWsJbDO> DOs){
        if(DOs==null||DOs.isEmpty()){
            return null ;
        }
        List<WsModel> wsModels = new ArrayList<>() ;
        for(PubWsJbDO DO:DOs){
            wsModels.add(DO2Model(DO)) ;
        }
        return wsModels ;
    }

    /**
     * 文书id由:wsxx_fydm_ajxh_wsbh
     * @param fydm
     * @param wsModel
     * @return
     */
    public static WdModel WsModel2JzdaModel(String fydm , WsModel wsModel){
        if(wsModel==null){
            return null ;
        }
        WdModel wdModel = new WdModel() ;
        wdModel.setId(DocSourceEnum.WSXX.getPrefix()+DocSourceEnum.CONNECTOR
                + fydm+DocSourceEnum.CONNECTOR
                +wsModel.getAjxh()+DocSourceEnum.CONNECTOR
                +wsModel.getWsbh());
        wdModel.setMc(wsModel.getWswjm());
        wdModel.setWjsx(wsModel.getWsbh());
        return wdModel;
    }
}
