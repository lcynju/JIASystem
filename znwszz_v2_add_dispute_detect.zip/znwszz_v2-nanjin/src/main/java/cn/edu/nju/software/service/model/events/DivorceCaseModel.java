package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2019/4/21
 * @time 19:53
 * @Description
 */
@Data
public class DivorceCaseModel {
    /**
     * 婚姻基本情况
     */
    List<EventField> bases = new ArrayList<>(5);
    /**
     * 生活感情情况
     */
    List<EventField> lives = new ArrayList<>(6);
    /**
     * 财产情况
     */
    List<EventField> properties= new ArrayList<>(3) ;

    public void addEventField(EventField eventField){
        switch (eventField.getType()){
            case "相识":
                bases.add(eventField) ;
                break;
            case "恋爱":
                bases.add(eventField) ;
                break;
            case "结婚":
                bases.add(eventField) ;
                break;
            case "再婚":
                bases.add(eventField) ;
                break;
            case "生育":
                bases.add(eventField) ;
                break;
            case "家庭矛盾":
                lives.add(eventField) ;
                break;
            case "家暴":
                lives.add(eventField) ;
                break;
            case "不良习惯":
                lives.add(eventField) ;
                break;
            case "分居":
                lives.add(eventField) ;
                break;
            case "离婚诉讼":
                lives.add(eventField) ;
                break;
            case "出轨":
                lives.add(eventField) ;
                break;
            case "财产":
                properties.add(eventField) ;
                break;
            case "债权":
                properties.add(eventField) ;
                break;
            case "债务":
                properties.add(eventField) ;
                break;
            default:
                    ;
        }
    }

}
