package cn.edu.nju.software.manager.webServiceManager.wsjcManager;

import org.apache.commons.codec.digest.DigestUtils;

import java.io.UnsupportedEncodingException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by 13314 on 2018/9/11.
 */
public class CaseIdHolder {
    private static final Map<String,String> caseIdMap = new ConcurrentHashMap<>() ;

    /**
     * get CaseId by wdId
     * @param wdId
     */
    public static String add(String wdId){
        try {
            String caseId = DigestUtils.md5Hex(wdId.getBytes("UTF-8"));
            synchronized (caseIdMap){
                caseIdMap.put(caseId,wdId) ;
            }
            return caseId ;
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null ;
    }

    /**
     * get wdId by caseId
     * @param caseId
     * @return
     */
    public static String get(String caseId){
        String wdid = null ;
        if(caseIdMap.containsKey(caseId)){
            synchronized (caseIdMap){
                wdid = caseIdMap.remove(caseId) ;
            }
        }
        return wdid ;
    }
}
