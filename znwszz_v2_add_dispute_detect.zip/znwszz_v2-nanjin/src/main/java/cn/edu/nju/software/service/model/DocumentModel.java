package cn.edu.nju.software.service.model;

import cn.edu.nju.software.service.model.enums.DocumentTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 文档模型
 * @author 13314
 * @date 2018/8/6
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description = "返回文档实例")
public class DocumentModel {
    /**
     * 不含文件路径，
     */
    @ApiModelProperty(value = "文档名,含扩展名")
    private String name ;

    @ApiModelProperty(value = "文档id")
    private String wdId ;

    @ApiModelProperty(value = "文档类型,包括文本型，表格型，展示型")
    private DocumentTypeEnum documentType ;

    @ApiModelProperty(value = "文档扩展类型，不含“.”")
    private String fileType ;

    @ApiModelProperty(value = "文件的唯一key，documentServer服务用于区别文档")
    private String key ;

    @ApiModelProperty(value = "下载对应文件的url")
    private String url ;

    @ApiModelProperty(value = "documentServer编辑文档后回调存储")
    private String callBackUrl ;

    @Override
    public String toString() {
        return "DocumentModel{" +
                "documentType=" + documentType +
                ", fileType='" + fileType + '\'' +
                ", name='" + name + '\'' +
                ", key='" + key + '\'' +
                ", url='" + url + '\'' +
                ", callBackUrl='" + callBackUrl + '\'' +
                '}';
    }
}
