package cn.edu.nju.software.manager;

import cn.edu.nju.software.configuration.properties.DocServiceProperties;
import cn.edu.nju.software.service.DocumentService;
import cn.edu.nju.software.service.model.DocumentModel;
import cn.edu.nju.software.service.model.enums.DocumentTypeEnum;
import cn.edu.nju.software.service.model.exception.BaseException;
import cn.edu.nju.software.util.DocumentUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;

/**
 *  documentServer远程调用
 * @author 13314
 * @date 2018/8/7
 */
@Component
public class DocumentServerManager {

    private DocServiceProperties docServicePro ;

    private DocumentService documentService ;
    /**
     * 格式化documentServer转换方法的参数
     */
    private static final MessageFormat ConvertParams = new MessageFormat("?url={0}&outputtype={1}&filetype={2}&title={3}&key={4}&async=false");

    private Logger logger = LoggerFactory.getLogger(DocumentServerManager.class) ;
    @Autowired
    public DocumentServerManager(DocServiceProperties docServicePro,DocumentService documentService){
        this.docServicePro = docServicePro ;
        this.documentService = documentService ;
    }

    /**
     * 转化文件格式，documentServer只支持三种格式用于edit，包括：docx,pptx,xlsx
     * @param documentModel
     * @return 转换后的文件存储路径
     */
    public DocumentModel convert(DocumentModel documentModel){
        String targetExtension = getInternalExtension(documentModel.getDocumentType());

        /**
         * 调用documentServer服务转换文档，并返回转换后文档的下载url
         */
        String downloadUrl = convertAndGetDownloadUrl(documentModel,targetExtension);

        /**
         * 下载并保存到本地
         */
        String newFileName = DocumentUtil.getFileNameWithoutExtension(documentModel.getName())+targetExtension ;
        byte[] content = downlaodConvertedDoc(downloadUrl);
        return documentService.save(newFileName,content) ;
    }

    private String convertAndGetDownloadUrl(DocumentModel documentModel,String targetExtension){
        String responseUri = null;
        try {
            /**
             * 构造转换接口的参数，包括：
             * 目标文档url
             * 转换目标格式
             * 转换前格式
             * 文件名
             * 文件唯一key
             */
            Object[] args = new Object[]{
                    URLEncoder.encode(documentModel.getUrl(),"UTF-8"),
                    targetExtension.replace(".", ""),
                    documentModel.getFileType().replace(".", ""),
                    documentModel.getName(),
                    documentModel.getKey()
            };
            /**
             * 转换url
             */
            String urlToConverter = docServicePro.getConverterUrl() + ConvertParams.format(args);
            /**
             * 连接documentServer
             */
            URL converterUrl = new URL(urlToConverter);
            HttpURLConnection converterConnection = (HttpURLConnection) converterUrl.openConnection();
            converterConnection.setRequestProperty("Accept", "application/json");
            converterConnection.setRequestMethod("POST");
            converterConnection.setConnectTimeout(docServicePro.getTimeout());
            InputStream converterStream = converterConnection.getInputStream();
            /**
             * 读取转换结果
             */
            InputStreamReader inputStreamReader = new InputStreamReader(converterStream);
            StringBuilder stringBuilder = new StringBuilder();
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            String line = bufferedReader.readLine();

            while (line != null) {
                stringBuilder.append(line);
                line = bufferedReader.readLine();
            }
            String result = stringBuilder.toString();
            /**
             * 解析转换结果
             */
            ObjectMapper mapper = new ObjectMapper();
            HashMap hashMap = mapper.readValue(result, HashMap.class);
            /**
             * 若结果错误解析错误码
             */
            String error = (String) hashMap.get("error");
            if (error != null && error != "") {
                processConvertServiceResponceError(Integer.parseInt(error));
            }
            /**
             * 根据转换进度，判断是否转换完成，
             */
            Boolean isEndConvert = (Boolean) hashMap.get("endConvert");
            if (isEndConvert) {
                responseUri = (String) hashMap.get("fileUrl");
            } else {
                Long resultPercent = (Long) hashMap.get("percent");
                logger.error("转换进度为：" + resultPercent + ",未完成");
                throw new BaseException("转换进度为：" + resultPercent + ",未完成");
            }
        }catch (Exception e){
            logger.error("调用转换服务失败："+documentModel.toString()+"，错误信息："+e.getMessage());
            throw new BaseException("调用转换服务失败："+documentModel.toString());
        }
        return responseUri ;
    }
    /**
     * 解析转换错误码
     * @param errorCode
     * @throws Exception
     */
    private void processConvertServiceResponceError(int errorCode) {
        String errorMessage = "";
        String errorMessageTemplate = "转换过程失败: ";

        switch (errorCode) {
            case -8:
                errorMessage = errorMessageTemplate + "Error document VKey";
                break;
            case -7:
                errorMessage = errorMessageTemplate + "Error document request";
                break;
            case -6:
                errorMessage = errorMessageTemplate + "Error database";
                break;
            case -5:
                errorMessage = errorMessageTemplate + "Error unexpected guid";
                break;
            case -4:
                errorMessage = errorMessageTemplate + "Error download error";
                break;
            case -3:
                errorMessage = errorMessageTemplate + "Error convertation error";
                break;
            case -2:
                errorMessage = errorMessageTemplate + "Error convertation timeout";
                break;
            case -1:
                errorMessage = errorMessageTemplate + "Error convertation unknown";
                break;
            case 0:
                break;
            default:
                errorMessage = "ErrorCode = " + errorCode;
                break;
        }

        throw new BaseException(errorMessage);
    }

    /**
     * 生成文档类型对应的后缀
     * @param fileType
     * @return
     */
    private static String getInternalExtension(DocumentTypeEnum fileType)
    {
        if(fileType.equals(DocumentTypeEnum.TEXT)) {
            return ".docx";
        }

        if(fileType.equals(DocumentTypeEnum.SPREADSHEET)) {
            return ".xlsx";
        }

        if(fileType.equals(DocumentTypeEnum.PRESENTATION)) {
            return ".pptx";
        }

        return ".docx";
    }

    private byte[] downlaodConvertedDoc(String url){
        try {
            URL downloadurl = new URL(url);
            HttpURLConnection downloadConnection = (HttpURLConnection) downloadurl.openConnection();
            InputStream downlaodStream = downloadConnection.getInputStream();

            byte[] bytes = new byte[downlaodStream.available()];
            downlaodStream.read(bytes) ;
            downlaodStream.close();
            downloadConnection.disconnect();
            return bytes ;
        }catch (Exception e){
            logger.error("下载转换后的文档失败,url:"+url);
            throw new BaseException("下载转换后的文档失败,url:"+url) ;
        }
    }
}
