package cn.edu.nju.software.util;

import cn.edu.nju.software.service.model.enums.FyEnum;

/**
 * Created by 13314 on 2018/9/5.
 */
public class AjUtil {
    public static String formAJBS(int ajxh,String fydm){
        String fybh = FyEnum.findByFydm(fydm).getFybh() ;
        String result = "";
        String ajxhStr = ajxh+"" ;
        int len = ajxhStr.length();
        for (int i = len; i < 11; i++) {
            ajxhStr = "0" + ajxhStr;
        }
        int len_Fy = fybh.length();
        for (int i = len_Fy; i < 4; i++) {
            fybh = "0" + fybh;
        }
        result = fybh + FyEnum.getBhForAjbs(fydm) + ajxhStr.substring(1);
        return result;
    }
}
