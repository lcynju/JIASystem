package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author 13314409603@163.com
 * @date 2019/4/21
 * @time 19:49
 * @Description
 */
@Data
public class EventField {
    /**
     * 相识，恋爱，结婚等事实类型
     */
    private String type ;
    transient List<BaseEvent> events ;
    public EventField(String type){
        this.type = type ;
    }
    public void addEvent(BaseEvent event){
        if(events==null){
            synchronized (this){
                if(events==null){
                    events = new ArrayList<>() ;
                }
            }
        }
        events.add(event) ;
    }
    public boolean isEmpty(){
        return events==null ;
    }
}
