package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:54
 * @Description
 */
public class Credit extends BaseEvent {
    private String debtor ;
    private String value ;

    public Credit(HashMap<String ,Object> map){
        super(map);
        this.debtor = (String) map.get("debtor");
        this.forRendaring.add((ArrayList<Integer>) map.get("debtor_index_pair")) ;

        this.value = (String) map.get("value");
        this.forRendaring.add((ArrayList<Integer>) map.get("value_index_pair")) ;
    }
    @Override
    /**
     * negated: trigger debtor value
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }

        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.debtor!=null && this.debtor.length()>0){
            str = str +" "+this.debtor ;
        }
        if(this.value!=null && this.value.length()>0){
            str = str +" "+this.value ;
        }
        this.title = str ;
    }
}
