package cn.edu.nju.software.service.model;

import lombok.Data;
import lombok.ToString;

/**
 * 返回客户端的结果
 * Created by DuWenjun on 2016/12/11.
 */
@Data
@ToString
public class ResponseResult {

    private boolean success;
    private String msg;
    private String err;
    private Object obj;
}
