package cn.edu.nju.software.service.model;

import lombok.Data;
import org.aspectj.lang.annotation.DeclareAnnotation;

/**其他诉讼参与人信息
 *
 * @author 13314
 * @date 2018/8/15
 */
@Data
public class Qtsscyr {
    /**
     * 类型
     */
    private String lx ;
    /**
     * 类型代码
     */
    private String lxDm ;
    /**
     * 名称
     */
    private String mc ;
    /**
     * 信息
     */
    private String xx ;

    @Override
    public String toString() {
        return "Qtsscyr{" +
                "lx='" + lx + '\'' +
                "lxDm='" + lxDm + '\'' +
                ", mc='" + mc + '\'' +
                ", xx='" + xx + '\'' +
                '}';
    }
}
