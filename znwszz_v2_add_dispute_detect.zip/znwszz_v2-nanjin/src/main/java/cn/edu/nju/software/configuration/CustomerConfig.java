package cn.edu.nju.software.configuration;

import freemarker.template.TemplateExceptionHandler;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File;
import java.io.IOException;

/**
 *  系统各类配置bean
 * @author 13314
 * @date 2018/8/6
 */
@Configuration
public class CustomerConfig {
    /**
     * 将自定义yml属性暴露，才可通过@Value，${}，以及@ConfigurationProperties访问
     * 必须注册为static
     *
     * @return
     */
    @Bean
    public static PropertySourcesPlaceholderConfigurer properties(){
        PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer() ;
        YamlPropertiesFactoryBean yaml = new YamlPropertiesFactoryBean() ;
        ClassPathResource generalResource = new ClassPathResource("config"+File.separator+"general.yml");
        yaml.setResources(generalResource);
        configurer.setProperties(yaml.getObject());
        return configurer ;
    }
    /**
     * freemarker Configuration
     * @return
     * @throws IOException
     */
    @Bean
    public freemarker.template.Configuration cfg() throws IOException {
        freemarker.template.Configuration cfg = new freemarker.template.Configuration(freemarker.template.Configuration.VERSION_2_3_28) ;
        cfg.setClassForTemplateLoading(this.getClass(),"/templates/ftl");
        cfg.setDefaultEncoding("UTF-8");
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
        cfg.setLogTemplateExceptions(false);
        cfg.setWrapUncheckedExceptions(true);
        return cfg ;
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**");
            }
        };
    }

}
