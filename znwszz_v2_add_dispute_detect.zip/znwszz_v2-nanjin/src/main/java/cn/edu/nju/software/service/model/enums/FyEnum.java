package cn.edu.nju.software.service.model.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by 13314 on 2018/8/1.
 */
public enum FyEnum {
    /**
     * 法院枚举类
     */
    TJGY("天津市高级人民法院","高院","120000 200","130.1.1.111","51", 1),
    TJYZY("天津市第一中级人民法院","一中院","120100 210","130.2.0.110","52", 2),
    TJEZY("天津市第二中级人民法院","二中院","120200 220","130.3.100.36","62", 3),
    TJHS("天津海事法院","海事法院","960200 230","130.4.1.196","72", 4),
    TJBH("天津滨海法院","滨海新区","120242 22A","130.25.1.13","74", 5),
    TJHP("天津市和平区人民法院","和平法院","120101 211","130.6.0.200","53", 6),
    TJHD("天津市河东区人民法院","河东法院","120202 221","130.9.40.13","63", 7),
    TJHX("天津市河西区人民法院","河西法院","120203 222","130.10.0.167","64", 8),
    TJHB("天津市河北区人民法院","河北法院","120105 213","130.7.0.7","55", 9),
    TJNK("天津市南开区人民法院","南开法院","120104 212","130.5.0.14","54", 10),
    TJHQ("天津市红桥区人民法院","红桥法院","120106 214","130.8.0.73","56", 11),
    TJDL("天津市东丽区人民法院","东丽法院","120207 226","130.13.0.13","68", 12),
    TJXQ("天津市西青区人民法院","西青法院","120107 215","130.11.1.5","57", 13),
    TJJN("天津市津南区人民法院","津南法院","120208 227","130.14.0.22","69", 14),
    TJBC("天津市北辰区人民法院","北辰法院","120108 216","130.12.0.2","58",15),
    TJWQ("天津市武清区人民法院","武清法院","120222 217","130.19.0.12","59", 16),
    TJBD("天津市宝坻区人民法院","宝坻法院","120224 219","130.21.0.5","61", 17),
    TJJH("天津市静海区人民法院","静海法院","120223 218","130.20.1.8","60", 18),
    TJNH("宁河区人民法院","宁河法院","120221 228","130.18.0.11","70", 19),
    JX("天津市蓟州区人民法院","蓟州法院","120225 21A","130.22.0.8","73", 20),
    TJTG("天津市塘沽区人民法院","塘沽法院","120204 223","130.15.0.21","65", 21),
    TJHG("天津市汉沽区人民法院","汉沽法院","120205 224","130.16.0.18","66", 22),
    TJDG("天津市大港区人民法院","大港法院","120206 225","130.17.0.12","67", 23),
    TJKFQ("天津市经济技术开发区人民法院","功能审判区","120241 229","130.23.0.15","71", 24),
    TJTL("天津铁路运输法院","铁路法院","920103 132","130.26.0.7","24", 25),
        ;

    String name;

    String jc;

    String fydm;

    String fydz;

    String fybh;

    Integer index;


    FyEnum(String name, String jc, String fydm, String fydz, String fybh, Integer index) {
        this.name = name;
        this.jc = jc;
        this.fydm = fydm;
        this.fydz = fydz;
        this.fybh = fybh;
        this.index = index;
    }

    public static Map<String,FyEnum> fydmMap = null ;
    public static Map<String,FyEnum> fyjcMap = null ;

    public static FyEnum findByFydm(String fydm){
        if(fydmMap==null){
            fydmMap = new HashMap<>(FyEnum.values().length) ;
            for(FyEnum fyEnum:FyEnum.values()){
                fydmMap.put(fyEnum.getFydm(),fyEnum) ;
            }
        }
        return fydmMap.get(fydm) ;
    }
    public static FyEnum findByJc(String jc){
        if(fyjcMap==null){
            fyjcMap = new HashMap<>(FyEnum.values().length) ;
            for(FyEnum fyEnum:FyEnum.values()){
                fyjcMap.put(fyEnum.getJc(),fyEnum) ;
            }
        }
        return fyjcMap.get(jc) ;
    }

    public static String getSjFyMc(String fydm){ //获得上级法院
        if("120000 200".equals(fydm)) {
            return "最高人民法院";
        } else {
            return getSjFy(fydm).name ;
        }
    }
    public static FyEnum getSjFy(String fydm){
        if("120000 200".equals(fydm)) {
            return null;
        } else if("120100 210".equals(fydm) || "120200 220".equals(fydm)) {
            return TJGY;
        } else if(fydm.charAt(8)=='1') {
            return TJYZY;
        } else {
            return TJEZY;
        }
    }
    public static int getBhForAjbs(String fydm){
        FyEnum fyEnum = findByFydm(fydm);
        if(fyEnum.equals(TJTG)){
            return 1 ;
        }else if(fyEnum.equals(TJHG)){
            return 2 ;
        }else if(fyEnum.equals(TJDG)){
            return 3 ;
        }else if(fyEnum.equals(TJKFQ)){
            return 4 ;
        }else {
            return 0;
        }

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJc() {
        return jc;
    }

    public void setJc(String jc) {
        this.jc = jc;
    }

    public String getFydm() {
        return fydm;
    }

    public void setFydm(String fydm) {
        this.fydm = fydm;
    }

    public String getFydz() {
        return fydz;
    }

    public void setFydz(String fydz) {
        this.fydz = fydz;
    }

    public String getFybh() {
        return fybh;
    }

    public void setFybh(String fybh) {
        this.fybh = fybh;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }
}
