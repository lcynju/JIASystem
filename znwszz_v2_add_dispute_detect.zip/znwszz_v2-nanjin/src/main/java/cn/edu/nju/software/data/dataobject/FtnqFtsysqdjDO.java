package cn.edu.nju.software.data.dataobject;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * FtnqFtsysqdjDO entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "FTNQ_FTSYSQDJ")
@IdClass(FtnqFtsysqdjDOId.class)
public class FtnqFtsysqdjDO implements java.io.Serializable {

	// Fields
	private Integer ajxh;
	private Integer sqbh;
	private String unit;
	private Integer menCount;
	private String caseReason;
	private String bgMen;
	private String ygMen;
	private String sqType;
	private String agreeMen;
	private String phone;
	private String lxMen;
	private Date sendDate;
	private String sfap;
	private Date sqDate;
	private String sxw;
	private Date rq;
	private String sqtjs;
	private String sqft;
	private String sjsxw;
	private String sjft;
	private String sjtjs;
	private Integer ptrs;
	private String sfgkkt;
	private String bgkktyy;
	private String ywpsycj;
	private String ywwfftjlqk;
	private String ktcjry;
	private String ygsfdt;
	private String bgsfdt;
	private String sjy;
	private String yqslyy;
	private Date sprq;
	private String sqr;
	private String spryj;
	private String yqsljg;
	private Date hfslrq;
	private String zcktly;
	private String ftyt;

	@Column(name="XS")
	private short xs;
	private Date zhsdrq;
	private Date ggrq;

//
//	public short getXs() {
//		return xs;
//	}
//
//	public void setXs(short xs) {
//		this.xs = xs;
//}

	private Date yqsqrq;
	private Date pqrq;
	private String bgkyydm;
	private Integer fz;
	private String sftz;
	private String sffbktgg;

	/*@Column(name="RMPSYXM")
	public String getRmpsyxm() {
		return rmpsyxm;
	}

	public void setRmpsyxm(String rmpsyxm) {
		this.rmpsyxm = rmpsyxm;
	}

	private String rmpsyxm;*/
	/**
	 * zcz
	 */
	private String sfktsl;//是否开庭审理
	private String sfwskt;
	private String plktsqbs;//批量开庭申请标识
	private Integer plktsqktsx;//批量开庭申请开庭顺序

	private String tssp;
	private Byte[] tsbl;
	private String tsblhzm;
	// Constructors

	@Column(name="TSSP")
	public String getTssp() {
		return tssp;
	}

	public void setTssp(String tssp) {
		this.tssp = tssp;
	}

	@Column(name="TSBL")
	public Byte[] getTsbl() {
		return tsbl;
	}

	public void setTsbl(Byte[] tsbl) {
		this.tsbl = tsbl;
	}

	@Column(name="TSBLHZM")
	public String getTsblhzm() {
		return tsblhzm;
	}

	public void setTsblhzm(String tsblhzm) {
		this.tsblhzm = tsblhzm;
	}

	/** default constructor */
	public FtnqFtsysqdjDO() {
	}

	/** minimal constructor */
	public FtnqFtsysqdjDO(Integer ajxh, Integer sqbh) {
		this.ajxh = ajxh;
		this.sqbh = sqbh;
	}

	/** full constructor */
	public FtnqFtsysqdjDO(Integer ajxh, Integer sqbh, String unit, Integer menCount,
						  String caseReason, String bgMen, String ygMen, String sqType,
						  String agreeMen, String phone, String lxMen, Date sendDate,
						  String sfap, Date sqDate, String sxw, Date rq, String sqtjs,
						  String sqft, String sjsxw, String sjft, String sjtjs, Integer ptrs,
						  String sfgkkt, String bgkktyy, String ywpsycj, String ywwfftjlqk,
						  String ktcjry, String ygsfdt, String bgsfdt, String sjy,
						  String yqslyy, Date sprq, String sqr, String spryj, String yqsljg,
						  Date hfslrq, String zcktly, Date zhsdrq, Date ggrq,
						  Date yqsqrq, Date pqrq, String bgkyydm, Integer fz, String sftz,String sffbktgg, String sfktsl,
						  String tssp, Byte[] tsbl, String tsblhzm,String ftyt,String sfwskt) {
		//this.xs=xs;
		//this.rmpsyxm=rmpsyxm;
		this.tssp=tssp;
		this.tsbl=tsbl;
		this.tsblhzm=tsblhzm;
		this.ajxh = ajxh;
		this.sqbh = sqbh;
		this.unit = unit;
		this.menCount = menCount;
		this.caseReason = caseReason;
		this.bgMen = bgMen;
		this.ygMen = ygMen;
		this.sqType = sqType;
		this.agreeMen = agreeMen;
		this.phone = phone;
		this.lxMen = lxMen;
		this.sendDate = sendDate;
		this.sfap = sfap;
		this.sqDate = sqDate;
		this.sxw = sxw;
		this.rq = rq;
		this.sqtjs = sqtjs;
		this.sqft = sqft;
		this.sjsxw = sjsxw;
		this.sjft = sjft;
		this.sjtjs = sjtjs;
		this.ptrs = ptrs;
		this.sfgkkt = sfgkkt;
		this.bgkktyy = bgkktyy;
		this.ywpsycj = ywpsycj;
		this.ywwfftjlqk = ywwfftjlqk;
		this.ktcjry = ktcjry;
		this.ygsfdt = ygsfdt;
		this.bgsfdt = bgsfdt;
		this.sjy = sjy;
		this.yqslyy = yqslyy;
		this.sprq = sprq;
		this.sqr = sqr;
		this.spryj = spryj;
		this.yqsljg = yqsljg;
		this.hfslrq = hfslrq;
		this.zcktly = zcktly;
//		this.xs = xs;
		this.zhsdrq = zhsdrq;
		this.ggrq = ggrq;
		this.yqsqrq = yqsqrq;
		this.pqrq = pqrq;
		this.bgkyydm = bgkyydm;
		this.fz = fz;
		this.sftz = sftz;
		this.sffbktgg = sffbktgg;
		this.sfktsl = sfktsl;
		this.ftyt=ftyt;
		this.sfwskt=sfwskt;
	}

	// Property accessors
	@Id
	@Column(name = "AJXH", nullable = false)
	public Integer getAjxh() {
		return this.ajxh;
	}

	public void setAjxh(Integer ajxh) {
		this.ajxh = ajxh;
	}

	@Id
	@Column(name = "SQBH", nullable = false)
	public Integer getSqbh() {
		return this.sqbh;
	}

	public void setSqbh(Integer sqbh) {
		this.sqbh = sqbh;
	}

	@Column(name = "UNIT", length = 10)
	public String getUnit() {
		return this.unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	@Column(name = "MEN_COUNT")
	public Integer getMenCount() {
		return this.menCount;
	}

	public void setMenCount(Integer menCount) {
		this.menCount = menCount;
	}

	@Column(name = "CASE_REASON", length = 40)
	public String getCaseReason() {
		return this.caseReason;
	}

	public void setCaseReason(String caseReason) {
		this.caseReason = caseReason;
	}

	@Column(name = "BG_MEN")
	public String getBgMen() {
		return this.bgMen;
	}

	public void setBgMen(String bgMen) {
		this.bgMen = bgMen;
	}

	@Column(name = "YG_MEN")
	public String getYgMen() {
		return this.ygMen;
	}

	public void setYgMen(String ygMen) {
		this.ygMen = ygMen;
	}

	@Column(name = "SQ_TYPE", length = 20)
	public String getSqType() {
		return this.sqType;
	}

	public void setSqType(String sqType) {
		this.sqType = sqType;
	}

	@Column(name = "AGREE_MEN", length = 40)
	public String getAgreeMen() {
		return this.agreeMen;
	}

	public void setAgreeMen(String agreeMen) {
		this.agreeMen = agreeMen;
	}

	@Column(name = "PHONE", length = 15)
	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	@Column(name = "LX_MEN", length = 40)
	public String getLxMen() {
		return this.lxMen;
	}

	public void setLxMen(String lxMen) {
		this.lxMen = lxMen;
	}

	@Column(name = "SEND_DATE", length = 23)
	public Date getSendDate() {
		return this.sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	@Column(name = "SFAP", length = 1)
	public String getSfap() {
		return this.sfap;
	}

	public void setSfap(String sfap) {
		this.sfap = sfap;
	}

	@Column(name = "SQ_DATE", length = 23)
	public Date getSqDate() {
		return this.sqDate;
	}

	public void setSqDate(Date sqDate) {
		this.sqDate = sqDate;
	}

	@Column(name = "SXW", length = 4)
	public String getSxw() {
		return this.sxw;
	}

	public void setSxw(String sxw) {
		this.sxw = sxw;
	}

	@Column(name = "RQ", length = 23)
	public Date getRq() {
		return this.rq;
	}

	public void setRq(Date rq) {
		this.rq = rq;
	}

	@Column(name = "SQTJS", length = 20)
	public String getSqtjs() {
		return this.sqtjs;
	}

	public void setSqtjs(String sqtjs) {
		this.sqtjs = sqtjs;
	}

	@Column(name = "SQFT", length = 20)
	public String getSqft() {
		return this.sqft;
	}

	public void setSqft(String sqft) {
		this.sqft = sqft;
	}

	@Column(name = "SJSXW", length = 4)
	public String getSjsxw() {
		return this.sjsxw;
	}

	public void setSjsxw(String sjsxw) {
		this.sjsxw = sjsxw;
	}

	@Column(name = "SJFT", length = 20)
	public String getSjft() {
		return this.sjft;
	}

	public void setSjft(String sjft) {
		this.sjft = sjft;
	}

	@Column(name = "SJTJS", length = 20)
	public String getSjtjs() {
		return this.sjtjs;
	}

	public void setSjtjs(String sjtjs) {
		this.sjtjs = sjtjs;
	}

	@Column(name = "PTRS")
	public Integer getPtrs() {
		return this.ptrs;
	}

	public void setPtrs(Integer ptrs) {
		this.ptrs = ptrs;
	}

	@Column(name = "SFGKKT", length = 1)
	public String getSfgkkt() {
		return this.sfgkkt;
	}

	public void setSfgkkt(String sfgkkt) {
		this.sfgkkt = sfgkkt;
	}

	@Column(name = "BGKKTYY", length = 50)
	public String getBgkktyy() {
		return this.bgkktyy;
	}

	public void setBgkktyy(String bgkktyy) {
		this.bgkktyy = bgkktyy;
	}

	@Column(name = "YWPSYCJ", length = 1)
	public String getYwpsycj() {
		return this.ywpsycj;
	}

	public void setYwpsycj(String ywpsycj) {
		this.ywpsycj = ywpsycj;
	}

	@Column(name = "YWWFFTJLQK", length = 1)
	public String getYwwfftjlqk() {
		return this.ywwfftjlqk;
	}

	public void setYwwfftjlqk(String ywwfftjlqk) {
		this.ywwfftjlqk = ywwfftjlqk;
	}

	@Column(name = "KTCJRY")
	public String getKtcjry() {
		return this.ktcjry;
	}

	public void setKtcjry(String ktcjry) {
		this.ktcjry = ktcjry;
	}

	@Column(name = "YGSFDT", length = 1)
	public String getYgsfdt() {
		return this.ygsfdt;
	}

	public void setYgsfdt(String ygsfdt) {
		this.ygsfdt = ygsfdt;
	}

	@Column(name = "BGSFDT", length = 1)
	public String getBgsfdt() {
		return this.bgsfdt;
	}

	public void setBgsfdt(String bgsfdt) {
		this.bgsfdt = bgsfdt;
	}

	@Column(name = "SJY", length = 10)
	public String getSjy() {
		return this.sjy;
	}

	public void setSjy(String sjy) {
		this.sjy = sjy;
	}

	@Column(name = "YQSLYY")
	public String getYqslyy() {
		return this.yqslyy;
	}

	public void setYqslyy(String yqslyy) {
		this.yqslyy = yqslyy;
	}

	@Column(name = "SPRQ", length = 23)
	public Date getSprq() {
		return this.sprq;
	}

	public void setSprq(Date sprq) {
		this.sprq = sprq;
	}

	@Column(name = "SQR", length = 50)
	public String getSqr() {
		return this.sqr;
	}

	public void setSqr(String sqr) {
		this.sqr = sqr;
	}

	@Column(name = "SPRYJ")
	public String getSpryj() {
		return this.spryj;
	}

	public void setSpryj(String spryj) {
		this.spryj = spryj;
	}

	@Column(name = "YQSLJG", length = 10)
	public String getYqsljg() {
		return this.yqsljg;
	}

	public void setYqsljg(String yqsljg) {
		this.yqsljg = yqsljg;
	}

	@Column(name = "HFSLRQ", length = 23)
	public Date getHfslrq() {
		return this.hfslrq;
	}

	public void setHfslrq(Date hfslrq) {
		this.hfslrq = hfslrq;
	}

	@Column(name = "ZCKTLY")
	public String getZcktly() {
		return this.zcktly;
	}

	public void setZcktly(String zcktly) {
		this.zcktly = zcktly;
	}

//	@Column(name = "XS")
//	public short getXs() {
//		return this.xs;
//	}
//
//	public void setXs(short xs) {
//		this.xs = xs;
//	}

	@Column(name = "ZHSDRQ", length = 23)
	public Date getZhsdrq() {
		return this.zhsdrq;
	}

	public void setZhsdrq(Date zhsdrq) {
		this.zhsdrq = zhsdrq;
	}

	@Column(name = "GGRQ", length = 23)
	public Date getGgrq() {
		return this.ggrq;
	}

	public void setGgrq(Date ggrq) {
		this.ggrq = ggrq;
	}

	@Column(name = "YQSQRQ", length = 23)
	public Date getYqsqrq() {
		return this.yqsqrq;
	}

	public void setYqsqrq(Date yqsqrq) {
		this.yqsqrq = yqsqrq;
	}

	@Column(name = "PQRQ", length = 23)
	public Date getPqrq() {
		return this.pqrq;
	}

	public void setPqrq(Date pqrq) {
		this.pqrq = pqrq;
	}

	@Column(name = "BGKYYDM", length = 10)
	public String getBgkyydm() {
		return this.bgkyydm;
	}

	public void setBgkyydm(String bgkyydm) {
		this.bgkyydm = bgkyydm;
	}

	@Column(name = "FZ")
	public Integer getFz() {
		return this.fz;
	}

	public void setFz(Integer fz) {
		this.fz = fz;
	}

	@Column(name = "SFTZ", length = 1)
	public String getSftz() {
		return this.sftz;
	}

	public void setSftz(String sftz) {
		this.sftz = sftz;
	}

	@Column(name = "SFFBKTGG", length = 2)
	public String getSffbktgg() {
		return this.sffbktgg;
	}

	public void setSffbktgg(String sffbktgg) {
		this.sffbktgg = sffbktgg;
	}

	@Column(name = "SFKTSL", length = 2)
	public String getSfktsl() {
		return sfktsl;
	}

	public void setSfktsl(String sfktsl) {
		this.sfktsl = sfktsl;
	}

	@Column(name="PLKTSQBS", length = 10)
	public String getPlktsqbs() {
		return plktsqbs;
	}

	public void setPlktsqbs(String plktsqbs) {
		this.plktsqbs = plktsqbs;
	}

	@Column(name="PLKTSQKTSX")
	public Integer getPlktsqktsx() {
		return plktsqktsx;
	}

	public void setPlktsqktsx(Integer plktsqktsx) {
		this.plktsqktsx = plktsqktsx;
	}
	@Column(name="FTYT")
	public String getFtyt() {
		return ftyt;
	}

	public void setFtyt(String ftyt) {
		this.ftyt = ftyt;
	}
	@Column(name="SFWSKT")
	public String getSfwskt() {
		return sfwskt;
	}

	public void setSfwskt(String sfwskt) {
		this.sfwskt	 = sfwskt;
	}


}