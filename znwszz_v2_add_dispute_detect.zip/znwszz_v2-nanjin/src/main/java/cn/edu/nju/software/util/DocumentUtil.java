package cn.edu.nju.software.util;

import cn.edu.nju.software.service.model.enums.DocumentTypeEnum;
import cn.edu.nju.software.service.model.exception.BaseException;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

/**
 *  文档工具类
 * @author 13314
 * @date 2018/8/7
 */
public class DocumentUtil {

    /**
     * 文档key最大长度
     */
    private final static int KEY_MAX_LENGTH = 20 ;
    /**
     * 根据文档存储路径获取文档的文件名称
     * @param savePath 文档保存路径
     * @return  文档文件名称
     */
    public static String getDocumentName(String savePath){
        if (StringUtil.isEmpty(savePath)){
            return null ;
        }
        String name = savePath ;
        if (savePath.contains(File.separator)) {
            name = savePath.substring(savePath.lastIndexOf(File.separator)+1,savePath.length()) ;
        }
        return name ;
    }

    /**
     * 根据文档文件名称获得文件扩展名
     * @param fileName 文件名称，text.docx
     * @return 扩展名，如：.docx
     */
    public static String getFileExtension(String fileName){
        if (StringUtil.isEmpty(fileName)){
            return null ;
        }
        if(fileName.lastIndexOf(".")==-1) {
           throw new BaseException("文件名错误，没有扩展名") ;
        }
        String fileExt = fileName.substring(fileName.lastIndexOf(".")) ;
        return fileExt.toLowerCase() ;
    }

    /**
     * 获取不含扩展名的文档名
     * @param fileName text.docx abc/def/text.docx
     * @return text abc/def/text
     */
    public static String getFileNameWithoutExtension(String fileName) {
        if(StringUtil.isEmpty(fileName)) {
            return null ;
        }
        String fileNameWithoutExtension = fileName.substring(0,fileName.lastIndexOf(".")) ;
        return fileNameWithoutExtension ;
    }

    /**
     * 生成文档的唯一ID
     * @param expectedKey
     * @return
     */
    public static String GenerateRevisionId(String expectedKey) {
        expectedKey = Integer.toString(expectedKey.hashCode());

        String key = expectedKey.replace("[^0-9-.a-zA-Z_=]", "_");

        return key.substring(0, Math.min(key.length(), KEY_MAX_LENGTH));
    }

    /**
     * 检查文件头是否为指定类型
     * @param fis
     * @param fileHeader
     * @return
     * @throws IOException
     */
    public static boolean checkSuffixAndFileHeader(InputStream fis, String fileHeader) throws IOException {
        String fileHeaderInfo = getFileHeaderInfo(fis, fileHeader.length() / 2);
        return StringUtil.equals(fileHeaderInfo, fileHeader);
    }

    /**
     * 获取文件头类型信息
     * @param fis
     * @param infoLength,文件头的byte长度
     * @return
     */
    private static String getFileHeaderInfo(InputStream fis, int infoLength) throws IOException {
        byte[] info_bytes = new byte[infoLength] ;
        fis.read(info_bytes,0,infoLength) ;
        return bytesToHexString(info_bytes).toUpperCase();
    }
    /**
     * 得到上传文件的文件头
     *
     * @param src
     * @return
     */
    private static String bytesToHexString(byte[] src) {
        StringBuilder stringBuilder = new StringBuilder();
        if (null == src || src.length <= 0) {
            return null;
        }
        for (int i = 0; i < src.length; i++) {
            int v = src[i] & 0xFF;
            String hv = Integer.toHexString(v);
            if (hv.length() < 2) {
                stringBuilder.append(0);
            }
            stringBuilder.append(hv);
        }
        return stringBuilder.toString();
    }
}
