package cn.edu.nju.software.manager;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Map;

/**
 * @author 13314409603@163.com
 * @date 2018/10/30
 * @time 10:16
 * @Description
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TemplateManagerTest {
    @Autowired
    TemplateManager templateManager ;

    @Test
    public void test(){
        Map<String, Object> templateData = templateManager.getTemplateData("120104 212", 238202, 0);
        System.out.println("end");
    }
}
