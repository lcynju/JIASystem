package cn.edu.nju.software.service;

import cn.edu.nju.software.service.model.events.DivorceCaseModel;

/**
 * @author 13314409603@163.com
 * @date 2019/4/15
 * @time 15:09
 * @Description
 */
public interface EventExtractor {
    DivorceCaseModel extractorEvents(byte[] content);
}
