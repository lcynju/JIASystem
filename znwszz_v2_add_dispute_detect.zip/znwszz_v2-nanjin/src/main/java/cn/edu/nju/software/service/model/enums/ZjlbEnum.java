package cn.edu.nju.software.service.model.enums;

import cn.edu.nju.software.util.StringUtil;

/**
 * @author 13314409603@163.com
 * @date 2018/10/31
 * @time 9:42
 * @Description
 */
public enum ZjlbEnum {
    /**
     * 当事人个人证件类别
     */
    JMSFZ("A","居民身份证") ,
    ZGGMHZ("B","中国居民护照") ,
    TWJMLWDLTXZ("C","台湾居民来往大陆通行证") ,
    GAJMLWNDTXZ("D","港澳居民来往内地通行证") ,
    WGGMHZ("E","外国公民护照") ,
    HKB("F","户口簿") ,
    SHTYXYDMZ("G","社会统一信用代码证") ,
    QT("Z","其他") ,
    ;
    private String dm ;
    private String mc ;
    ZjlbEnum(String dm,String mc){
        this.dm = dm ;
        this.mc = mc ;
    }
    public static String findMcByDm(String dm){
        for(ZjlbEnum zjlbEnum:ZjlbEnum.values()){
            if(StringUtil.equals(zjlbEnum.dm,StringUtil.trim(dm))){
                return zjlbEnum.mc ;
            }
        }
        return QT.mc ;
    }
}
