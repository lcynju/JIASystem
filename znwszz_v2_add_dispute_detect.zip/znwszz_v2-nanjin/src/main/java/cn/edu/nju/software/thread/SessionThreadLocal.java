package cn.edu.nju.software.thread;

import javax.servlet.http.HttpSession;

public class SessionThreadLocal {
    private static ThreadLocal<HttpSession> threadLocal = new ThreadLocal<>();

    public static <T extends HttpSession> void put(T t) {
        threadLocal.set(t);
    }

    @SuppressWarnings("unchecked")
    public static <T> T get() {
        return (T) threadLocal.get();
    }

    public static void remove() {
        threadLocal.remove();
    }

}
