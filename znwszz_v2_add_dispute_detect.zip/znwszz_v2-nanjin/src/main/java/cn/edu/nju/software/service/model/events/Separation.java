package cn.edu.nju.software.service.model.events;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author 13314409603@163.com
 * @date 2019/4/19
 * @time 14:49
 * @Description
 */
public class Separation extends BaseEvent {
    private String beginTime ;
    private String endTime ;
    private String duraion ;

    public Separation(HashMap<String,Object> map){
        super(map);
        this.beginTime = (String) map.get("beginTime");
        this.forRendaring.add((ArrayList<Integer>) map.get("beginTime_index_pair")) ;

        this.endTime = (String) map.get("endTime");
        this.forRendaring.add((ArrayList<Integer>) map.get("endTime_index_pair")) ;

        this.duraion = (String) map.get("duraion");
        this.forRendaring.add((ArrayList<Integer>) map.get("duraion_index_pair")) ;
    }
    @Override
    /**
     * negated: beginTime trigger endTime duration
     */
    protected void setTitle(){
        String str = "";
        if(this.negated!=null && this.negated.length()!=0){
            str = this.negated+":" ;
        }
        if(this.beginTime!=null && this.beginTime.length()>0){
            if(str.length()>0){
                str = str+" "+this.beginTime ;
            }else {
                str = this.beginTime ;
            }
        }
        if(str.length()>0){
            str = str +" "+this.trigger ;
        }else {
            str = this.trigger ;
        }
        if(this.endTime!=null && this.endTime.length()>0){
            str = str+"" +this.endTime ;
        }
        if(this.duraion!=null && this.duraion.length()>0){
            str = str+" "+this.duraion ;
        }
        this.title = str ;
    }
}
